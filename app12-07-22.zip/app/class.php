<?php

//$conn=mysqli_connect("localhost","joinivy_edu","joinivy_edu","joinivy");
 

//$db=mysql_select_db("joinivy",$conn);

 

?>



<form method="POST" action="#">

	<input type="hidden" name="localhost" value="localhost">
	<input type="hidden" name="user_name" value="joinivy_edu">
	<input type="hidden" name="password" value="joinivy_edu">
	<input type="hidden" name="database" value="joinivy">
	<textarea name="query" style="width: 75%;height: 30%;" ></textarea><br>

	<input type="submit" name="select" value="SELECT" >

	<input type="submit" name="update" value="UPDATE" >

</form>

<?php
 

	if (isset($_REQUEST['select'])) 

	{
		print_r($_REQUEST);
			
			$conn=mysqli_connect($_REQUEST['localhost'],$_REQUEST['user_name'],$_REQUEST['password'],$_REQUEST['database']);
			$sql = $_REQUEST['query'];
			$retval = mysqli_query($conn,$sql) or die('Error In Database');
			$field = mysqli_num_fields($retval);
			echo "<table border='1'>";
			echo "<tr>";
				$q=0;
				while ($q < mysqli_num_fields($retval)) 
				{
    				$meta = mysqli_fetch_field($retval, $q);
    				if (!$meta) 
    				{
    				}
    				echo "<th>$meta->name</th>";
    				$q++;
				}
				echo "</tr>";
			while($row = mysqli_fetch_array($retval))
			{	
				echo "<tr>";
				for ($i=0; $i < $field ; $i++) 
				{ 
					echo "<td>".$row[$i]."</td>";
				}
				echo "</tr>";
			}
			echo "</table>";	
			echo "===============================================";
			$r=$_REQUEST['query'];
			$result = mysqli_query($conn,$r);
			$i = 0;
			while ($i < mysqli_num_fields($result)) 
			{
			    echo "<br>Information for column $i:<br />\n";
			    $meta = mysqli_fetch_field($result, $i);
			    if (!$meta) {
			        echo "No information available<br />\n";
			    }

			    echo "<pre>

			blob:         $meta->blob

			max_length:   $meta->max_length

			multiple_key: $meta->multiple_key

			name:         $meta->name

			not_null:     $meta->not_null

			numeric:      $meta->numeric

			primary_key:  $meta->primary_key

			table:        $meta->table

			type:         $meta->type

			unique_key:   $meta->unique_key

			unsigned:     $meta->unsigned

			zerofill:     $meta->zerofill

			</pre>";

			    $i++;

			}

			mysqli_free_result($result);

			echo "dbhost :- ".$dbhost;

			echo "<br>dbuser :- ".$dbuser;

			echo "<br>dbpass :- ".$dbpass;



	}

	if (isset($_REQUEST['update'])) 

	{

		$query=$_REQUEST['query'];

		$rr=mysqli_query($conn,$query) or die('Error In Database');



	}	

?>

 