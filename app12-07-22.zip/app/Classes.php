<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classes extends Model
{
    Protected $table = 'class';  
    
}
