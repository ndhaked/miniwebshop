<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class Library extends Model

{

    Protected $table = 'library';  

    public function course() {
        return $this->belongsTo( 'App\Course','course_id');
    }

    public function class() {
        return $this->belongsTo( 'App\ClassDetails' ,'class_id');
    }

    public function teacher() {
        return $this->belongsTo( 'App\User' ,'teacher_id');
    }

}

