<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FrontHowWorksJoinivy extends Model
{
    Protected $table = 'front_home_how_works_joinivy';  
    
}
