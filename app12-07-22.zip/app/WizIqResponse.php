<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WizIqResponse extends Model
{
    //
}
