<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FrontTechnologyHuman extends Model
{
    protected $table = 'home_technology_human';
}
