<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class BatchClassDetails extends Model
{

    Protected $table = 'batch_class_details';
    // public $timestamps = false;  

}

