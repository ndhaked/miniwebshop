<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    public function orderItems() {
        return $this->hasMany( 'App\OrderItem' ,'order_id');
    }

    public function classStudentRequest() {
        return $this->belongsTo( 'App\ClassStudentRequest' ,'class_student_request_id');
    }

    public function orderCompletedUser() {
        return $this->belongsTo( 'App\User' ,'order_complete_user_id');
    }

    public function orderRequestedUser() {
        return $this->belongsTo( 'App\User' ,'request_user_id');
    }

    

    	
}
