<?php

include(app_path().'/edu_api/CancelClass.php');

function AddCopresenter($secretAcessKey,$access_key,$webServiceUrl, $start_date, $start_time, $class_name, $duration_time, $teacher_id, $attendee_limit,$create_recording, $teacher_name, $class_id)
{

    $authBase = new AuthBase($secretAcessKey, $access_key);

    $obj =  ScheduleClass($secretAcessKey,$access_key,$webServiceUrl, $start_date, $start_time, $class_name, $duration_time, $teacher_id, $attendee_limit,$create_recording, $teacher_name); 
    if($obj['errormsg']== null){
        CancelClass($secretAcessKey,$access_key,$webServiceUrl,$obj['class_ids']);

        $XMLAttendee = "<presenter_list><presenter>
    			    		<presenter_id><![CDATA[" . $teacher_id . "]]></presenter_id>
    					    <presenter_name><![CDATA[" . $teacher_name . "]]></presenter_name>
    					</presenter></presenter_list>";
        $method = "add_copresenter";
        $requestParameters["signature"] = $authBase->GenerateSignature($method, $requestParameters);
        $requestParameters["class_id"] = $class_id; //required
        $requestParameters["presenter_list"] = $XMLAttendee;
        $httpRequest = new HttpRequest();

        try
        {
            $XMLReturn = $httpRequest->wiziq_do_post_request($webServiceUrl . '?method=' . $method, http_build_query($requestParameters, '', '&'));
        } catch (Exception $e) {
            echo $e->getMessage();
        }
        if (!empty($XMLReturn)) {
            try
            {
                $objDOM = new DOMDocument();
                $objDOM->loadXML($XMLReturn);
            } catch (Exception $e) {
                echo $e->getMessage();
            }

            $status = $objDOM->getElementsByTagName("rsp")->item(0);
            $attribNode = $status->getAttribute("status");

    		if($attribNode == "ok"){
    			$presenter_url = $objDOM->getElementsByTagName("presenter_url")->item(0)->nodeValue;
    			return $presenter_url;
    		}
            else if ($attribNode == "fail") {
                $error = $objDOM->getElementsByTagName("error")->item(0);
                $msg = array('errormsg' => $errormsg = $error->getAttribute("msg"));
                print_r($msg);
                return $msg;

            }

        }
    }
    else{
        return $obj;
    }

}
