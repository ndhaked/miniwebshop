<?php

function uploadContent($secretAcessKey,$access_key,$webServiceUrl,$title,$presenter,$document,$folder_path,$accesslevel='2'){
	require_once("AuthBase.php");

	$requestParameters = array();
	$authBase = new AuthBase($secretAcessKey, $access_key);
	$method = "upload";
	$requestParameters["signature"] = $authBase->GenerateSignature($method, $requestParameters);
	$requestParameters["title"] = $title;
	//#for teacher account pass parameter 'presenter_email'
	//This is the unique email of the presenter that will identify the presenter in WizIQ. Make sure to add
	//this presenter email to your organization’s teacher account. ’ For more information visit at: (http://developer.wiziq.com/faqs)
	// $requestParameters["presenter_email"]= "prajay@ajency.in";
	// Optional parameters
	#for room based account pass parameters 'presenter_id', 'presenter_name'
	if(!empty($presenter)){
		$requestParameters["presenter_id"]=$presenter['id'];
		$requestParameters["presenter_name"]=$presenter['name'];
	}
	
	//$requestParameters.Add("presenter_id", "123");
	//$requestParameters.Add("presenter_name", "ramesh");
	//$requestParameters.Add("presenter_id", "578");
	//$requestParameters.Add("presenter_name", "David");
	//$requestParameters.Add("folder_path","Ram/Sham");
	//$requestParameters.Add("access_level","1");
	//$requestParameters.Add("return_url","");
	//$requestParameters.Add("status_ping_url","");
	//
	
	if($folder_path!=""){
		$requestParameters["folder_path"]= $folder_path;
	}

	$requestParameters["access_level"]= $accesslevel;
	$requestParameters["file_upload"]= $document;
	$fname = $document;
	$url = $webServiceUrl."?method=".$method; 
	$file = postfile($url, $fname, $requestParameters);

	return $file;

}



function postfile($url, $filepath, $requestParameters)
{
    if (file_exists($filepath))
    {
        $size = filesize($filepath);
        $fp = fopen($filepath, 'r');
        if (!$fp)
        {
            return ['response'=>'Cannot open file= ' . $filepath,'status'=>false];
             
        }
        if (!is_numeric($size))
        {
            return ['response'=>'File is empty','status'=>false];
            
        }
    } 
    else
    {
        return ['response'=>'File Not found= ' . $filepath,'status'=>false];
        
    }
    // $filapath = "@$filepath";
    // $requestParameters["file"] = $filapath;
    
    $cFile = curl_file_create($filepath);
    $requestParameters["file_contents"] = $cFile;
    $cur = curl_init($url);
    curl_setopt($cur, CURLOPT_POST, 1);
    curl_setopt($cur, CURLOPT_POSTFIELDS, $requestParameters);
    curl_setopt($cur, CURLOPT_INFILESIZE, $size);
    curl_setopt($cur,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($cur, CURLOPT_INFILE, $fp);
    $response = curl_exec($cur);
    curl_close($cur);
    fclose($fp);
    if(!empty ($response)){
    	try
		{
		  $objDOM = new DOMDocument(); 
		  $objDOM->loadXML($response); 

		}
		catch(Exception $e)
		{
		  	return ['response'=>$e->getMessage(),'status'=>false];
		}

		$status=$objDOM->getElementsByTagName("rsp")->item(0);
    	$attribNode = $status->getAttribute("status");
		if($attribNode=="ok")
		{
			$methodTag=$objDOM->getElementsByTagName("method");
			$methodname = $methodTag->item(0)->nodeValue;;
			$content_idTag=$objDOM->getElementsByTagName("content_id");
			$content_id=$content_idTag->item(0)->nodeValue;
			$response_data = ['method'=>$methodname,'content_id'=>$content_id];
    		return ['response'=>$response_data,'status'=>true];
    	}
    	else{
    		return ['response'=>[],'status'=>true];
    	}
    }    
    else{
    	return ['response'=>'Empty Response','status'=>false];
    }
 
 
}

function DeleteUploadContent($secretAcessKey,$access_key,$webServiceUrl,$content_id)
 {
    require_once("AuthBase.php");
    $authBase = new AuthBase($secretAcessKey,$access_key);
    $method = "delete";
    $requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
    $requestParameters["content_id"] = $content_id;//Required
    $httpRequest=new HttpRequest();
    try
    {
            $XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=delete',http_build_query($requestParameters, '', '&'));
    }
    catch(Exception $e)
    {
        return ['response'=>$e->getMessage(),'status'=>false];
    }
    if(!empty($XMLReturn))
    {
        return ['response'=>$XMLReturn,'status'=>true];
    }
    else
        return ['response'=>'Empty Response','status'=>false];
 }

?>