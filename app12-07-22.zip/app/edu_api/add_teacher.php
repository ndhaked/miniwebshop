<?php
header("Content-type:text/xml");
class add_teacher
{
 function add_teacher($secretAcessKey,$access_key,$webServiceUrl)
 {
    require_once("AuthBase.php");
    $authBase = new AuthBase($secretAcessKey,$access_key);
    $method = "add_teacher";
    $requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
    $requestParameters["presenter_email"]="kerrygun@gmail.com";
    $requestParameters["name"] = "Krupesh jarsaniya"; 
    $requestParameters["email"] = "krupesh8484@gmail.com"; 
    $requestParameters["password"] = "123456";//optional
    $requestParameters["mobile_number"] = "+91 9687728484"; 
    
    $httpRequest=new HttpRequest1();
    try
    {
            $XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=add_teacher',http_build_query($requestParameters, '', '&'));
    }
    catch(Exception $e)
    {
            echo $e->getMessage();
    }
    if(!empty($XMLReturn))
    {
        print $XMLReturn;
    }
    else
        echo "<response>Empty Response</response>";
 }
}
?>