<?php

	
	function RecurringClass($secretAcessKey,$access_key,$webServiceUrl, $newDate1, $newtime1, $teacher_id, $teacher_name, $week, $repeat_type, $comma_days, $duration_time, $attendee_limit, $class_end_date, $create_recording, $class_name)
	{
       	// include(app_path().'/edu_api/AuthBase.php');
		$authBase = new AuthBase($secretAcessKey,$access_key);
		$method = "create_recurring";
		$requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
		
		// $requestParameters["presenter_email"]= $Presenter_Email; // Add Teacher email here , Create or Add teacher From the wiziq account after login
	    #for room based account pass parameters 'presenter_id', 'presenter_name'

	    $requestParameters["presenter_id"] = $teacher_id;
	    $requestParameters["presenter_name"] = $teacher_name;

	    // API PARAMETERS////    

	    $requestParameters["start_time"] = $newDate1." ".$newtime1;//date('m/d/Y',strtotime($class_date))." ".date('H:i:s',strtotime($class_time));
	    $requestParameters["title"]=$class_name; //Required
	    
	    $requestParameters["class_repeat_type"]=$repeat_type; //Required
	   // $requestParameters["class_occurrence"]=$occurance; //Required
	    $requestParameters["specific_week"]=$week; //Required
	    $requestParameters["days_of_week"]=$comma_days; //Required
	    $requestParameters["class_end_date"]=$class_end_date; 

		
		    
	    $requestParameters["duration"]=$duration_time; //optional
	    $requestParameters["time_zone"]="Africa/Cairo"; //optional
	    $requestParameters["attendee_limit"]=$attendee_limit; //optional
	    $requestParameters["control_category_id"]="audio, video"; //optional
	    $requestParameters["create_recording"]=$create_recording; //optional


	    $requestParameters["return_url"]="https://joinivy.com"; //optional
	    $requestParameters["status_ping_url"]="http://joinivy.com/1/status.php"; //optional
	    $requestParameters["language_culture_name"]="en-us";
		 

        $var=http_build_query($requestParameters, '', '&');
        
		$httpRequest=new HttpRequest1();
		
		try
		{
			$XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=create_recurring',$var); 
			
		
		}
		catch(Exception $e)
		{	
	  		echo $e->getMessage();
		}
 		if(!empty($XMLReturn))
 		{
 			try
			{
			  $objDOM = new DOMDocument();
			  $objDOM->loadXML($XMLReturn);
	  
			}
			catch(Exception $e)
			{
			  echo $e->getMessage();
			}
		$status=$objDOM->getElementsByTagName("rsp")->item(0);
    	$attribNode = $status->getAttribute("status");
		if($attribNode=="ok")
		{
			$methodTag=$objDOM->getElementsByTagName("method");
            // $method=$methodTag->item(0)->nodeValue;

			//Getting Master ID Start //
            $master_idsTag = $objDOM->getElementsByTagName("class_master_id");
            // $master_ids = $master_idsTag->item(0)->nodeValue;
			//Getting Master ID End // 

           	$class_idTag=$objDOM->getElementsByTagName("class_id");
            // $class_session_code=$class_idTag->item(0)->nodeValue;
            $recording_urlTag=$objDOM->getElementsByTagName("recording_url");
            // $recording_url=$recording_urlTag->item(0)->nodeValue;
            $recurring_summaryTag=$objDOM->getElementsByTagName("recurring_summary");
            // $recurring_summary=$recurring_summaryTag->item(0)->nodeValue;

 
         
            // $presenter_emailTag=$objDOM->getElementsByTagName("presenter_email");
            // $presenter_email=$presenter_emailTag->item(0)->nodeValue;
            $presenter_urlTag=$objDOM->getElementsByTagName("presenter_url");
            // $presenter_url=$presenter_urlTag->item(0)->nodeValue;

            $abc =array('presenter_urlTag'=>$presenter_url=$presenter_urlTag->item(0)->nodeValue,'methodTag'=>$method=$methodTag->item(0)->nodeValue,'class_ids'=>$class_id=$class_idTag->item(0)->nodeValue,'class_master_id'=>$master_ids = $master_idsTag->item(0)->nodeValue, 'recording_url'=>$recording_url=$recording_urlTag->item(0)->nodeValue, 'errormsg' => null);
			return $abc;
		}
		else if($attribNode=="fail")
		{
			$error=$objDOM->getElementsByTagName("error")->item(0);
   			// echo "<br>errorcode=".$errorcode = $error->getAttribute("code");	

   			// echo "<br>errormsg=".$errormsg = $error->getAttribute("msg");

   			$msg = array('errormsg' =>  $errormsg = $error->getAttribute("msg"));
   			return $msg;	
		}
	 }//end if	
   }//end function
	

?>