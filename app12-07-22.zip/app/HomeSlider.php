<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomeSlider extends Model
{
    Protected $table = 'home_front_slider';  
    
}
