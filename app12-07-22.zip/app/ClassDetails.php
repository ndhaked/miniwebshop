<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClassDetails extends Model
{
    Protected $table = 'class_details';  

    public function course() {
        return $this->belongsTo( 'App\Course' ,'course_id');
    }
    
}
