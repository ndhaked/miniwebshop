<?php

	function ViewSchedule($secretAcessKey,$access_key,$webServiceUrl,$class_master_id)
	{
		$responseArray = array();
		require_once("AuthBase.php");
		$authBase = new AuthBase($secretAcessKey,$access_key);
		$method = "view_schedule";
		$requestParameters["signature"]=$authBase->GenerateSignature($method,$requestParameters);
		$requestParameters["class_master_id"] = $class_master_id;
		$requestParameters["page_size"] = 50;
		// $requestParameters["page_number"] = 1;  

		//print_r($reuestParameters1);
			$httpRequest=new HttpRequest1();
			try
			{
				$XMLReturn=$httpRequest->wiziq_do_post_request($webServiceUrl.'?method=view_schedule',http_build_query($requestParameters, '', '&')); 
			//print_r($XMLReturn);die();
		
			}
			catch(Exception $e)
			{
		  		echo $e->getMessage();
			}
	 		if(!empty($XMLReturn))
	 		{
	 			try{
				  $objDOM = new DOMDocument();
				  $objDOM->loadXML($XMLReturn);
				}
				catch(Exception $e){
				  echo $e->getMessage();
				}
			$status=$objDOM->getElementsByTagName("rsp")->item(0);
	    	$attribNode = $status->getAttribute("status");
			if($attribNode=="ok"){
			   // print_r($XMLReturn);

									   
				
				$i=0;
	            while(is_object($finance = $objDOM->getElementsByTagName("class_details")->item($i)))
	            {
	                     foreach($finance->childNodes as $nodename)
	                     {
	                             if($nodename->nodeName=='presenter_list')
	                                {

	                                     foreach($nodename->childNodes as $subNodes)
	                                     {  
	                                    
	                                     		 foreach ($subNodes->childNodes as $nodes) {
	                                     		 	   $responseArray[$nodes->nodeName][] = $nodes->nodeValue;
	                                     		 }
	                                     
	                        
	                                     }
	                                }
	                             else
	                                {
										$responseArray[$nodename->nodeName][] = $nodename->nodeValue;
	                                }
	                     }
	      			$i++;
	            }
	            // print_r($responseArray);
				return $responseArray;
	//echo "Count" . count($responseArray);
	 /*echo "<pre>";
	print_r($responseArray);
	echo "</pre>"; */
			}
		else if($attribNode=="fail")
		{
			$error=$objDOM->getElementsByTagName("error")->item(0);
   			$msg = array('errormsg' =>  $errormsg = $error->getAttribute("msg"));
   			return $msg;	
		}

    }
    else
    {
        echo "<response>Empty Response</response>";
    
 	}

}//end function
	

?>