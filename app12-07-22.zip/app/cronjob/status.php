<?php

$conn = mysqli_connect('localhost', 'joinivy_test', 'joinivy_test');
if (!$conn) {
    die('Not connected : ' . mysqli_error());
}

// make foo the current db
$db_selected = mysqli_select_db($conn,'joinivy_test');
if (!$db_selected) {
    die ('Can not use the database : ' . mysqli_error());
}


	$class_id = $_REQUEST['class_id'];
    $class_status = $_REQUEST['class_status'];
    $status = '';
    if($class_status=='completed')
    {
        $status='1';
    }
    elseif($class_status=='live')
    {
        $status='2';
    }
    elseif ($class_status=='expired') 
    {
        $status='4';
    }



	$query ="update schedule_class set status ='".$status."' where class_ids='".$class_id."'";
	mysqli_query($conn,$query) or die("failed".mysqli_error());


	$dateString = date("Y-m-d-h-i-s");
	$dateString = $dateString."_r.txt";
	$myFile = $dateString;
	$fh = fopen($myFile, 'w') or die("Log File Cannot Be Opened.");
	fwrite($fh, "data:- ");
	$output=json_encode($_REQUEST);
	fwrite($fh, $output);
	fclose($fh);

