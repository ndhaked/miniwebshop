<?php

$conn = mysqli_connect('localhost', 'joinivy_edu', 'joinivy_edu');
if (!$conn) {
    die('Not connected : ' . mysqli_error());
}

// make foo the current db
$db_selected = mysqli_select_db($conn,'joinivy');
if (!$db_selected) {
    die ('Can not use the database : ' . mysqli_error());
}

// $path = 'https://joinivy.com/app/edu_api/View_Schedule.php';
require_once("View_Schedule.php");
require_once("AddAttendee.php");

$access_key="nbaqEtPHk3E=";
$secretAcessKey="fipzu+2E2bDJRRPjjE418w==";
$webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";

$sql = "SELECT * FROM schedule_class WHERE status = 0 AND is_delete = 0 AND class_master_id != 0 AND class_master_id != 1 AND student_id !='null' AND student_name != 'null' GROUP BY class_master_id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) 
    {
        // echo $row['class_ids'];
        // echo '<br>';
        $view_schedule =  ViewSchedule($secretAcessKey,$access_key,$webServiceUrl,$row['class_master_id']);

        foreach ($view_schedule['class_id'] as $key => $value) 
        {
            $sql1 = "UPDATE schedule_class SET teacher_schedule_class_url = '".$view_schedule['presenter_url'][$key]."' WHERE class_ids ='".$view_schedule['class_id'][$key]."'";
            if ($conn->query($sql1) === TRUE) 
            {
                // echo "Record updated successfully";
            } 
            else
            {
                echo "Error updating record: " . $conn->error;
            }
        }

    }

} 
else 
{
    echo "0 results";
}


// AddAttendee

$sql_1 = "SELECT * FROM schedule_class WHERE student_schedule_class_url = 'null' AND status = 0 AND is_delete = 0";
$result_1 = $conn->query($sql_1);
if ($result_1->num_rows > 0) {

    // output data of each row
    while($row = $result_1->fetch_assoc()) 
    {
        // echo $row['student_id'];
        // echo '<br>';

        $student_api_array=array();
        $student_api_details['id']=$row['student_id'];
        $student_api_details['name']=$row['student_name'];
        array_push($student_api_array, $student_api_details);

        $obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl,$row['class_ids'],$student_api_array);
        print_r($obj_student);
        // echo count($obj_student['add_attendeesStatus']);
       
        $sql2 = "UPDATE schedule_class SET student_schedule_class_url = '".$obj_student['student_attendee_url']."' WHERE class_ids ='".$row['class_ids']."'";
        $conn->query($sql2);
    }
}



       


$conn->close();