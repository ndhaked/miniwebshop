<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FrontVirtualClass extends Model
{
    protected $table = 'home_virtual_class';
}
