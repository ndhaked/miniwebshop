<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LiveClass extends Model
{
    Protected $table = 'live_class';  
}
