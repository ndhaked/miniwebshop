<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class BuddyClassStudentRequest extends Model

{

    Protected $table = 'buddy_class_student_request';  

}
