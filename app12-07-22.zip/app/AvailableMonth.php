<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class AvailableMonth extends Model
{

    Protected $table = 'available_month';  
    // public $timestamps = false;

}

