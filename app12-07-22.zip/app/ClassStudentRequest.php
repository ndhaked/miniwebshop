<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class ClassStudentRequest extends Model

{

    Protected $table = 'class_students_request';  

    public function user() {
        return $this->belongsTo( 'App\User' ,'creator_id');
    }

    public function student() {
        return $this->belongsTo( 'App\User' ,'student_id');
    }

    public function classdetails() {
        return $this->belongsTo( 'App\ClassDetails' ,'class_details_id');
    }

    public function scheduleClass() {
        return $this->belongsTo( 'App\ScheduleClass' ,'schedule_class_id');
    }
}
