<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeacherDetails extends Model
{
    protected $table = 'teacher_details';
}
