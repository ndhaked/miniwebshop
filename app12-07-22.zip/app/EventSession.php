<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventSession extends Model
{
    public function schedule_class() {
        return $this->belongsTo( 'App\ScheduleClass','schedule_class_id' );
    }

    public function user() {
        return $this->belongsTo( 'App\User' ,'teacher_id');
    }

    public function assistantTeacher() {
        return $this->belongsTo( 'App\User' ,'assistant_teacher_id');
    }

    public function eventParticipants() {
        return $this->hasMany( 'App\EventParticipant' ,'event_session_id');
    }

    public function eventSchedule() {
        return $this->belongsTo( 'App\EventSchedule' ,'event_schedule_id');
    }
}
