<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Response;
use Redirect;
use DB;
use App\PasswordReset;
use View;
use App\Course;


class PasswordResetController extends Controller
{
    public function __construct()
    {
        $courses_header = Course::where('parent_id',1)->where('is_delete','=',0)->get();
        $courses2_header = Course::where('parent_id',2)->where('is_delete','=',0)->get();
        View::share(['courses_header'=>$courses_header,'courses2_header'=>$courses2_header]);
        
    }
    public function resetPassword(Request $request, $token = null)
    {
    	$email = PasswordReset::where('token', $token)->first();
    	if ($email == null) 
    	{
    		return redirect()->route('f_home');
    	}
    	return view('front.createPassword')->with(['token' => $token, 'email' => $email->email]);
    }


    

    public function savePassword(Request $request)
    {
    	$validator = Validator::Make($request->all(),[

		'email' => 'required|email',
        'password' => 'min:6|required_with:confirm_password|same:confirm_password',
		'confirm_password' => 'min:6'

		]);

		$input = $request->all();
		if ($validator->passes()) 
		{
            $plain_password = !empty($input['password']) ? $input['password'] : '';
			DB::table('users')
        	->where('email', $input['email'])
        	->limit(1)
        	->update(array('password' => Hash::make($input['password']),'plain_password'=>$plain_password));

        	$PasswordReset = PasswordReset::where('token', $input['token'])->delete();

			return redirect()->route('f_home')->with('message', 'Password Create Successfully!');
		}

		return Redirect::back()->withErrors($validator);

		

    }
}
