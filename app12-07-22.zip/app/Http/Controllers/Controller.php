<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
//use App\Course;


class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    
    public function __construct()
	{
	    //its just a dummy data object.
	    //$user = User::all();
		//$courses_header = Course::where('parent_id',1)->where('is_delete','=',0)->get();
        //type 2
        //$courses2_header = Course::where('parent_id',2)->where('is_delete','=',0)->get();
	    // Sharing is caring
	    //View::share(['courses_header'=>$courses_header,'courses2_header'=>$courses2_header]);
	    //View::share('courses_header',$courses_header);
	}
}
