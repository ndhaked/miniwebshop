<?php
namespace App\Http\Controllers\parent;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Encryption\Encrypter;
use Crypt;
use DB;
use Auth;
use Hash;
use Session;
use Validator;
use App\ImageUpload;
use App\Course;
use App\StudentDetails;
use App\User;

class HomeController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');

        hasDashboardAccess('4');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $id = Auth::user()->id;
        $get_student = User::where('parent_id',$id)->get();
        $delete_student_get = User::where('parent_id',$id)->where('is_delete',1)->get();
        $active_student_get = User::where('parent_id',$id)->where('is_delete',0)->where('account_verified',1)->get();

        $all_student = count($get_student);
        $delete_student = count($delete_student_get);
        $active_student = count($active_student_get);

        /*return view('panel.parent.home',compact('all_users','teachers','students','activate_user'));*/
        return view('panel.parent.home',compact('all_student','delete_student','active_student'));
    }
    public function student_list()
    {
        $id = Auth::user()->id;
        $get_student = User::where('parent_id',$id)->where('is_delete',0)->where('account_verified',1)->get();
        return view('panel.parent.students_list',compact('get_student'));
    }
    public function student_login(Request $request)
    {

         $validator = Validator::make($request->all(), [
            'id' => 'required'
            ]);
        $get_student = User::where('id',$request->id)->where('is_delete',0)->where('account_verified',1)->first();

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $redirect_payment_due = false;
        if(Session::has('STUDENT_REDIRECT_PAYMENTDUE')){
            $redirect_payment_due = true;
            Session::forget('STUDENT_REDIRECT_PAYMENTDUE');
        }

       /* $password = decrypt($get_student->password);
        dd($password);*/ 
        if(!empty($get_student->email))
        {
            $data = array ('email' => $get_student->email,'password' => $get_student->plain_password,'user_type'=>3,'account_verified' => 1,'is_delete' => 0);
        }
        else
        {
            $data = array ('user_name' => $get_student->user_name,'password' => $get_student->plain_password,'user_type'=>3,'account_verified' => 1,'is_delete' => 0);
        }    
            //Session::flush();
        // dd($data);
        if (Auth::attempt ($data)) 
        { 
          
             // $id = Auth::user()->id;
             // dd($id);
            Session::put('p_login','p_login');
            return response()->json(['status' => 1,'data' => $data,'redirect_payment_due'=>$redirect_payment_due]);
        } else {
            return response()->json(['status' => 4011,'error1' => "Invalid data.Please try again."]);
             exit();
        }
    }

    public function addStudent(Request $request){

        $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:5|max:255',                        
                        'date_of_birth' => 'required|before:today',                       
                        'm_name_prefix' => 'required',
                        'school_type' => 'required'
                        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $parent = loggedInUser();

        $set_validation = explode("/",$request->date_of_birth);
        $dob = $set_validation[2].'-'.$set_validation[1].'-'.$set_validation[0];

        $count_users_s = User::orderBy('id', 'desc')->first();
        $user_count_s = $count_users_s->id + 1;
        $get_student_name = substr($request->name, 0, 4);
        $student_user_name = $get_student_name.$user_count_s;

        $date = date("Y-m-d H:i:s");

        $data = array('parent_id'=>$parent->id,'user_name'=>$student_user_name,'user_type'=>'3','name'=>$request->name,'plain_password'=>$parent->plain_password,'password'=>$parent->password,'account_verified'=>1,'new_user'=>'1','account_status'=>'active','created_at'=>$date);
        $s_id = DB::table('users')->insertGetId($data);

        $s_data = array('student_id'=>$s_id,'s_dob'=>$dob,'s_country'=>'','s_school_type'=>'','s_curriculum_type'=>'','s_other_curriculum'=>'','s_native_language'=>'','created_at'=>$date);
        DB::table('student_details')->insert($s_data);

        $maildata = array();
        $maildata['from_email'] = config('constants.FROM_EMAIL');
        $maildata['from_name']  = config('constants.FROM_NAME');
        $maildata['attachment']  = '';
        $maildata['student_name']  =  $request->m_name_prefix.'. '.$request->name;
        $maildata['reciever_email']  =   $parent->email;
        $maildata['reciever_name']  = $parent->name;
        $maildata['subject']  = 'JoinIvy - New Student Created';
        sendMail('email.parent_new_student',$maildata); 

        return response()->json(['status' => 1,'data' => $data]);

    }

    public function user_referral()
    {
        
        return view('panel.parent.user_referral');
    }
    
    
  
}

