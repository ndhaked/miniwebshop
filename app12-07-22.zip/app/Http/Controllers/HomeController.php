<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

class HomeController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $all_users = DB::table('users')->count();
        $teachers = DB::table('users')->where('user_type','2')->count();
        $students = DB::table('users')->where('user_type','3')->count();
        $activate_user = DB::table('users')->where('account_verified','1')->count();
        return view('panel.admin.home',compact('all_users','teachers','students','activate_user'));
    }
    public function course_offered()
    {
        
        return view('front.course_offered');
    }

    
  
}
