<?php

namespace App\Http\Controllers\admin;



use Illuminate\Http\Request;



use App\Http\Requests;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Mail;

use Validator;

use Hash;

use DB;

use App\Mail\ResetEmail;

use App\ImageUpload;

use App\TeacherDetails;

use App\User;

use App\PasswordReset;

use Carbon\Carbon;


class TeacherController extends Controller

{

	/**

     * Create a new controller instance.

     *

     * @return void

     */

    public function __construct()

    {

        $this->middleware('auth');

    }

    /**

     * Show the application dashboard.

     *

     * @return \Illuminate\Contracts\Support\Renderable

     */

    /*----course-----*/

    public function index()

    {

        $teacher_deactivet_list = User::join('teacher_details','teacher_details.teacher_id','users.id')

                                  ->where('users.is_delete','0')

                                  ->where('users.user_type','2')

                                  ->where('users.account_verified','2')

                                  ->get();

        $teacher_activet_list = User::join('teacher_details','teacher_details.teacher_id','users.id')

                                ->where('users.is_delete','0')

                                ->where('users.user_type','2')

                                ->where('users.account_verified','1')

                                ->get(); 

        $teacher_pending_list = User::join('teacher_details','teacher_details.teacher_id','users.id')

                                ->where('users.is_delete','0')

                                ->where('users.user_type','2')

                                ->where('users.account_verified','0')

                                ->get();

        $teacher_rejected_list = User::join('teacher_details','teacher_details.teacher_id','users.id')

                                ->where('users.is_delete','0')

                                ->where('users.user_type','2')

                                ->where('users.account_verified','10')

                                ->get();  
        User::where('new_user', '1')->where('user_type','2')->update(['new_user'=>'0']);                                      

        return view('panel.admin.teacher.index',compact('teacher_deactivet_list','teacher_activet_list','teacher_pending_list','teacher_rejected_list'));

    }

    public function teacher_add(Request $request)

    {

        $validator = Validator::make($request->all(), [

            'name' => 'required|string|min:5|max:255',

            'prefix' => 'required',
            'native_language' => 'required',

            'language_fluency' => 'required',

            'degree_major' => 'required',

            'current_profession' => 'required',


            'teaching_experience' => 'required',

            'grade_interested' => 'required',

            'subject_interested' => 'required',
            'country_code' => 'required',

            'email' => 'required|string|email|max:255|unique:users',

            'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',

            'cv' => 'required|max:10000|mimes:pdf,docx',

            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'            

        ]);

        if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }



        $date = date('Y-m-d h:i:s');

        $teacher_name = $request->prefix.'. '.$request->name;

        $email = $request->email;

        $mobile = $request->country_code.' '.$request->mobile;

        $native_language = $request->native_language;



        $t_r_name = $request->t_r_name;

        $t_r_mobile = $request->t_r_mobile;

        $t_r_email = $request->t_r_email;



        $language_fluency = $request->language_fluency;

        $degree_major = $request->degree_major;

        $current_profession = $request->current_profession;

        $school_name = $request->school_name;

        $professtion_name = $request->professtion_name;

        $teaching_experience = $request->teaching_experience;

        $grade_interested = $request->grade_interested;

        $subject_interested = $request->subject_interested;

        if(!empty($request->cv))

        {

            $profile_pic = ImageUpload::upload('front/CV/',$request->file('cv'));

            $cv = $profile_pic;

        }

        if(!empty($request->image))

        {

            $profile_pic = ImageUpload::upload('teachers/',$request->file('image'));

            $image = $profile_pic;

        }

        else

        {

            $image = "dummy-image.jpg";

        }

        $check_email = User::where('email',$request->email)->first();

        if(empty($check_email))

        {

            $password = Hash::make($request->password);

            $data = array('name'=>$teacher_name,'email'=>$email,'mobile'=>$mobile,'user_type'=>'2','referrer_name'=>$t_r_name,'referrer_mobile'=>$t_r_mobile,'referrer_email'=>$t_r_email,'created_at'=>$date);

            $id = User::insertGetId($data);



            $teacher_data = array('teacher_id'=>$id,'language_fluency'=>implode(',',$language_fluency),'t_native_language'=>$native_language,'degree_major_subjects'=>implode(',',$degree_major),'current_profession'=>$current_profession,'t_school_name'=>$school_name,'other_profession_name'=>$professtion_name,'teaching_experience'=>implode(',',$teaching_experience),'grade_interested'=>implode(',',$grade_interested),'subject_interested'=>implode(',',$subject_interested),'upload_cv'=>$cv,'image'=>$image,'created_at'=>$date);

            TeacherDetails::insert($teacher_data);

        }

        return response()->json(['status' => 1,'data' => $data]);

        /*$teacher_list = DB::table('users')->where('is_delete','0')->where('user_type','2')->get();

        return redirect()->route('teachers_list')->with(['teacher_list'=>$teacher_list]);*/

    }

     public function edit_teacher(Request $request)

    {

        $get_users = User::where('id',$request->user_id)->get(); 

        foreach ($get_users as $key => $get_user) 

        {

            $teacherDetails = TeacherDetails::where('teacher_id', $get_user->id)->get();   



            $get_user['email'] = $get_user->email;

            $name = explode('. ',$get_user->name);
            $get_user['prefix'] = $name[0];
            $get_user['name'] = $name[1];

            $mobile = explode(' ',$get_user->mobile);
            $get_user['country_code'] = $mobile[0];
            $get_user['mobile'] = $mobile[1];

            $get_user['image'] = $get_users[0]->image;

            $get_user['t_native_language'] = $teacherDetails[0]->t_native_language;

            $lng_flu = explode(',',$teacherDetails[0]->language_fluency);

            $lng_arr_make = array();

            foreach($lng_flu as $key => $value)

            {

               $language =  $value;

               array_push($lng_arr_make,$language);

            }

            $get_user['language_fluency'] = $lng_arr_make;

            

            $hig_qua = explode(',',$teacherDetails[0]->highest_qualification);

            $hei_arr_make = array();

            foreach($hig_qua as $key_hei => $value_hei)

            {

               $hig_qua_ar =  $value_hei;

               array_push($hei_arr_make,$hig_qua_ar);

            }

            $get_user['highest_qualification'] = $hei_arr_make;

            

            

            $dig_major = explode(',',$teacherDetails[0]->degree_major_subjects);

            $digree_major_arr_make = array();

            foreach($dig_major as $key_dig => $value_dig)

            {

               $digree_qua_ar =  $value_dig;

               array_push($digree_major_arr_make,$digree_qua_ar);

            }

            $get_user['degree_major_subjects'] = $digree_major_arr_make;

           

            $get_user['other_majors'] = $teacherDetails[0]->other_majors;

            $get_user['current_profession'] = $teacherDetails[0]->current_profession;

            $get_user['other_profession_name'] = $teacherDetails[0]->other_profession_name;

            $get_user['t_school_name'] = $teacherDetails[0]->t_school_name;



            $tea_exp = explode(',',$teacherDetails[0]->teaching_experience);

            $tea_exp_arr_make = array();

            foreach($tea_exp as $key_tec => $value_tec)

            {

               $tec_exp_ar =  $value_tec;

               array_push($tea_exp_arr_make,$tec_exp_ar);

            }

            $get_user['teaching_experience'] = $tea_exp_arr_make;

            $get_user['other_curriculum_type'] = $teacherDetails[0]->other_curriculum_type;
            $get_user['teacher_description'] = (!empty($teacherDetails[0]->teacher_description))?$teacherDetails[0]->teacher_description:'';



            $gra_inte = explode(',',$teacherDetails[0]->grade_interested);

            $value_grad_arr_make = array();

            foreach($gra_inte as $key_grad => $value_grad)

            {

               $value_grad_ar =  $value_grad;

               array_push($value_grad_arr_make,$value_grad_ar);

            }

            $get_user['grade_interested'] = $value_grad_arr_make;



            $sub_int = explode(',',$teacherDetails[0]->subject_interested);

            $sub_int_arr_make = array();

            foreach($sub_int as $key_sub => $value_sub)

            {

               $value_sub_int =  $value_sub;

               array_push($sub_int_arr_make,$value_sub_int);

            }

            $get_user['subject_interested'] = $sub_int_arr_make;    

            $get_user['other_subject'] = $teacherDetails[0]->other_subject;

            $get_user['upload_cv'] = $teacherDetails[0]->upload_cv;

         

        }

        

        return response()->json(['status' => 1,'success' => $get_users]);

    }


    public function viewteacher(Request $request)

    {

        $get_users = User::where('id',$request->user_id)->get(); 

        foreach ($get_users as $key => $get_user) 

        {

            $teacherDetails = TeacherDetails::where('teacher_id', $get_user->id)->get();   

            $get_user['email'] = $get_user->email;
            $get_user['created_at'] = $get_user->created_at;  

            $name = explode('. ',$get_user->name);
            $get_user['prefix'] = $name[0];
            $get_user['name'] = $name[1];

            $mobile = explode(' ',$get_user->mobile);
            $get_user['country_code'] = $mobile[0];
            $get_user['mobile'] = $mobile[1];

            $get_user['image'] = $get_users[0]->image;

            $get_user['t_native_language'] = $teacherDetails[0]->t_native_language;

            $lng_flu = explode(',',$teacherDetails[0]->language_fluency);

            $lng_arr_make = array();

            foreach($lng_flu as $key => $value)

            {

               $language =  $value;

               array_push($lng_arr_make,$language);

            }

            $get_user['language_fluency'] = $lng_arr_make;

            

            $hig_qua = explode(',',$teacherDetails[0]->highest_qualification);

            $hei_arr_make = array();

            foreach($hig_qua as $key_hei => $value_hei)

            {

               $hig_qua_ar =  $value_hei;

               array_push($hei_arr_make,$hig_qua_ar);

            }

            $get_user['highest_qualification'] = $hei_arr_make;

            

            

            $dig_major = explode(',',$teacherDetails[0]->degree_major_subjects);

            $digree_major_arr_make = array();

            foreach($dig_major as $key_dig => $value_dig)

            {

               $digree_qua_ar =  $value_dig;

               array_push($digree_major_arr_make,$digree_qua_ar);

            }

            $get_user['degree_major_subjects'] = $digree_major_arr_make;

           

            $get_user['other_majors'] = $teacherDetails[0]->other_majors;

            $get_user['current_profession'] = $teacherDetails[0]->current_profession;

            $get_user['other_profession_name'] = $teacherDetails[0]->other_profession_name;

            $get_user['t_school_name'] = $teacherDetails[0]->t_school_name;



            $tea_exp = explode(',',$teacherDetails[0]->teaching_experience);

            $tea_exp_arr_make = array();

            foreach($tea_exp as $key_tec => $value_tec)

            {

               $tec_exp_ar =  $value_tec;

               array_push($tea_exp_arr_make,$tec_exp_ar);

            }

            $get_user['teaching_experience'] = $tea_exp_arr_make;

            $get_user['other_curriculum_type'] = $teacherDetails[0]->other_curriculum_type;



            $gra_inte = explode(',',$teacherDetails[0]->grade_interested);

            $value_grad_arr_make = array();

            foreach($gra_inte as $key_grad => $value_grad)

            {

               $value_grad_ar =  $value_grad;

               array_push($value_grad_arr_make,$value_grad_ar);

            }

            $get_user['grade_interested'] = $value_grad_arr_make;



            $sub_int = explode(',',$teacherDetails[0]->subject_interested);

            $sub_int_arr_make = array();

            foreach($sub_int as $key_sub => $value_sub)

            {

               $value_sub_int =  $value_sub;

               array_push($sub_int_arr_make,$value_sub_int);

            }

            $get_user['subject_interested'] = $sub_int_arr_make;    

            $get_user['other_subject'] = $teacherDetails[0]->other_subject;

            $get_user['upload_cv'] = $teacherDetails[0]->upload_cv;

         

        }

        

        return response()->json(['status' => 1,'success' => $get_users]);

    }
    



    // activeTeacher

    public function activeTeacher()

    {

        $active = User::where('id', request('id'))

                  ->limit(1)

                  ->update(array('account_verified' => request('status')));



        if (request('status') == 1) 

        {   

            // token

            $token = md5(uniqid(rand(), true));

            $getName = User::where('id', request('id'))->first(); 

             

            $reset_email = array(); 

            $reset_email['email'] = $getName->email;

            $reset_email['token'] = $token;

            $reset_email['created_at'] = date("Y-m-d H:i:s");



            PasswordReset::insert($reset_email);



            // $objDemo = new \stdClass();

            // $objDemo->link = url('create/password/'.$token);

            // $objDemo->sender = 'JoinIvy';

            // $objDemo->receiver = $getName->name;

     

            // Mail::to($getName->email)->send(new ResetEmail($objDemo));

            $maildata = array();
            $maildata['confirmation_link'] = url('verification/'.$token);

            $maildata['from_email'] = config('constants.FROM_EMAIL');
            $maildata['from_name']  = config('constants.FROM_NAME');
            $maildata['attachment']  = '';
            $maildata['reciever_email']  =  $getName->email;
            $maildata['reciever_name']  = $getName->name;
            $maildata['subject']  = 'Registration Application Approved';
            sendMail('email.teacher_activation',$maildata); 

            return response()->json(['success'=>true, 'message'=> 'User Active Successfully'],200);



        }

        else

        {

            return response()->json(['success'=>true, 'message'=> 'User De-Active Successfully'],200);

        }

    }

    public function deactiveTeacher()

    {

        $active = User::where('id', request('id'))

                  ->limit(1)

                  ->update(array('account_verified' => request('status')));



        if (request('status') == 1) 

        {   

            // token

           /* $token = md5(uniqid(rand(), true));

            $getName = User::where('id', request('id'))->first(); 

             

            $reset_email = array(); 

            $reset_email['email'] = $getName->email;

            $reset_email['token'] = $token;

            $reset_email['created_at'] = date("Y-m-d H:i:s");



            PasswordReset::insert($reset_email);



            $objDemo = new \stdClass();

            $objDemo->link = 'http://joinivy.com/1/fht/create/password/'.$token;

            $objDemo->sender = 'JoinIvy';

            $objDemo->receiver = $getName->name;

     

            Mail::to($getName->email)->send(new ResetEmail($objDemo));

*/

            return response()->json(['success'=>true, 'message'=> 'User Deactive Successfully'],200);



        }

        else

        {

            return response()->json(['success'=>true, 'message'=> 'User De-Active Successfully'],200);

        }

    }

    public function rejectTeacher()

    {


        $active = User::where('id', request('id'))
                  ->limit(1)
                  ->update(array('account_verified' => request('status')));
        if (request('status') == 10) 
        {   
            // token
            $token = md5(uniqid(rand(), true));
            $getName = User::where('id', request('id'))->first(); 
            return response()->json(['success'=>true, 'message'=> 'User Deactive Successfully'],200);

        }
        else
        {
            return response()->json(['success'=>true, 'message'=> 'User De-Active Successfully'],200);
        }

    }



    public function updateTeacher(Request $request)

    {

       

        $validator = Validator::make($request->all(), [

            'name' => 'required|string|min:5|max:255',

            'prefix' => 'required',

            'native_language' => 'required',

            'language_fluency' => 'required',

            'highest_qualification' => 'required',

            'degree_major' => 'required',

            'current_profession' => 'required',


            'teaching_experience' => 'required',

            'grade_interested' => 'required',

            'subject_interested' => 'required',

            'email' => 'required|string|email|max:255',
            
            'country_code' => 'required',
            
            'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10'

        ]);

        if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }

        if(!empty($request->cv))

        {

            $profile_pic = ImageUpload::upload('front/CV/',$request->file('cv'));

            $cv = $profile_pic;

        }

        else

        {

            $cv = $request->cv_data;

        }

        if(!empty($request->image))

        {

            $profile_pic = ImageUpload::upload('teachers/',$request->file('image'));

            $image = $profile_pic;

        }

        else

        {

            $image = $request->profile_img;

        }
        $name = $request->prefix.'. '.$request->name;
        $mobile = $request->country_code.' '.$request->mobile;
        $data =  User::where('id', $request->user_id) 

                 ->limit(1)  

                 ->update(array('name'=>$name, 'email'=>$request->email, 'mobile'=>$mobile,'is_profiled_teacher'=>$request->profiled_teacher,'is_featured'=>$request->featured));

         

        $language_fluency = implode(',',$request->language_fluency);

        $highest_qualification = implode(',',$request->highest_qualification);

        $degree_major_subjects = implode(',',$request->degree_major);

        $teaching_experience = implode(',',$request->teaching_experience);

        $grade_interested = implode(',',$request->grade_interested);

        $subject_interested = implode(',',$request->subject_interested);



        TeacherDetails::where('teacher_id', $request->user_id) 

        ->limit(1)  

        ->update(array('t_native_language'=>$request->native_language,'language_fluency'=>$language_fluency,'highest_qualification'=>

            $highest_qualification,'degree_major_subjects'=>$degree_major_subjects,'other_majors'=>$request->other_majors,'current_profession'=>$request->current_profession,'other_profession_name'=>$request->other_profession_name,'t_school_name'=>$request->school_name,'teaching_experience'=>$teaching_experience,'other_curriculum_type'=>$request->other_curriculum_type,'grade_interested'=>$grade_interested,'subject_interested'=>$subject_interested,'other_subject'=>$request->other_subject,'upload_cv'=>$cv,'teacher_description'=>$request->teachers_details));
        
        $image_data = array('image'=>$image);
        User::where('id', $request->user_id)->update($image_data);
        

       return response()->json(['status' => 1,'data' => $data]);

    }

    

    /*-- new ----*/

     public function delete_Teacher($id)

    {

        $teacher_delete = TeacherDetails::where('teacher_id',$id)->update(['is_delete'=>'1']);

        $user_delete = User::where('id',$id)->update(['is_delete'=>'1']);

        return redirect()->route('teachers_list');

    }


    function createPasswordTeacher()
    {

        $teacher_password = User::where('id',request('user_id_01'))->update(['password'=>  Hash::make(request('password')) ]);
        return response()->json(['status' => 1]);

    }

    

}

