<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use Auth;
use Mail;
use App\Mail\ScheduleClassEmail;
use App\Mail\EventSessionEmails;

use App\ImageUpload;
use App\User;
use Validator;
use App\ScheduleClass;
use App\StudentDetails;
use App\TeacherDetails;
use App\ClassDetails;
use App\ClassStudentRequest;
use App\Classes;
use App\Course;
use Carbon\Carbon;
use App\AddAttendeeStudentClass;

use App\EventSession;
use App\EventSchedule;

use App\LessonCredit;
use App\Order;
use App\OrderItem;
use App\CronWizIQAddAttendee;
use PDF;
use Illuminate\Support\Str;


class ClassController extends Controller

{

	/**

     * Create a new controller instance.

     *

     * @return void

     */

    public function __construct()

    {

        $this->middleware('auth');

    }

    /**

     * Show the application dashboard.

     *

     * @return \Illuminate\Contracts\Support\Renderable

     */

    /*----course-----*/
    ///---old code--///*
    public function index_old()

    {

       $class_list = ScheduleClass::where('is_delete','0')->get();
       $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
       $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
       $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get();
       $one_to_one_class = ScheduleClass::where('is_delete','0')->where('class_type',1)->get();
       foreach ($one_to_one_class as $key => $value)
       {
           $teachers_name = TeacherDetails::where('teacher_id', $value->teacher_id)->where('is_delete','0')->get();
           foreach ($teachers_name as $key => $teacher_name)
           {
               $teacher_name_get = User::where('id', $teacher_name->teacher_id)->where('is_delete','0')->first();
               $value['teacher_name'] = $teacher_name_get->name;
           }
           $course = Course::where('id', $value->course_id)->where('is_delete','0')->get();
           foreach ($course as $key => $name)
           {
               $value['course_name'] = $name->course_name;
           }
           $course_details = ClassDetails::where('id', $value->class_name)->where('is_delete','0')->get();
           foreach ($course_details as $key_class => $name_class)
           {
               $value['class_name'] = $name_class->course_name;
           }
       }
       //dd($live_class);
       return view('panel.admin.class.one_to_one_class',compact('class_list','teacher_list','student_list','course_list','getNames','one_to_one_class'));
    }

    public function index()
    {   
      
       $session_status = sessionStatus();
       // $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
       $course_list = Course::leftjoin('class_details', 'class_details.course_id', '=', 'course.id') 
       ->where('course.is_delete','0')->where('course.parent_id','!=','0')->where('class_details.one_to_one_class','1')->select('course.*')->distinct()->get();
       $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
       $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get(); //->where('account_verified','1')
       $class_list = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')->where('schedule_class.class_type',1)
            ->where('event_sessions.is_delete','0')
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '>=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type','class_students_request.creator_id')
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->get();
      
      
       return view('panel.admin.class.one_to_one_class',compact('class_list','teacher_list','student_list','course_list','session_status'));
    }


    public function getOnetoOneClass(Request $request){
        $requestData = $request->all();  //dd($requestData);
        $json_data = getEventSessionPaginatedData($requestData);
              
        return response()->json($json_data);

    }

    public function addOnetoOneScheduleClass(){  

        $request = request()->all();
        $validator = Validator::make($request, [
            'student_name' => 'required_if:class_type,1',
            'batch_name' => 'required_if:class_type,3',
            'class_limit' => 'required_if:class_type,3',
            'teacher_name' => 'required',
            'time_duration' => 'required',
            'course_id' => 'required',
            'class_name' => 'required',
            'weekly_date' => 'required_if:occurance_type,4',
            'onetime_date' => 'required_if:occurance_type,0',
            'onetime_time' => 'required_if:occurance_type,0'
         ],
        [
          // 'days_of_week[].required_if' => 'The select days.',
          'course_id.required' => 'This field is required',
          'class_name.required' => 'This field is required',
          'teacher_name.required' => 'This field is required',
          'time_duration.required' => 'This field is required',
          'student_name.required_if' => 'This field is required',
          'batch_name.required_if' => 'This field is required',
          'class_limit.required_if' => 'This field is required',
          'weekly_date.required_if' => 'This field is required',
          'onetime_date.required_if' => 'This field is required',
          'onetime_time.required_if' => 'This field is required'
        ]);

        $days_of_week = array();

        if(isset($request['occurance_type']) && $request['occurance_type']=='4'){
            if(!isset($request['days_of_week'])){
                $days_of_week[] = 'Please select atleast one day and time' ;
            }
            else{ 
              foreach ($request['days_of_week'] as $key => $day) { //dd($request[$day.'_time']);
                  if(is_null($request[$day.'_time']) || $request[$day.'_time']==''){
                    $days_of_week[] = 'Please enter time for '.$day;

                  }
              }

            }
          }

          $student_limit = array(); 
          if(isset($request['class_type']) && $request['class_type']!='1'){ 
            if(intval($request['class_limit']) < count($request['student_name'])){
                $student_limit[] = 'Please add student within the given class limit' ;
            }
             
          }

        if(request('assistant_teacher_name') && (request('assistant_teacher_name') == request('teacher_name'))){
          $assistant_teacher_error = "Cannot be the same as teacher" ;
        }
        

        if ($validator->fails() || !empty($days_of_week) || !empty($student_limit) || isset($assistant_teacher_error)) 
        {  
            $error=json_decode($validator->errors());

            if(!empty($error)){
              if(!empty($days_of_week)){
                foreach ($days_of_week as $key => $err) {
                  $error->days_of_week[] =$err;
                }
              }
              
              if(!empty($student_limit)){
                foreach ($student_limit as $key => $err) {
                  $error->student_name = $err;
                }
              }
              if(isset($assistant_teacher_error)){
                $error->assistant_teacher_name = $assistant_teacher_error;
              }
            }
            else{
              if(!empty($days_of_week))
                $error['days_of_week']=$days_of_week;

              if(!empty($student_limit))
                $error['student_name'] = $student_limit;

              if(isset($assistant_teacher_error)){
                $error['assistant_teacher_name'] = $assistant_teacher_error;
              }
                 
            }
        
            
            
                  
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $start_date ='';
        if(isset($request['weekly_date'])){
          $start_date =$request['weekly_date'];
        }
        elseif(isset($request['onetime_date'])){
          $start_date =$request['onetime_date'];
        }
          

        $dob_get = explode("/",$start_date);
        $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

        $newtime ='';
        if(isset($request['time'])){
          $time_get1 = explode(" ",request('time'));
          $time_get2 = explode(":",$time_get1[0]);
          $newtime = $time_get2[0].':'.$time_get2[1];
        }
        


        $addClass = array();

        $date = $newDate.' '.$newtime;
         


         
        $addClass['date'] = $newDate.' '.$newtime;
        $addClass['course_id'] = request('course_id');
        $addClass['teacher_id'] =request('teacher_name');
        if(request('assistant_teacher_name')){
          $addClass['assistant_teacher_id'] = request('assistant_teacher_name');
        }
        $addClass['class_name'] = request('class_name');
        $addClass['about_class'] = !empty(request('about_class')) ? request('about_class') : "";
         $addClass['class_ids'] = '0';
         $addClass['class_payment_type'] = request('class_payment_type');
         $addClass['schedule_status'] = 'active';
         $addClass['student_schedule_class_url'] = '';
         $addClass['teacher_schedule_class_url'] = '';
         $addClass['class_type'] = request('class_type');
         $addClass['class_image'] = '';
         $addClass['duration'] = request('time_duration');
         $addClass['record'] = request('audio');
         $addClass['recording_url'] = '';
         $addClass['recording_type'] = request('is_recored');
         $addClass['created_at'] = $newDate.' '.$newtime;

         if(request('class_type')=='3'){
            $addClass['batch_name'] = request('batch_name');
            $addClass['class_limit'] = request('class_limit');
         }
         
         $schedule_class = new ScheduleClass;
         $schedule_class->insert($addClass);

        
        $schedule_class_id = DB::getPdo()->lastInsertId();

        if(isset($request['student_request_id']) && $request['student_request_id']!=""){
            $student_class_req = ClassStudentRequest::find($request['student_request_id']);
            $student_class_req->session_start_date  = $newDate;
            $student_class_req->schedule_class_id  = $schedule_class_id;
            $student_class_req->status ='1';
            $student_class_req->save();
        }
        else{

            $student_name = $request['student_name'];
            if(isset($request['student_name']) && !is_array($request['student_name']) && !empty($request['student_name'])){
              $student_name =array();
              $student_name[] = $request['student_name'];
            }
            if(!empty($student_name)){
                $add_students = array();
           
                foreach ($student_name as $key => $request_student_id) {
                  $updateClass = array();
                  $updateClass['student_id'] =$request_student_id;
                  $updateClass['creator_id'] = \Auth::user()->id;
                  $updateClass['class_types'] = request('class_type');
                  $updateClass['class_details_id'] = request('class_name');
                  $updateClass['schedule_class_id'] = $schedule_class_id;
                  $updateClass['session_start_date'] = $newDate;
                  $updateClass['session_end_date'] = '2019-12-01';
                  $updateClass['status'] ='1';
                  $updateClass['duration'] = request('time_duration');
                  $updateClass['schedule_class_url'] = '';
                  $updateClass['created_at'] = $newDate.' '.$newtime;

                  $add_students[] = $updateClass;
                  
              } 

              ClassStudentRequest::insert($add_students);
            }
            
          
        }
        
        createNewSchedue($request,$schedule_class_id);

               

        /******Send Email********/

        $data = getScheduleSessionData($schedule_class_id);
        $data['from_email'] = config('constants.FROM_EMAIL');
        $data['from_name']  = config('constants.FROM_NAME');
        $data['attachment']  = '';
 
        
        /************** student mail **********/
        if($request['class_type']=='1'){
          $student_id = request('student_name'); 
          $student = User::find($student_id);
          $this->sendSechduleMailStudents($student,$data,$request);
        }
        elseif($request['class_type']=='3'){
          $students = request('student_name'); 
          if(!empty($students)){
            foreach ($students as $key => $student_id) {
              $student = User::find($student_id);
              $this->sendSechduleMailStudents($student,$data,$request);
            }
          }
          
          
        }        

        /********* teacher mail************/
        $this->sendSechduleMailTeacher($data,$request);
        if(request('assistant_teacher_name')){
          $this->sendSechduleMailAssistantTeacher($data,$request);
        }
        //send mail
        
        // Mail::to($data['reciever_email'])->send(new EventSessionEmails($data));

        return response()->json(['success'=>true,"status"=> '1'], 200);


    }


    public function sendSechduleMailStudents($student,$data,$request){
    

      if($student->parent_id){
        $data['reciever_email']  = $student->parent->email;
        $data['reciever_name']  = $student->parent->name;   
        $data['student_name']  = $student->name; 
        $student_parent_template_onetime = 'email.event_onetime_parent_email';   
        $student_parent_template_recurring = 'email.event_recurring_session_parent_email'; 
      }
      else{
        $data['reciever_email']  = $student->email;
        $data['reciever_name']  = $student->name;  
        $student_parent_template_onetime = 'email.event_onetime_session_email';   
        $student_parent_template_recurring = 'email.event_recurring_session_email';  
      }

      if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
          $data['subject']  = 'JoinIvy - Weekly Session Created';
          sendMail($student_parent_template_recurring,$data);
      }
      elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){
           
          $data['subject']  = 'JoinIvy - One Time Session Created';
          sendMail($student_parent_template_onetime,$data);
      }

      /********* teacher mail************/
      

    }

    public function sendSechduleMailTeacher($data,$request){
      $data['reciever_email']  = $data['event_sessions']->user->email;
      $data['reciever_name']  = $data['event_sessions']->user->name;  

      if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
          $data['subject']  = 'JoinIvy - Weekly Session Created';
          sendMail('email.event_recurring_session_teacher_email',$data);
      }
      elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){             
          $data['subject']  = 'JoinIvy - One Time Session Created';
          sendMail('email.event_onetime_session_teacher_email',$data);
      }
    }

    public function sendSechduleMailAssistantTeacher($data,$request){
      $data['reciever_email']  = $data['event_sessions']->assistantTeacher->email;
      $data['reciever_name']  = $data['event_sessions']->assistantTeacher->name;  

      if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
          $data['subject']  = 'JoinIvy - Weekly Session Created';
          sendMail('email.event_recurring_session_teacher_email',$data);
      }
      elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){             
          $data['subject']  = 'JoinIvy - One Time Session Created';
          sendMail('email.event_onetime_session_teacher_email',$data);
      }
    }



     public function addOnetoClass()
     { 
        $validator = Validator::make(request()->all(), [
            'course_id' => 'required',
            'class_name' => 'required',
            'teacher_id' => 'required',
            'date' => 'required',
            'time' => 'required',
         ],
        [
          'course_id.required' => 'This field is required'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }


        include(app_path().'/edu_api/create.php');
        include(app_path().'/edu_api/AddAttendee.php');
        include(app_path().'/edu_api/Recurring.php');
        include(app_path().'/edu_api/View_Schedule.php');



        $access_key="nbaqEtPHk3E=";
        $secretAcessKey="fipzu+2E2bDJRRPjjE418w==";
        $webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";



        $dob_get = explode("/",request('date'));
        $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];
        $time_get1 = explode(" ",request('time'));
        $time_get2 = explode(":",$time_get1[0]);
        $newtime = $time_get2[0].':'.$time_get2[1];


        $addClass = array();

        $addClass['date'] = $newDate.' '.$newtime;
        $addClass['course_id'] = request('course_id');
        $addClass['teacher_id'] =request('teacher_id');
        $addClass['about_class'] = !empty(request('about_class')) ? request('about_class') : "";
        $addClass['class_name'] = request('class_id');

        $class = ClassDetails::where('id', request('class_id'))->where('is_delete', 0)->first(['course_name']);
        $class_name = $class->course_name;

        $duration = ClassStudentRequest::where('class_details_id',request('class_id'))->first();
        $duration_time = $duration->duration;

        $teacher_id = request('teacher_id');

        // dd($teacher_id);
        $teacher = User::where('id', $teacher_id)->where('is_delete', 0)->first();
        $teacher_name = $teacher->name;

        $student = User::where('id', $duration->student_id)->where('is_delete', 0)->first();
        $student_email = $student->email;


        $attendee_limit = '1';
        if(request('is_recored') == 1)
        {
          $create_recording = 'true';
        }
        else
        {
          $create_recording = 'false';
        }

        if(request('repeat_type') != 0)
       {
          $week = request('specific_week');
          $repeat_type = request('repeat_type');
          @$comma_days = implode(',',request('days_of_week'));
          $newDate1 = $dob_get[1].'/'.$dob_get[0].'/'.$dob_get[2];
          $newtime1 = $time_get2[0].':'.$time_get2[1];
          $date_1 = explode("/",request('class_end_date'));
          $class_end_date = $date_1[1].'/'.$date_1[0].'/'.$date_1[2];

          $obj =  RecurringClass($secretAcessKey, $access_key, $webServiceUrl, $newDate1, $newtime1, $teacher_id, $teacher_name, $week, $repeat_type, $comma_days, $duration_time, $attendee_limit, $class_end_date, $create_recording, $class_name);

          // dd($obj);
          
       }
       else
       {

          $obj =  ScheduleClass($secretAcessKey,$access_key,$webServiceUrl, $newDate, $newtime, $class_name, $duration_time, $teacher_id, $attendee_limit,$create_recording, $teacher_name);
       }


        if ($obj['errormsg'] != null) 
        {      
            return response()->json(['status' => 401,'errors' => $obj['errormsg']]);
            exit();
        }

        if (isset($obj['class_master_id'])) 
        {

          $view_schedule =  ViewSchedule($secretAcessKey,$access_key,$webServiceUrl,$obj['class_master_id']);

          // foreach ($view_schedule['class_ids'] as $key => $value) 
          // {
            
          //   $student_api_array=array();
          // $student_api_details['id']=request('class_students_request_id');
          // $student_api_details['name']=request('studentname');
          // array_push($student_api_array, $student_api_details);


          // $obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl,$obj['class_ids'],$student_api_array);

          // }
          // // dd($view_schedule);

        }
        // else
        // {

          $student_api_array=array();
          $student_api_details['id']=request('class_students_request_id');
          $student_api_details['name']=request('studentname');
          array_push($student_api_array, $student_api_details);


          $obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl,$obj['class_ids'],$student_api_array);
        // }
        


        



        

        
        if ($obj_student['errormsg'] != null) 
        {      
            return response()->json(['status' => 401,'errors' => $obj['errormsg']]);
            exit();
        }

        
        if(!empty(request('class_image')))
        {
             $profile_pic = ImageUpload::upload('front/class_images/',request('class_image'));
             $image = $profile_pic;
        }
        else
        {
          $image = 'course_default_img.png';
        }

        if (empty($view_schedule)) 
        {
           $addClass['class_ids'] = $obj['class_ids'];
           $addClass['student_schedule_class_url'] = $obj_student['student_attendee_url'];
           $addClass['teacher_schedule_class_url'] = $obj['presenter_urlTag'];
           $addClass['class_type'] = 1;
           $addClass['class_image'] = $image;
           $addClass['duration'] = request('one_to_one_duration');
           $addClass['record'] = request('audio');
           $addClass['recording_url'] = $obj['recording_url'];
           $addClass['recording_type'] = request('is_recored');
           $addClass['created_at'] = $newDate.' '.$newtime;
           if (isset($obj['class_master_id'])) 
           {
              $addClass['class_master_id'] = $obj['class_master_id'];
           }

           ScheduleClass::insert($addClass);
        }
        else
        {

          foreach($view_schedule['class_id'] as $key => $getclass)
          {  

            // print_r($view_schedule['presenter_url'][$i]);die;

             $addClass['class_ids'] = $view_schedule['class_id'][$key];
             $addClass['student_schedule_class_url'] = $obj_student['student_attendee_url'];
             $addClass['teacher_schedule_class_url'] = $view_schedule['presenter_url'][$key];
             $addClass['class_type'] = 1;
             $addClass['class_image'] = $image;
             $addClass['duration'] = request('one_to_one_duration');
             $addClass['record'] = request('audio');
             $addClass['recording_url'] = $view_schedule['recording_url'][$key];
             $addClass['recording_type'] = request('is_recored');
             $addClass['created_at'] = $newDate.' '.$newtime;
             if (isset($obj['class_master_id'])) 
             {
                $addClass['class_master_id'] = $obj['class_master_id'];
             }

            ScheduleClass::insert($addClass);

          } 
        }


        

        $schedule_class_id = DB::getPdo()->lastInsertId();
        $updateClass = array();
        $updateClass['schedule_class_id'] = $schedule_class_id;
        $updateClass['status'] ='1';
        $updateClass['schedule_class_url'] = '';
        ClassStudentRequest::where('id',request('class_students_request_id'))->update($updateClass);



        // $objDemo = new \stdClass();
        // $objDemo->sender = 'JoinIvy';
        // $objDemo->date = $newDate.' '.$newtime;
        // $objDemo->teacher_name = $teacher_name;
        // $objDemo->class_name = $class_name; 


        // Mail::to($student_email)->send(new ScheduleClassEmail($objDemo));
        return response()->json(['success'=>true,"status"=> '1'], 200);

       }



    public function editOnetoClass(Request $request)

    {


        $one_to_one_class = ScheduleClass::where('id',$request->id)->get();

        foreach ($one_to_one_class as $key => $value) 

        {


            $one_to_one_class['id'] = $request->id;

            $one_to_one_class['s_name'] = $value->student_id;

            $one_to_one_class['course'] = $value->course_id;

            $one_to_one_class['class_name'] = $value->class_name;

            $one_to_one_class['about_class'] = !empty($value->about_class) ? $value->about_class : "";

            $one_to_one_class['teacher_id'] = $value->teacher_id;

            $one_to_one_class['class_image'] = $value->class_image;

            $date_time_get = explode(" ",$value->date);

            $one_to_one_class['date'] =  date("d/m/Y",strtotime($date_time_get[0]));

            $one_to_one_class['time'] =  date("h:i",strtotime($date_time_get[1]));

        }

        return response()->json(['status' => 1,'success' => $one_to_one_class]);

    }


    public function editOnetoScheduleClass(){  

        $request = request()->all();
        $validator = Validator::make($request, [
            
            'teacher_name' => 'required',
            'onetime_date' => 'required_if:occurance_type_hidden,0',
            'onetime_time' => 'required_if:occurance_type_hidden,0'
           
         ],
        [

          'onetime_date.required_if' => 'This field is required',
          'onetime_time.required_if' => 'This field is required'
        ]);

        $days_of_week = array();

        if(isset($request['occurance_type_hidden']) && $request['occurance_type_hidden']=='4'){
            if(!isset($request['days_of_week'])){
                $days_of_week[] = 'Please select atleast one day and time' ;
            }
            else{ 
              foreach ($request['days_of_week'] as $key => $day) { //dd($request[$day.'_time']);
                  if(is_null($request[$day.'_time']) || $request[$day.'_time']==''){
                    $days_of_week[] = 'Please enter time for '.$day;

                  }
              }

            }
          }

          $student_limit = array(); 
          if(isset($request['class_type']) && $request['class_type']!='1'){ 
            if(intval($request['class_limit']) < count($request['student_name'])){
                $student_limit[] = 'Please add student within the given class limit' ;
            }
             
          }
        if(request('assistant_teacher_name') && (request('assistant_teacher_name') == request('teacher_name'))){
          $assistant_teacher_error = "Cannot be the same as teacher" ;
        }
        
        if ($validator->fails() || !empty($days_of_week) || !empty($student_limit) || isset($assistant_teacher_error)) 
        {  
            $error=json_decode($validator->errors());  
            if(!empty($error)){
              if(!empty($days_of_week)){
                foreach ($days_of_week as $key => $err) {
                  $error->days_of_week[] =$err;
                }
              }

                if(!empty($student_limit)){
                  foreach ($student_limit as $key => $err) {
                    $error->student_name = $err;
                  }
                }

              if(isset($assistant_teacher_error)){
                $error->assistant_teacher_name = $assistant_teacher_error;
              }
            }
            else{
                if(!empty($days_of_week))
                  $error['days_of_week']=$days_of_week;

                if(!empty($student_limit))
                  $error['student_name'] = $student_limit;

                if(isset($assistant_teacher_error)){
                  $error['assistant_teacher_name'] = $assistant_teacher_error;
                }
            }

             

            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $session = EventSession::find($request['one_to_one_class_id']);
        $schedule_class_data = $session->schedule_class;
        $new_start_date = explode(" ", $schedule_class_data->created_at);
        
        $schedule_class_id = $session->schedule_class_id;
        $session_start_date = $session->start_date;
        $eventSchedule = EventSchedule::where('schedule_class_id',$schedule_class_id)->first();

        if(isset($request['class_type']) && $request['class_type']!='1'){
          //save class limit
          $schedule_class_data->class_limit = $request['class_limit'];
          $schedule_class_data->save();

          $existing_students = ClassStudentRequest::where('schedule_class_id',$schedule_class_id)->where('is_delete','0')->pluck('student_id')->toArray();
          $all_students = $request['student_name'];

          $new_students = array_diff($all_students, $existing_students); 
          $deleted_students = array_diff($existing_students,$all_students); 
          $existing_students_minus_new_deletd = array_intersect($existing_students, $all_students); 

          if(!empty($deleted_students)){
            \DB::table('class_students_request')->where('schedule_class_id',$schedule_class_id)->whereIn('student_id',$deleted_students)->update(['is_delete' => '1']);
          }

          $schedule_class_data->about_class = !empty(request('about_class')) ? request('about_class') : "" ;
          $schedule_class_data->save();           
          

          if(!empty($new_students)){
              $add_students = array();
              $add_attendee = array();
              // $deleted_student_data = ClassStudentRequest::where('schedule_class_id',$schedule_class_id)->first();
              foreach ($new_students as $key => $request_student_id) {
                $updateClass = array();
                $updateClass['student_id'] = $request_student_id;
                $updateClass['creator_id'] = \Auth::user()->id;
                $updateClass['class_types'] = $request['class_type'];
                $updateClass['class_details_id'] = $schedule_class_data->class_name;
                $updateClass['schedule_class_id'] = $schedule_class_id;
                $updateClass['session_start_date'] = $new_start_date[0];
                $updateClass['session_end_date'] = '2019-12-01';
                $updateClass['status'] ='1';
                $updateClass['duration'] = $schedule_class_data->duration;
                $updateClass['schedule_class_url'] = '';
                $updateClass['created_at'] = date('Y-m-d H:i:s');

                $add_students[] = $updateClass;

                // if($session->wiz_class_id!=""){
                //   $new_student_name = User::find($request_student_id)->name;
                //   $add_attendee[] = ['id'=>$request_student_id,'name'=>$new_student_name];
                // }
                
            } 
 
            ClassStudentRequest::insert($add_students);
            // if($session->wiz_class_id!=""){
            //   $attendee[] = ['wiziq_class_id'=>$session->wiz_class_id,'student_data'=>serialize($add_attendee),'status'=>'0']; 
            //   CronWizIQAddAttendee::insert($attendee);
            // }
          }

        }
        
        
        $day = strtolower(date("l", strtotime($session_start_date)));
        
        if($day!='sunday'){
          $startoftheweek = date("Y-m-d", strtotime('last sunday', strtotime($session_start_date)));
        }
        else{
          $startoftheweek =$session_start_date;
        }
        

        $date = new \Carbon\Carbon;  
        if($date > $startoftheweek)
        {  
            $startoftheweek = date("Y-m-d");
        }  
       
        if($day!='saturday'){
          $endoftheweek = date("Y-m-d", strtotime('next saturday', strtotime($session_start_date)));
        }
        else{
          $endoftheweek =$session_start_date;
        }
        
        $dob_get = explode("-",$startoftheweek);
        $weekly_date = $dob_get[2].'/'.$dob_get[1].'/'.$dob_get[0];

        $request['time_duration'] = $session->duration;
        $request['occurance_type'] = $eventSchedule->schedule_type;
        $request['weekly_date'] = $weekly_date;



 
        if($eventSchedule->schedule_type=='4'){
            if(isset($request['edit_recurring']) && $request['edit_recurring']=='permanent'){
 
    //             $start_date ='';
    //             if(isset($request['weekly_date'])){
    //               $start_date =$request['weekly_date'];
    //             }
    //             elseif(isset($request['onetime_date'])){
    //               $start_date =$request['onetime_date'];
    //             }
                  
    // dd($start_date);
    //             $dob_get = explode("/",$start_date);
    //             $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

    //             $newtime ='';
    //             if(isset($request['time'])){
    //               $time_get1 = explode(" ",request('time'));
    //               $time_get2 = explode(":",$time_get1[0]);
    //               $newtime = $time_get2[0].':'.$time_get2[1];
    //             }
                


    //             $addClass = array();

    //             $date = $newDate.' '.$newtime;

    //             $event_sessions = EventSession::where('schedule_class_id',$schedule_class_id)->first();
                 
    //             $schedule_class = ScheduleClass::find(request('one_to_one_class_id'));         
    //             $schedule_class->date = $newDate.' '.$newtime;
    //             $schedule_class->course_id = request('course_id');
    //             $schedule_class->teacher_id =request('teacher_name');
    //             $schedule_class->class_name = request('class_name');
    //             $schedule_class->class_payment_type = request('class_payment_type');
    //             $schedule_class->duration = request('time_duration');
    //             $schedule_class->save();
                  
    //             $student_request = ClassStudentRequest::where('schedule_class_id',$schedule_class_id)->first();
    //             $student_request->class_details_id = request('class_name');
    //             $student_request->session_start_date = $newDate;
    //             $student_request->save();

                deleteSchedules($schedule_class_id);
                deleteSessions($schedule_class_id,$startoftheweek);

                createNewSchedue($request,$schedule_class_id);
            }
            else{
               deleteSchedulesfortheweek($request,$schedule_class_id,$startoftheweek,$endoftheweek);
            }

            
        }
        else{
            deleteSchedules($schedule_class_id);
            deleteSessions($schedule_class_id,$session_start_date);
            createNewSchedue($request,$schedule_class_id);

            
        }
        
 
        /******Send Email********/
        
        $data = getScheduleSessionData($schedule_class_id);
        $data['from_email'] = config('constants.FROM_EMAIL');
        $data['from_name']  = config('constants.FROM_NAME');
        $data['attachment']  = '';
        
        /************** student mail **********/

        //Existing users
        if($request['class_type']=='1'){
          $student = $data['event_sessions']->schedule_class->studentClassRequest->student;
          $this->sendEditSechduleMailStudents($student,$data,$request);
        }
        elseif($request['class_type']=='3'){
          // $students = request('student_name'); 
          foreach ($existing_students_minus_new_deletd as $key => $student_id) {
            $student = User::find($student_id);
            $this->sendEditSechduleMailStudents($student,$data,$request);
          }
          
        }

        //New added users
        if(!empty($new_students)){
          foreach ($new_students as $key => $request_student_id) {  
            $student = User::find($request_student_id);
            $this->sendSechduleMailStudents($student,$data,$request);  
          }
        }    

        /********* teacher mail************/
        $this->sendEditSechduleMailTeacher($data,$request);

        if(request('assistant_teacher_name')){
          $this->sendEditSechduleMailAssistantTeacher($data,$request);
        }
        

        


        // $event_sessions = EventSession::where('event_sessions.schedule_class_id',$schedule_class_id)
        //     ->join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
        //     ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
        //     ->where('schedule_class.is_delete','0')
        //     ->where('event_sessions.is_delete','0')
        //     ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type','class_students_request.creator_id','class_students_request.student_id','class_students_request.session_start_date')
        //     ->first()->toArray(); 


        // $event_schedule = EventSchedule::where('schedule_class_id',$schedule_class_id)->where('is_delete','0')->get()->toArray();
 
       

        

        return response()->json(['success'=>true,"status"=> '1'], 200);


    }

    public function sendEditSechduleMailStudents($student,$data,$request){
      if($student->parent_id){
          $data['reciever_email']  = $student->parent->email;
          $data['reciever_name']  = $student->parent->name;   
          $data['student_name']  = $student->name; 
          $student_parent_template_onetime = 'email.event_onetime_parent_edit_email';   
          $student_parent_template_recurring = 'email.event_recurring_session_parent_edit_email'; 
        }
        else{
          $data['reciever_email']  = $student->email;
          $data['reciever_name']  = $student->name;  
          $student_parent_template_onetime = 'email.event_onetime_session_edit_email';   
          $student_parent_template_recurring = 'email.event_recurring_session_edit_email';  
        }

        if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
            $data['subject']  = 'JoinIvy - Weekly Session Revised'; 
            sendMail($student_parent_template_recurring,$data);
        }
        elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){
             
            $data['subject']  = 'JoinIvy - One Time Session Rescheduled';
            sendMail($student_parent_template_onetime,$data);
        }

    }

    public function sendEditSechduleMailTeacher($data,$request){
        /********* teacher mail************/
        $data['reciever_email']  = $data['event_sessions']->user->email;
        $data['reciever_name']  = $data['event_sessions']->user->name;  

        if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
            $data['subject']  = 'JoinIvy - Weekly Session Revised';
            sendMail('email.event_recurring_session_edit_teacher_email',$data);
        }
        elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){             
            $data['subject']  = 'JoinIvy - One Time Session Rescheduled';
            sendMail('email.event_onetime_session_teacher_edit_email',$data);
        }
    }

    public function sendEditSechduleMailAssistantTeacher($data,$request){
        /********* teacher mail************/
        $data['reciever_email']  = $data['event_sessions']->assistantTeacher->email;
        $data['reciever_name']  = $data['event_sessions']->assistantTeacher->name;  

        if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
            $data['subject']  = 'JoinIvy - Weekly Session Revised';
            sendMail('email.event_recurring_session_edit_teacher_email',$data);
        }
        elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){             
            $data['subject']  = 'JoinIvy - One Time Session Rescheduled';
            sendMail('email.event_onetime_session_teacher_edit_email',$data);
        }
    }

    public function sendOneToOneEditMails($schedule_class_id,$request){
        $data = getScheduleSessionData($schedule_class_id);
        $data['from_email'] = config('constants.FROM_EMAIL');
        $data['from_name']  = config('constants.FROM_NAME');
        $data['attachment']  = '';

        $student = $data['event_sessions']->schedule_class->studentClassRequest->student;
        
        /************** student mail **********/
        if($student->parent_id){
          $data['reciever_email']  = $student->parent->email;
          $data['reciever_name']  = $student->parent->name;   
          $data['student_name']  = $student->name; 
          $student_parent_template_onetime = 'email.event_onetime_parent_edit_email';   
          $student_parent_template_recurring = 'email.event_recurring_session_parent_edit_email'; 
        }
        else{
          $data['reciever_email']  = $student->email;
          $data['reciever_name']  = $student->name;  
          $student_parent_template_onetime = 'email.event_onetime_session_edit_email';   
          $student_parent_template_recurring = 'email.event_recurring_session_edit_email';  
        }

        if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
            $data['subject']  = 'JoinIvy - Weekly Session Rescheduled'; 
            sendMail($student_parent_template_recurring,$data);
        }
        elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){
             
            $data['subject']  = 'JoinIvy - One Time Session Rescheduled';
            sendMail($student_parent_template_onetime,$data);
        }

        /********* teacher mail************/
        $data['reciever_email']  = $data['event_sessions']->user->email;
        $data['reciever_name']  = $data['event_sessions']->user->name;  

        if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
            $data['subject']  = 'JoinIvy - Weekly Session Rescheduled';
            sendMail('email.event_recurring_session_edit_teacher_email',$data);
        }
        elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){             
            $data['subject']  = 'JoinIvy - One Time Session Rescheduled';
            sendMail('email.event_onetime_session_teacher_edit_email',$data);
        }
    }



    public function viewOnetoClass(Request $request)

    {


        $one_to_one_class = ScheduleClass::where('id',$request->id)->get();

        foreach ($one_to_one_class as $key => $value) 

        {

            $one_to_one_class['id'] = $request->id;

            $one_to_one_class['s_name'] = $value->student_id;

            $one_to_one_class['course'] = $value->course_id;

            $one_to_one_class['class_name'] = $value->class_name;

            $one_to_one_class['about_class'] = !empty($value->about_class) ? $value->about_class : "";

            $one_to_one_class['teacher_id'] = $value->teacher_id;

            $one_to_one_class['class_image'] = $value->class_image;

            $date_time_get = explode(" ",$value->date);

            $one_to_one_class['date'] =  date("d/m/Y",strtotime($date_time_get[0]));

            $one_to_one_class['time'] =  date("h:i",strtotime($date_time_get[1]));

        }

        return response()->json(['status' => 1,'success' => $one_to_one_class]);

    }

    public function viewOnetoScheduleClass(Request $request)

    {

        $event_sessions = EventSession::where('event_sessions.id',$request->id)
            ->join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->leftjoin('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_type','schedule_class.class_limit','schedule_class.batch_name','schedule_class.about_class','schedule_class.class_name', 'schedule_class.class_payment_type','class_students_request.creator_id','class_students_request.student_id','class_students_request.session_start_date')
            ->first()->toArray(); 

        $session_start_date = $event_sessions['start_date'];
        $day = strtolower(date("l", strtotime($session_start_date)));
        
        if($day!='sunday'){
          $startoftheweek = date("Y-m-d", strtotime('last sunday', strtotime($session_start_date)));
        }
        else{
          $startoftheweek =$session_start_date;
        }


        $event_schedule = EventSchedule::where('schedule_class_id',$event_sessions['schedule_class_id'])->get()->toArray();
 
        $all_students = array();      
        if($event_sessions['class_type']!='1'){
          $all_students = ClassStudentRequest::where('schedule_class_id',$event_sessions['schedule_class_id'])->where('status','1')->where('is_delete','0')->pluck('student_id')->toArray();
          
        }

        

        return response()->json(['status' => 1,'event_schedule' => $event_schedule,'event_sessions' => $event_sessions,'startoftheweek' => $startoftheweek,'all_students' => $all_students]);

    }

    public function viewBatchScheduleClass(Request $request)

    {

        $event_sessions = ClassStudentRequest::where('class_students_request.id',$request->id)
            ->join('schedule_class', 'schedule_class.id', '=', 'class_students_request.schedule_class_id') 
            ->leftjoin('event_sessions', 'event_sessions.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_type','schedule_class.class_limit','schedule_class.batch_name','schedule_class.class_name', 'schedule_class.class_payment_type','class_students_request.creator_id','class_students_request.student_id','class_students_request.session_start_date')
            ->first()->toArray(); 
// dd($event_sessions);
        $session_start_date = $event_sessions['start_date'];
        $day = strtolower(date("l", strtotime($session_start_date)));
        
        if($day!='sunday'){
          $startoftheweek = date("Y-m-d", strtotime('last sunday', strtotime($session_start_date)));
        }
        else{
          $startoftheweek =$session_start_date;
        }


        $event_schedule = EventSchedule::where('schedule_class_id',$event_sessions['schedule_class_id'])->where('is_delete','0')->get()->toArray();
 
        $all_students = array();      
        if($event_sessions['class_type']!='1'){
          $all_students = ClassStudentRequest::where('schedule_class_id',$event_sessions['schedule_class_id'])->where('status','1')->where('is_delete','0')->pluck('student_id')->toArray();
          
        }

        

        return response()->json(['status' => 1,'event_schedule' => $event_schedule,'event_sessions' => $event_sessions,'startoftheweek' => $startoftheweek,'all_students' => $all_students]);

    }

    public function editBatchScheduleClass(Request $request){
      $request = request()->all();  
      $student_request = ClassStudentRequest::find($request['student_request_id']); 
      $class_limit = $student_request->scheduleClass->class_limit;
      $enrolled_students = ClassStudentRequest::where('schedule_class_id',$student_request->schedule_class_id)->where('status','1')->where('is_delete','0')->count();
 
      if($enrolled_students > intval($class_limit)){
        $errors['student_name'] = 'Cannot enroll students more than '.$class_limit;
        return response()->json(['status' => 401,'error' => $errors]);
      }
      
      $student_request->status = '1';
      $student_request->save();

      return response()->json(['status' => 1,'success' => true]);
    }

    



    public function updateOnetoClass(Request $request)

    {


        /*$validator = Validator::make($request->all(), [


            'course_id' => 'required',

            'class_name' => 'required',

            'about_class' => 'required',

            'teacher_id' => 'required',

            'date' => 'required',

            'time' => 'required'

        ]);
*/
        $validator = Validator::make($request->all(), [


            'course_id' => 'required',

            'class_name' => 'required',

            'teacher_id' => 'required',

            'date' => 'required',

            'time' => 'required'

        ]);
  
        if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }

        if(!empty($request->class_image))

        {

            $profile_pic = ImageUpload::upload('front/class_images/',$request->file('class_image'));

            $image = $profile_pic;

        }

        else

        {

            $image = $request->old_img;

        }




         $dob_get = explode("/",request('date'));

         $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

         $time_get1 = explode(" ",request('time'));

         $time_get2 = explode(":",$time_get1[0]);

         $newtime = $time_get2[0].':'.$time_get2[1].':'.'00';

         $updateClass = array();


         $updateClass['course_id'] = request('course_id');

         $updateClass['teacher_id'] =request('teacher_id');

         $updateClass['about_class'] = !empty(request('about_class')) ? request('about_class') : "" ;

         $updateClass['class_name'] = request('class_name');

         $updateClass['class_image'] = $image;

         $updateClass['record'] = request('audio');

         $updateClass['recording_type'] = request('is_recored');

         $updateClass['date'] = $newDate.' '.$newtime;

         $updateClass['created_at'] = $newDate.' '.$newtime;

          


         ScheduleClass::where('id',$request->one_to_one_class_id)->update($updateClass);

         return response()->json(['status' => 1,'data' => $updateClass]);

    }



    public function deleteOnetoClass($id)

    {

        // $teacher_delete = ScheduleClass::where('id',$id)->update(['is_delete'=>'1']);
        deleteClass($id);
        // return redirect()->route('one_to_one_class');
        return redirect()->back();

    }

    public function cancelClasses($id)
    {
        $cancel = (isset($_GET['cancel'])) ? $_GET['cancel'] :'';
        if($cancel=='schedule'){
          cancelSessions($id);
        }
        else{
          cancelEventClass($id);
        }
        return redirect()->back();

    }

    

    public function get_course_one_to_one(Request $request)
    {
      $class_type = (isset($request->class_type)) ? $request->class_type:'';
      if($class_type=='1')
        $course_list = ClassDetails::where('is_delete','0')->where('class_details.one_to_one_class','1')->where('course_id',$request->course_id)->get();
      elseif($class_type=='2')
        $course_list = ClassDetails::where('is_delete','0')->where('class_details.buddy_class','1')->where('course_id',$request->course_id)->get();
      elseif($class_type=='3')
        $course_list = ClassDetails::where('is_delete','0')->where('class_details.batch_class','1')->where('course_id',$request->course_id)->get();
      else
        $course_list = ClassDetails::where('is_delete','0')->where('course_id',$request->course_id)->get();
      
      $course_name_list = array();
      foreach ($course_list as $key => $value) 
      {
        $data['name'] = $value->course_name;
        $data['id'] = $value->id;
        array_push($course_name_list,$data);
      }
      //dd($course_name_list);
       return response()->json(['status' => 1,'success' => $course_name_list]);
    }



    /*----------------- Group Class ----------------*/

    public function group_class()
    {

        $class_list = Classes::where('is_delete','0')->get();

        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();

        $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();

       // Group Class Data

       $group_class = ScheduleClass::where('is_delete','0')->where('class_type',2)->get();
       //dd($one_to_one_class);
       foreach ($group_class as $key => $value)

       {

           
           // teacher name

           $teachers_name = TeacherDetails::where('teacher_id', $value->teacher_id)->where('is_delete','0')->get();

           foreach ($teachers_name as $key => $teacher_name)

           {

               $teacher_name_get = User::where('id', $teacher_name->teacher_id)->where('is_delete','0')->first();

               $value['teacher_name'] = $teacher_name_get->name;

           }

           //get course_name

           $course = Course::where('id', $value->course_id)->where('is_delete','0')->get();

           foreach ($course as $key => $name)

           {

               $value['course_name'] = $name->course_name;

           }
           $course_details = ClassDetails::where('id', $value->class_name)->where('is_delete','0')->get();
           foreach ($course_details as $key_class => $name_class)
           {
               $value['class_name'] = $name_class->course_name;
           }

           try{ 
             // Get Student Name
             $s_name = ClassStudentRequest::where('schedule_class_id',$value->id)->first();
             $user = User::where('id', $s_name->student_id)->first();
             $value['student_name'] = $user->name;
           }
           catch(\Exception $e){
          }


       }       

       // dd($group_class);

        return view('panel.admin.class.group_class',compact('class_list','teacher_list','course_list','group_class'));

    }


    // Add Group Class
    public function addGroupClass(Request $request)
    {

        //dd(request()->all());
        /*$validator = Validator::make($request->all(), [


            'course_id' => 'required',

            'class_limit' => 'required',

            'class_name' => 'required',

            'about_class' => 'required',

            'teacher_id' => 'required',

            'date' => 'required',

            'time' => 'required',
            'class_image' => 'required|image|mimes:jpeg,png,jpg',

        ],
        [
          'course_id.required' => 'The select course field is required.',
          'teacher_id.required' => 'The select teacher field is required.'
        ]);*/
        $validator = Validator::make($request->all(), [


            'course_id' => 'required',

            'class_limit' => 'required',

            'class_name' => 'required',

            'teacher_id' => 'required',

            'date' => 'required',

            'time' => 'required',

        ],
        [
          'course_id.required' => 'This field is required',
          'teacher_id.required' => 'This field is required'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }


           $dob_get = explode("/",request('date'));

           $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

           $time_get1 = explode(" ",request('time'));

           $time_get2 = explode(":",$time_get1[0]);

           $newtime = $time_get2[0].':'.$time_get2[1].':'.'00';

           //$newTime = date("h:i", strtotime(request('time')));

           $addClass = array();

           $addClass['course_id'] = request('course_id');
           $addClass['teacher_id'] =request('teacher_id');
           $addClass['about_class'] = !empty(request('about_class')) ? request('about_class') : "";
           $addClass['class_name'] = request('class_name');
           $addClass['class_limit'] = request('class_limit');

           //$image = request('class_image');

           //dd($image);

           if(!empty(request('class_image')))

           {

               $profile_pic = ImageUpload::upload('front/class_images/',request('class_image'));

               $image = $profile_pic;

           }

           else

           {

               $image = 'course_default_img.png';

           }

           $addClass['class_type'] = 2;

           $addClass['class_image'] = $image;

           $addClass['record'] = request('audio');

           $addClass['recording_type'] = request('is_recored');

           $addClass['date'] = $newDate.' '.$newtime;

           $addClass['created_at'] = $newDate.' '.$newtime;

           ScheduleClass::insert($addClass);

           return response()->json(['success'=>true,'status' => 1], 200);

    }


    // editGroupClass
    public function editGroupClass(Request $request)
    {
        $editGroupClass = ScheduleClass::where('id',$request->id)->get();
        foreach ($editGroupClass as $key => $value) 
        {
            $editGroupClass['id'] = $request->id;
            $editGroupClass['course_id'] = $value->course_id;
            $editGroupClass['teacher_id'] = $value->teacher_id;
            $editGroupClass['class_limit'] = $value->class_limit;
            $editGroupClass['about_class'] = !empty($value->about_class) ? $value->about_class : "" ;
            $editGroupClass['class_name'] = $value->class_name;
            $editGroupClass['class_image'] = $value->class_image;
            $date_time_get = explode(" ",$value->date);
            $editGroupClass['date'] =  date("d/m/Y",strtotime($date_time_get[0]));
            $editGroupClass['time'] =  date("h:i",strtotime($date_time_get[1]));

        }

        return response()->json(['status' => 1,'success' => $editGroupClass]);
    }


    // updateGroupClass
    public function updateGroupClass(Request $request)
    {
      /*$validator = Validator::make($request->all(), [

            'course_id' => 'required',
            'class_limit' => 'required',
            'class_name' => 'required',
            'about_class' => 'required',
            'teacher_id' => 'required',
            'date' => 'required',
            'time' => 'required',

        ],
        [
          'course_id.required' => 'The select course field is required.',
          'teacher_id.required' => 'The select teacher field is required.'
        ]);*/
        $validator = Validator::make($request->all(), [

            'course_id' => 'required',
            'class_limit' => 'required',
            'class_name' => 'required',
            'teacher_id' => 'required',
            'date' => 'required',
            'time' => 'required',

        ],
        [
          'course_id.required' => 'This field is required',
          'teacher_id.required' => 'This field is required'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        if(!empty($request->class_image))

        {

            $profile_pic = ImageUpload::upload('front/class_images/',$request->file('class_image'));

            $image = $profile_pic;

        }

        else

        {

            $image = $request->old_img;

        }




         $dob_get = explode("/",request('date'));

         $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

         $time_get1 = explode(" ",request('time'));

         $time_get2 = explode(":",$time_get1[0]);

         $newtime = $time_get2[0].':'.$time_get2[1].':'.'00';

         $updateClass = array();


         $updateClass['course_id'] = request('course_id');

         $updateClass['teacher_id'] =request('teacher_id');
         $updateClass['class_limit'] =request('class_limit');

         $updateClass['about_class'] = !empty(request('about_class')) ? request('about_class') : "";

         $updateClass['class_name'] = request('class_name');

         $updateClass['class_image'] = $image;

         $updateClass['record'] = request('audio');

         $updateClass['recording_type'] = request('is_recored');

         $updateClass['date'] = $newDate.' '.$newtime;

         $updateClass['created_at'] = $newDate.' '.$newtime;

          


         ScheduleClass::where('id',$request->group_class_id)->update($updateClass);

         return response()->json(['status' => 1,'data' => $updateClass]);

    }


    // viewGroupClass
    public function viewGroupClass(Request $request)
    {
        $group_class = ScheduleClass::where('id',$request->id)->get();

        foreach ($group_class as $key => $value) 

        {

            $group_class['id'] = $request->id;
            $group_class['course_id'] = $value->course_id;
            $group_class['teacher_id'] = $value->teacher_id;
            $group_class['class_limit'] = $value->class_limit;
            $group_class['about_class'] = !empty($value->about_class) ? $value->about_class : "";
            $group_class['class_name'] = $value->class_name;
            $group_class['class_image'] = $value->class_image;
            $date_time_get = explode(" ",$value->date);
            $group_class['date'] =  date("d/m/Y",strtotime($date_time_get[0]));
            $group_class['time'] =  date("h:i",strtotime($date_time_get[1]));

        }

        return response()->json(['status' => 1,'success' => $group_class]);
    }

    // deleteGroupClass
    public function deleteGroupClass($id)
    {

      $teacher_delete = ScheduleClass::where('id',$id)->update(['is_delete'=>'1']);

      return redirect()->back();

    }

    public function get_course_group(Request $request)
    {
      $course_list = ClassDetails::where('is_delete','0')->where('course_id',$request->course_id)->get();
      $course_name_list = array();
      foreach ($course_list as $key => $value) 
      {
        $data['name'] = $value->course_name;
        $data['id'] = $value->id;
        array_push($course_name_list,$data);
      }
      //dd($course_name_list);
       return response()->json(['status' => 1,'success' => $course_name_list]);
    }
    /*----------------- Group Class End ----------------*/



    /*----------------- Reschedule Class Start ----------------*/

    public function reschedule_class()
    {

        $upcoming_class_list =  ScheduleClass::where('schedule_class.is_delete',0)->where('status','=',3)
                            ->select('schedule_class.id as schedule_id','schedule_class.*','users.*','course.*','class_details.*')
                            ->leftJoin('users', 'schedule_class.teacher_id', '=', 'users.id')
                            ->leftJoin('course', 'schedule_class.course_id', '=', 'course.id')
                            ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
                            ->get();
        
              

         $currentDate = date('Y-m-d');

          $teacher_list = User::where('is_delete','0')
                      ->where('user_type','2')
                      ->where('account_verified','1')
                      ->leftJoin('available_month', 'users.id' ,'=', 'available_month.teacher_id')
                      ->whereDate('available_month.end_date', '>=', $currentDate)
                      ->select('users.*','available_month.id as available_id')
                      ->get();
                                   
        return view('panel.admin.class.reschedule_class',compact('upcoming_class_list','teacher_list'));
    }

    public function upcoming_class()
    {

         //  $get_all_upcoming_class =  DB::table('schedule_class','schedule_class.date as date1')->where('schedule_class.status',0)->where('schedule_class.is_delete',0)
         //    ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
         //    ->leftJoin('course', 'schedule_class.course_id', '=', 'course.id')
         //    ->leftJoin('users', 'schedule_class.teacher_id', '=', 'users.id')
         //    ->leftJoin('class_students_request', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')->where('class_students_request.status',1)
         //    ->select('schedule_class.*','course.*','users.*','class_details.course_name AS class_name1','class_students_request.student_id','class_students_request.id as class_students_request_id')
         //    ->get();

        
         // // dd($get_all_upcoming_class);
         // foreach ($get_all_upcoming_class as $key => $value) 
         // {
         //    $studentname = User::where('id', $value->student_id)->first();
         //    $value->student_name = $studentname->name;
         // }
         // 
         $get_all_upcoming_class = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '>=', date('Y-m-d H:i:s'))
            ->where('event_sessions.is_delete','0')
            // ->where('class_students_request.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type', 'schedule_class.class_type', 
              DB::raw("if(CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)<=NOW(), 'live', event_sessions.status) as status"))
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->get();                 
          

        // $currentDate = date('Y-m-d');
        // $teacher_list = User::where('is_delete','0')
        //               ->where('user_type','2')
        //               ->where('account_verified','1')
        //               ->leftJoin('available_month', 'users.id' ,'=', 'available_month.teacher_id')
        //               ->whereDate('available_month.end_date', '>=', $currentDate)
        //               ->select('users.*','available_month.id as available_id')
        //               ->get();
        $session_status = sessionStatus();
       $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
       $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
       $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get(); //->where('account_verified','1')
       
        $class_type=classType();

        return view('panel.admin.class.upcoming_class',compact('class_type','class_list','teacher_list','student_list','course_list','get_all_upcoming_class','session_status'));

    }

    public function getupcoming_class(Request $request){
        $requestData = $request->all();  //dd($requestData);
        $json_data = getEventSessionPaginatedData($requestData,$cond);
              
        return response()->json($json_data);

    }



    public function past_class()

    {

        $class_list = Classes::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();


        
        
        // $get_all_live_class =  DB::table('schedule_class','schedule_class.date as date1')->where('schedule_class.status',1)->where('schedule_class.is_delete',0)
        //     ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
        //     ->leftJoin('class_students_request', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')->where('class_students_request.status',1)
        //     ->select('schedule_class.*','class_details.course_name as class_name','class_students_request.student_id')
        //     ->get();

        // // dd($get_all_live_class->toArray());
        //  foreach ($get_all_live_class as $key => $value) 
        //  {
        //     $studentname = User::where('id', $value->student_id)->first();
        //     $value->student_name = $studentname->name;
        //  }

        /* $get_all_live_class = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.status','!=','canceled')
            // ->whereIn('event_sessions.status',['completed'])
            ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '<=', date('Y-m-d H:i:s'))
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type')
            ->orderBy('event_sessions.start_date','desc')
            ->orderBy('event_sessions.start_time','desc')
            ->get();  */
        $class_type=classType();

        return view('panel.admin.class.past_class',compact('class_list','class_type','teacher_list','course_list'));

    }

        


    // ==================  Batch Class CRUD  ========================= //

    public function batch_class()
    {
       $session_status = sessionStatus();
       $course_list = Course::leftjoin('class_details', 'class_details.course_id', '=', 'course.id') 
       ->where('course.is_delete','0')->where('course.parent_id','!=','0')->where('class_details.batch_class','1')->select('course.*')->distinct()->get(); 
       $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
       $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get();

        // Batch Class Data
        $class_list = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')->where('schedule_class.class_type',3)
            ->where('event_sessions.is_delete','0')
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '>=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type')
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->get();

       // $batch_class = ScheduleClass::where('is_delete','0')->where('class_type',3)->get();
       // //dd($one_to_one_class);
       // foreach ($batch_class as $key => $value)

       // {

           
       //     // teacher name

       //     $teachers_name = TeacherDetails::where('teacher_id', $value->teacher_id)->where('is_delete','0')->get();

       //     foreach ($teachers_name as $key => $teacher_name)

       //     {

       //         $teacher_name_get = User::where('id', $teacher_name->teacher_id)->where('is_delete','0')->first();

       //         $value['teacher_name'] = $teacher_name_get->name;

       //     }

       //     //get course_name

       //     $course = Course::where('id', $value->course_id)->where('is_delete','0')->get();

       //     foreach ($course as $key => $name)

       //     {

       //         $value['course_name'] = $name->course_name;

       //     }
       //     $course_details = ClassDetails::where('id', $value->class_name)->where('is_delete','0')->get();
       //     foreach ($course_details as $key_class => $name_class)
       //     {
       //         $value['class_name'] = $name_class->course_name;
       //     }

       // } 

        return view('panel.admin.class.batch_class',compact('course_list','teacher_list','course_list','class_list','student_list','session_status'));

    }

    public function getBatchStudents(Request $request){
        $requestData = $request->all();
        $schedule_class_id = $requestData['schedule_class_id'];
        $batch_name = ScheduleClass::find($schedule_class_id)->batch_name;
        $students = ClassStudentRequest::join('users', 'users.id', '=', 'class_students_request.student_id') 
            ->where('class_students_request.schedule_class_id',$schedule_class_id)->where('class_students_request.is_delete','0')->where('class_students_request.status','1')
            ->select('users.name',DB::raw('(CASE WHEN users.parent_id != "0" THEN (select email from users as parentuser where parentuser.id=users.parent_id) ELSE users.email END) AS email'))
            ->get();

        return response()->json(['success'=>true,'status' => 1,'students' => $students,'batch_name' => $batch_name], 200);
    }


    // Add Group Class
    public function addBatchClass(Request $request)
    {
        // dd(request('repeat_type'));
        // dd(request()->all());
        /*$validator = Validator::make($request->all(), [


            'course_id' => 'required',

            'class_limit' => 'required',

            'class_name' => 'required',

            'about_class' => 'required',

            'teacher_id' => 'required',

            'date' => 'required',

            'time' => 'required',
            'class_image' => 'required|image|mimes:jpeg,png,jpg',

        ],
        [
          'course_id.required' => 'The select course field is required.',
          'teacher_id.required' => 'The select teacher field is required.'
        ]);*/
        $validator = Validator::make($request->all(), [


            'course_id' => 'required',

            'class_limit' => 'required',

            'class_name' => 'required',

            'teacher_id' => 'required',

            'date' => 'required',

            'time' => 'required',

        ],
        [
          'course_id.required' => 'This field is required',
          'teacher_id.required' => 'This field is required'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }


           $dob_get = explode("/",request('date'));
           $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];
           $time_get1 = explode(" ",request('time'));
           $time_get2 = explode(":",$time_get1[0]);
           $newtime = $time_get2[0].':'.$time_get2[1].':'.'00';

           //$newTime = date("h:i", strtotime(request('time')));

           $addClass = array();

           $addClass['course_id'] = request('course_id');
           $addClass['teacher_id'] =request('teacher_id');
           $addClass['about_class'] = !empty(request('about_class')) ? request('about_class') : "";
           $addClass['class_name'] = request('class_name');
           $addClass['class_limit'] = request('class_limit');

           /*=============================================================*/

            //echo URL('app/public/edu_api/WiZiQService.php'); 
            //include(app_path().'/edu_api/AuthBase.php');
            include(app_path().'/edu_api/create.php');
            include(app_path().'/edu_api/AddAttendee.php');
            include(app_path().'/edu_api/Recurring.php');


            // $access_key="2zUH43M7Cfk=";
            // $secretAcessKey="l5oRUT3EnwNgxhhpL4r9yw==";

            $access_key="nbaqEtPHk3E=";
            $secretAcessKey="fipzu+2E2bDJRRPjjE418w==";

            $webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";




            $class = ClassDetails::where('id', request('class_name'))->where('is_delete', 0)->first(['course_name']);
            $class_name = $class->course_name;

            //$duration = ClassStudentRequest::where('class_details_id',request('class_name'))->first();
            //dd($duration);
            $duration_time = request('duration');

            $teacher_id = request('teacher_id');
            $teacher = User::where('id', $teacher_id)->where('is_delete', 0)->first(['name']);
            $teacher_name = $teacher->name;


            $attendee_limit = request('class_limit');
            if(request('is_recored') == 1)
            {
              $create_recording = 'true';
            }
            else
            {
              $create_recording = 'false';
            }


            if(request('repeat_type') != 0)
           {
              $week = request('specific_week');
              $repeat_type = request('repeat_type');
              @$comma_days = implode(',',request('days_of_week'));
              $newDate1 = $dob_get[1].'/'.$dob_get[0].'/'.$dob_get[2];

              $newtime1 = $time_get2[0].':'.$time_get2[1];

              $date_1 = explode("/",request('class_end_date'));
              $class_end_date = $date_1[1].'/'.$date_1[0].'/'.$date_1[2];



              $obj =  RecurringClass($secretAcessKey, $access_key, $webServiceUrl, $newDate1, $newtime1, $teacher_id, $teacher_name, $week, $repeat_type, $comma_days, $duration_time, $attendee_limit, $class_end_date, $create_recording, $class_name);

              // dd($obj);
           }
           else
           {

                $obj =  ScheduleClass($secretAcessKey,$access_key,$webServiceUrl, $newDate, $newtime, $class_name, $duration_time, $teacher_id, $attendee_limit,$create_recording, $teacher_name);

            }    

            if ($obj['errormsg'] != null) 
            {      
                return response()->json(['status' => 401,'errors' => $obj['errormsg']]);
                exit();
            }

           /* $student_api_array=array();
            $student_api_details['id']=request('class_students_request_id');
            $student_api_details['name']=request('studentname');
            array_push($student_api_array, $student_api_details);*/

            //$obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl,$obj['class_ids'],$student_api_array);

            
           /* if ($obj_student['errormsg'] != null) 
            {      
                return response()->json(['status' => 401,'errors' => $obj['errormsg']]);
                exit();
            }*/

           /*==============================================================*/
           if(!empty(request('class_image')))

           {

               $profile_pic = ImageUpload::upload('front/class_images/',request('class_image'));

               $image = $profile_pic;

           }

           else

           {

               $image = 'course_default_img.png';

           }
            $addClass['class_ids'] = $obj['class_ids'];
            //$addClass['student_schedule_class_url'] = $obj_student['student_attendee_url'];
            $addClass['teacher_schedule_class_url'] = $obj['presenter_urlTag'];
            // dd(request('class_end_date'));
            if (request('class_end_date') != null) 
            {
              $dob_get2 = explode("/",request('class_end_date'));
              $newDate2 = $dob_get2[2].'-'.$dob_get2[1].'-'.$dob_get2[0];
            }
            else
            {
              $newDate2 = $newDate;
            }
            //dd($newDate2);
           $addClass['duration'] = request('duration');
           $addClass['class_type'] = 3;
           $addClass['class_image'] = $image;
           $addClass['record'] = request('audio');
           $addClass['recording_type'] = request('is_recored');
           $addClass['date'] = $newDate.' '.$newtime;
           $addClass['end_date'] = $newDate2;


           if (request('repeat_type') != 0 && request('repeat_type') != 4 && request('repeat_type') != 5) 
           {

              $to = \Carbon\Carbon::createFromFormat('Y-m-d', $newDate);
              $from = \Carbon\Carbon::createFromFormat('Y-m-d', $newDate2);
              $diff_in_days = $to->diffInDays($from);
              $addClass['repeat_type'] = $diff_in_days + 1;

           }
          
          


           $addClass['repeat_every'] = request('specific_week');
           $addClass['week'] =  @$comma_days;
           $addClass['created_at'] = $newDate.' '.$newtime;


           ScheduleClass::insert($addClass);

           return response()->json(['success'=>true,'status' => 1], 200);

    }

    // editGroupClass
    public function editBatchClass(Request $request)
    {
        $editBatchClass = ScheduleClass::where('id',$request->id)->get();
        foreach ($editBatchClass as $key => $value) 
        {
            $editBatchClass['id'] = $request->id;
            $editBatchClass['course_id'] = $value->course_id;
            $editBatchClass['teacher_id'] = $value->teacher_id;
            $editBatchClass['class_limit'] = $value->class_limit;
            $editBatchClass['about_class'] = !empty($value->about_class) ? $value->about_class : "";
            $editBatchClass['class_name'] = $value->class_name;
            $editBatchClass['class_image'] = $value->class_image;
            $date_time_get = explode(" ",$value->date);
            $editBatchClass['date'] =  date("d/m/Y",strtotime($date_time_get[0]));
            $editBatchClass['time'] =  date("h:i",strtotime($date_time_get[1]));

        }

        return response()->json(['status' => 1,'success' => $editBatchClass]);
    }



    // updateBatchClass
    public function updateBatchClass(Request $request)
    {
      /*$validator = Validator::make($request->all(), [

            'course_id' => 'required',
            'class_limit' => 'required',
            'class_name' => 'required',
            'about_class' => 'required',
            'teacher_id' => 'required',
            'date' => 'required',
            'time' => 'required',

        ],
        [
          'course_id.required' => 'The select course field is required.',
          'teacher_id.required' => 'The select teacher field is required.'
        ]);*/
        $validator = Validator::make($request->all(), [

            'course_id' => 'required',
            'class_limit' => 'required',
            'class_name' => 'required',
            'teacher_id' => 'required',
            'date' => 'required',
            'time' => 'required',

        ],
        [
          'course_id.required' => 'This field is required',
          'teacher_id.required' => 'This field is required'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        if(!empty($request->class_image))

        {

            $profile_pic = ImageUpload::upload('front/class_images/',$request->file('class_image'));

            $image = $profile_pic;

        }

        else

        {

            $image = $request->old_img;

        }




         $dob_get = explode("/",request('date'));

         $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

         $time_get1 = explode(" ",request('time'));

         $time_get2 = explode(":",$time_get1[0]);

         $newtime = $time_get2[0].':'.$time_get2[1].':'.'00';

         $updateClass = array();


         $updateClass['course_id'] = request('course_id');

         $updateClass['teacher_id'] =request('teacher_id');
         $updateClass['class_limit'] =request('class_limit');

         $updateClass['about_class'] = !empty(request('about_class')) ? request('about_class') : "";

         $updateClass['class_name'] = request('class_name');

         $updateClass['class_image'] = $image;

         $updateClass['record'] = request('audio');

         $updateClass['recording_type'] = request('is_recored');

         $updateClass['date'] = $newDate.' '.$newtime;

         $updateClass['created_at'] = $newDate.' '.$newtime;

          


         ScheduleClass::where('id',$request->batch_class_id)->update($updateClass);

         return response()->json(['status' => 1,'data' => $updateClass]);

    }


    // viewBatchClass
    public function viewBatchClass(Request $request)
    {
        $batch_class = ScheduleClass::where('id',$request->id)->get();

        foreach ($batch_class as $key => $value) 

        {

            $batch_class['id'] = $request->id;
            $batch_class['course_id'] = $value->course_id;
            $batch_class['teacher_id'] = $value->teacher_id;
            $batch_class['class_limit'] = $value->class_limit;
            $batch_class['about_class'] = !empty($value->about_class) ? $value->about_class : "";
            $batch_class['class_name'] = $value->class_name;
            $batch_class['class_image'] = $value->class_image;
            $date_time_get = explode(" ",$value->date);
            $batch_class['date'] =  date("d/m/Y",strtotime($date_time_get[0]));
            $batch_class['time'] =  date("h:i",strtotime($date_time_get[1]));

        }

        return response()->json(['status' => 1,'success' => $batch_class]);
    }


    // deleteBatchClass
    public function deleteBatchClass($id)
    {

      $teacher_delete = ScheduleClass::where('id',$id)->update(['is_delete'=>'1']);

      return redirect()->back();

    }

    public function get_course_batch(Request $request)
    {
      $course_list = ClassDetails::where('is_delete','0')->where('course_id',$request->course_id)->get();
      $course_name_list = array();
      foreach ($course_list as $key => $value) 
      {
        $data['name'] = $value->course_name;
        $data['id'] = $value->id;
        array_push($course_name_list,$data);
      }
      //dd($course_name_list);
       return response()->json(['status' => 1,'success' => $course_name_list]);
    }


    public function getClassHoursRemaining(Request $request){

        $class= $request->class_name;
        $student=$request->student_name;

        $can_launch = canLaunchClass($student,$class,0); 
        $total_remaining_hours = $can_launch['total_remaining_hours'];

        return response()->json(['status' => 1,'total_remaining_hours' => $total_remaining_hours]);
         
    }






    // reschedule
    public function rescheduleClass()
    {
       //dd(request()->all());

      include(app_path().'/edu_api/create.php');
      include(app_path().'/edu_api/RescheduleClass.php');
            

      $access_key="nbaqEtPHk3E=";
      $secretAcessKey="fipzu+2E2bDJRRPjjE418w==";
      $webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";

      $dob_get = explode("/",request('date'));
      $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];
      $time_get1 = explode(" ",request('time'));
      $time_get2 = explode(":",$time_get1[0]);
      $newtime = $time_get2[0].':'.$time_get2[1].':'.'00';

      $teacher_id = request('teacher_id');
      $class_ids = request('class_ids');

      $teacher = User::where('is_delete',0)->where('id', $teacher_id)->first();
      $email = $teacher->email;

      //$email = request('email');
      $title = request('title');
      //dd($email);

      // dd($newDate .' '. $newtime);


      $obj =  RescheduleClass($secretAcessKey, $access_key, $webServiceUrl, $newDate, $newtime, $teacher_id, $class_ids, $email, $title);

      if ($obj['errormsg'] != null) 
      {      
          return response()->json(['status' => 401,'errors' => $obj['errormsg']]);
          exit();
      }

     // dd(request('class_ids'));
      ScheduleClass::where('class_ids', request('class_ids'))->update(['status' => 0, 'date' => $newDate." ".$newtime,'teacher_id'=>$teacher_id]);

      return response()->json(['status' => 1]);

    }
     public function student_data_get_upc(Request $request)
    {   

        //echo "string";die;
        $student_id= $request->student_id;
        $class_students_request_id=$request->class_students_request_id;
        $get_all_data = ClassStudentRequest::where('is_delete',0)->where('parent_id',$class_students_request_id)->get();

        //dd($get_all_data->toArray());

        if($get_all_data->isEmpty())
        {
        ?>  
          <tr class="odd"><td colspan="9" class="dataTables_empty" valign="top">No data available in table</td></tr>
        <?php  
          
        }
        else
        {
          foreach ($get_all_data as $key => $value) 
          {
          $check_class = AddAttendeeStudentClass::where('class_students_request_id',$value->parent_id)->first();
          //dd($check_class);

          $student_data = User::where('id',$value->student_id)->where('is_delete',0)->first(['name']);
            if (isset($student_data->name))
            {
              $student_name = $student_data->name;
            }
            else
            {
              $student_name = '';
            }
            $value['student_name'] = $student_name;
            $class_details = ClassDetails::where('is_delete',0)->where('id',$value->class_details_id)->first(['course_name','course_id']);
            $value['course_name'] = $class_details->course_name;

            $course = Course::where('is_delete',0)->where('id', $class_details->course_id)->first();
            $value['class_name'] = $course->course_name;

            if($value->class_types=='1')
            {
              $class_type = "One to One Class";
            }
            elseif($value->class_types=='2')
            {
              $class_type = "Buddy Class";
            }
            else
            {
              $class_type = "Batch Class";
            }
            $value['class_type'] = $class_type;

            if ($value->student_id == 0) 
            {
               $value['student_name'] = 'Not Register Student';
            }
            else
            {
              $student = User::where('is_delete',0)->where('id', $value->student_id)->first();
              $value['student_name'] = $student->name;
            }
            

            $check_student = AddAttendeeStudentClass::where('is_delete',0)->where('student_id', $value->student_id)->first();
            if(isset($check_student))
            {
            ?>   


            <tr>
                <td><?= $value->student_name ?></td>
                <td><?= $value->student_email_id ?></td>
                <td><?= $value->course_name ?></td>
                <td><?= $value->class_name ?></td>
                <td><?= $value->class_type ?></td>
                <td><?= $value->duration ?>  Minutes</td>
              <!--   <td><?= '<b>Start Date : </b>'.$value->session_start_date. ' <br><b>End Date : </b> '.$value->session_end_date ?></td>
                <td><?= '<b>Start Time : </b>'.$value->session_start_time. ' <br><b>End Time : </b> ' .$value->session_end_time ?></td>
                <td><?= $value->sessions_per_week ?></td>
                <td><?= $value->weeks_enrolling ?></td>
                <td><?= $value->total_sessions_per_weeks ?></td>
                <td><?= $value->fee_per_session ?></td>
                <td><?= $value->total_fee ?></td> -->
                <td>
               <?php
                if($value->payment_status=='0'){  echo '<button class="btn btn-default btn-xs">Not Payment</button>'; }
                if($value->payment_status=='1'){  echo '<button class="btn btn-success btn-xs">Success Payment</button>'; }
                if($value->payment_status=='2'){  echo '<button class="btn btn-warning btn-xs">Unsuccess Payment</button>'; }
                if($value->payment_status=='3'){  echo '<button class="btn btn-danger btn-xs">Cancel Payment</button>'; }
                ?>
                </td>
                 

            </tr>
                
            <?php  
            }

            

          }
        return response()->json(['status' => 200,'data' => $get_all_data]);
        }
        
    }

    public function edit_session(){
      $request = request()->all();//dd($request);
     
      $validator = Validator::make($request, [
          
          'edit_teacher_name' => 'required',
          'edit_seesion_date' => 'required',
          'edit_session_time' => 'required'
         
       ],
        [
          'edit_teacher_name.required' => 'This field is required.',
          'edit_seesion_date.required' => 'This field is required.',
          'edit_session_time.required' => 'This field is required.'
        ]);
 

        
        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());  
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        editSession($request);


        return response()->json(['success'=>true,"status"=> '1'], 200);
    }

    public function requestPayment(){
        $class_types=classType();
        // $student_request = ClassStudentRequest::join('users', 'users.id', '=', 'class_students_request.student_id') 
        //                     ->where('users.account_verified','1')
        //                     ->where('users.is_delete',0)
        //                     ->where('class_students_request.is_delete',0)
        //                     ->select('class_students_request.*')
        //                     ->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get();
        return view('panel.admin.student-teacher-mapping.request_payment',compact('student_list','class_types','course_list'));
    }

    public function studentRequestData(){
        $request = request()->all();
        $classStudentRequest = ClassStudentRequest::find($request['id']);
        $class_type=classType();

        $student = '';
        $parent = '';
        $parent_id = '';
        if($classStudentRequest->student){
          if($classStudentRequest->student->parent_id){
            $parent_id = $classStudentRequest->student->parent_id;
            $parent = $classStudentRequest->student->parent->name;
          }
          $student =$classStudentRequest->student->name;
        }
        
        $class_details =$classStudentRequest->classdetails;
        $duration = ($classStudentRequest->schedule_class_id)? $classStudentRequest->scheduleClass->duration:$classStudentRequest->duration;

        $can_launch = canLaunchClass($classStudentRequest->student_id,$classStudentRequest->class_details_id,$duration); 
        if($classStudentRequest->schedule_class_id && $classStudentRequest->scheduleClass->class_payment_type=='paid'){
          $total_remaining_hours = $can_launch['total_remaining_hours'];
        }
        else{
          $total_remaining_hours = 'Not Applicable';
        }
        

        $data['duration'] = $duration;
        $data['class'] = $class_details->course_name;
        $data['class_id'] = $classStudentRequest->class_details_id;
        $data['student_id'] = $classStudentRequest->student_id;
        $data['id'] = $classStudentRequest->id;
        $data['parent_id'] = $parent_id;
        $data['course'] = $classStudentRequest->classdetails->course->course_name;
        
        $data['student'] = $student;
        $data['parent'] = $parent;
        $data['class_type'] = (isset($class_type[$classStudentRequest->class_types]))?$class_type[$classStudentRequest->class_types]:'';
        $data['teacher'] = '';
        $data['total_remaining_hours'] = $total_remaining_hours;

        $data['course_fees'] = getCoursefees($class_details,$duration,$classStudentRequest->class_types);
        $data['course_fees_per_hour'] = getCoursefees($class_details,'60',$classStudentRequest->class_types);

        return response()->json(['status' => 200,'data' => $data]);

 
    }

    public function pastClassData(){
      $requestData = request()->all();
      $skip = $requestData['start'];
      $length = $requestData['length'];
      $get_all_live_class = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
        // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
        ->where('schedule_class.is_delete','0')
        ->where('event_sessions.status','!=','canceled')
        // ->whereIn('event_sessions.status',['completed'])
        ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '<=', date('Y-m-d H:i:s'))
        ->where('event_sessions.is_delete','0')
        ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type')
        ->orderBy('event_sessions.start_date','desc')
        ->orderBy('event_sessions.start_time','desc');

        $get_all_live_class_count = $get_all_live_class->count();
      $get_all_live_class_data = $get_all_live_class->skip($skip)->take($length)->get();   
         
      $class_type=classType();
      $i = $skip+1;
      foreach ($get_all_live_class_data as $key => $live_class) {
        try{ 
           
        $student_name = (!empty($live_class->schedule_class->studentClassRequestMany->where('is_delete','0')->where('status','1')->count()))?$live_class->schedule_class->studentClassRequestMany->where('is_delete','0')->where('status','1')->first()->student->name:'';
        if($live_class->schedule_class->studentClassRequestMany->where('is_delete','0')->where('status','1')->count()>1){
          $student_name .= '<br><a href="#" class="batch_student_list" schedule-class="{{$value->schedule_class_id}}">more</a>';
        }      
        }
         catch(\Exception $e){
        }
        $request_data[] = [
          'id' => $i++,
          'course_name' => $live_class->schedule_class->course->course_name,
          'class_name' => $live_class->schedule_class->class->course_name,
          'class_type' => $class_type[$live_class->class_type],
          'teacher_name' => $live_class->user->name,
          'student_name' => $student_name,
          'duration' => $live_class->duration." Minutes",
          'datetime' => date('D, d M Y', strtotime($live_class->start_date))." ".date('h:i a', strtotime($live_class->start_time)),
          'class_id' => $live_class->wiziq_class_id,
          'action' => '<a href="'.$live_class->recording_url.'" class="btn btn-success" target="_blank">View Recording </a>'
        ];
      }

      $json_data = array(
        "draw"            => intval( $requestData['draw'] ),
        "recordsTotal"    => intval( $get_all_live_class_count ),
        "recordsFiltered" => intval( $get_all_live_class_count ),
        "data"            => $request_data,
      );

      return $json_data;
    }

    public function requestPaymentData(){
      $requestData = request()->all();  
      $data =[];
      $skip = $requestData['start'];
      $length = $requestData['length'];
      $orderValue = $requestData['order'][0];
      $filters = $requestData['filters'];

      // $total_student_request = ClassStudentRequest::join('users', 'users.id', '=', 'class_students_request.student_id') 
      //                       ->where('users.account_verified','1')
      //                       ->where('users.is_delete',0)
      //                       ->where('class_students_request.is_delete',0)
      //                       ->select('class_students_request.*')->count();


        // $student_request_query = ClassStudentRequest::join('users', 'users.id', '=', 'class_students_request.student_id')  
        //                         ->join('schedule_class', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')
        //                         ->where('schedule_class.class_payment_type','paid')                    
        //                         ->where('schedule_class.is_delete','0')                    
        //                         ->where('users.account_verified','1')
        //                         ->where('users.is_delete',0)
        //                         ->where('class_students_request.is_delete',0)->where('class_students_request.status',1);

        $student_request_query = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id')
                                ->join('class_students_request', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')  
                                ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '>=', date('Y-m-d H:i:s'))
                                 ->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked','live'])
                                ->where('schedule_class.class_payment_type','paid')                    
                                ->where('schedule_class.is_delete','0') 
                                ->where('event_sessions.is_delete','0') 
                                ->where('class_students_request.is_delete',0)->where('class_students_request.status',1);

      
        if(isset($filters['student_id']) && $filters['student_id']!=""){
            $student_request_query->where('class_students_request.student_id',$filters['student_id']);
        }

        if(isset($filters['course_id']) && $filters['course_id']!=""){ 
            $student_request_query->where('schedule_class.course_id',$filters['course_id']);
        }

        if(isset($filters['class_name']) && $filters['class_name']!=""){
            $student_request_query->where('schedule_class.class_name',$filters['class_name']);
        }

        if(isset($filters['class_type']) && $filters['class_type']!=""){
            $student_request_query->where('class_students_request.class_types',$filters['class_type']);
        }

        if(isset($filters['date_from']) && !empty($filters['date_from']) && !empty($filters['date_to']))
        { 
            $date_from = $filters['date_from'];
            $date_from_split = explode("/",$date_from);
            $filer_date_from = $date_from_split[2].'-'.$date_from_split[1].'-'.$date_from_split[0];

            $date_to = $filters['date_to'];
            $date_to_split = explode("/",$date_to);
            $filer_date_to = $date_to_split[2].'-'.$date_to_split[1].'-'.$date_to_split[0];

     
            $student_request_query->where('event_sessions.start_date','>=',$filer_date_from); 
            $student_request_query->where('event_sessions.start_date','<=',$filer_date_to);
        }




                                   
        $student_request_query->select(DB::raw('DISTINCT(event_sessions.schedule_class_id) as sci'), DB::raw("(select CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`) from event_sessions where event_sessions.is_delete=0 and schedule_class_id=schedule_class.id and CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`) >= '".date('Y-m-d H:i:s')."' order by CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`) asc limit 1) as session_start_time"))->orderBy('session_start_time');

        $total_student_request = $student_request_query->count(DB::raw('DISTINCT(event_sessions.schedule_class_id)')); 

        $student_request = $student_request_query->skip($skip)->take($length)->get();  
        $class_type=classType();
        $class_frequency = getFrequency();
        $request_data = [];
        $i = $skip+1;
        foreach ($student_request as $key => $request) {

            $schedule = ScheduleClass::find($request->sci);
            $student_request = $schedule->studentClassRequest;
            $session_start_time = date('d M Y h:i a', strtotime($request->session_start_time));
            $duration = $schedule->duration;
            $schedule_type = $schedule->eventSchedule()->where('is_delete','0')->first();             
            $has_active_schedule = (!empty($schedule_type))?true:false;

            $can_launch = canLaunchClass($student_request->student_id,$student_request->class_details_id,$duration); 
            $total_remaining_hours = $can_launch['total_remaining_hours'];

            $frequency = (!empty($schedule_type))? $class_frequency[$schedule_type->schedule_type]:'-';
             
            $action = '';           

           
            $action = '<button class="btn btn-info btn-xs my-1" data-toggle="modal" data-target="#showViewPaymentsModal" student-id="'.$student_request->student_id.'" data-id="'.$student_request->class_details_id.'" data-req-id="'.$student_request->id.'" id="studentViewPayment">View History</button> ';
            
            $action .= '<button class="btn btn-success btn-xs my-2" data-toggle="modal" data-target="#showRequestModal" data-id="'.$student_request->id.'" id="studentPaymentRequest">Request Payment</button> ';                                              
                          
                  
            if($has_active_schedule){     
              $action .= '<button class="btn btn-default btn-xs" data-toggle="modal" data-target="#showRequestModal" data-id="'.$student_request->id.'" id="studentAddCreditHours">Credit Hours</button> '; 
            }                   
            
            $action .= '<button class="btn btn-danger btn-xs my-2" data-toggle="modal" data-target="#showRequestModal" data-id="'.$student_request->id.'" id="studentAddDebitHours">Debit Hours</button>';
              
 

            $request_data[] = [ 
                            'id' => $i,
                            'class_name' => $student_request->classdetails->course_name,
                            'course_name' => $student_request->classdetails->course->course_name,
                            'class_type' => (isset($class_type[$student_request->class_types]))?$class_type[$student_request->class_types]:'',
                            'student' => ($student_request->student)?$student_request->student->name:'',
                            'duration' => $duration.' Minutes',
                            'total_remaining_hours' => $total_remaining_hours,
                            'next_session' => $session_start_time,
                            'action' => $action,
                            'frequency' => $frequency,
                            'status' => ($has_active_schedule)?'Ongoing':'Completed',
                            ];
            $i++;
        }

        $json_data = array(
                "draw"            => intval( $requestData['draw'] ),
                "recordsTotal"    => intval( $total_student_request ),
                "recordsFiltered" => intval( $total_student_request ),
                "data"            => $request_data,
            );

        return $json_data;

    }

    public function saveRequestPayment(){
        $request = request()->all();
        $validator = Validator::make($request, [

            'fee_per_session' => 'required|integer|min:1',
            'total_number_of_hours' => 'required|numeric|min:1',
            'total_fees' => 'required|min:1',
            

        ],
        [
          'fee_per_session.required' => 'This field is required.',
          'total_number_of_hours.required' => 'This field is required.',
          'total_fees.required' => 'This field is required.'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }
        
        if(isset($request['hdn_confirm']) && $request['hdn_confirm']!='1' && $request['hdn_request_type']!="payment_request"){
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 402,'error1' => $error]);
            exit();
        }

        $request_user_id = ($request['hdn_parent_id']!='')? $request['hdn_parent_id'] : $request['hdn_student_id']; 
        $student = User::find($request['hdn_student_id']);
        $debit_credit_reason = (isset($request['add_reason']) && $request['add_reason']!="")? Str::slug($request['add_reason']):'';

        $seconds = ($request['total_number_of_hours'] * 3600);

        if($request['hdn_request_type']=='payment_request'){
            $order_status = 'requested';
            
        }
        elseif($request['hdn_request_type']=='add_debit'){
           $order_status = 'debited';
           $lc_status = 'debited';
        }
        elseif($request['hdn_request_type']=='add_credit'){
          $lc_status = 'credited';
          $order_status = (isset($request['add_reason']) && $request['add_reason']=='Payment yet to be received') ? 'requested':'credited';
           
        }

        $order = new Order;

        $order->order_date = date('Y-m-d H:i:s');
        $order->total_amount = $request['total_fees'];
        $order->total_seconds = $seconds; 
        $order->gateway_transaction_id = '';
        $order->user_id = loggedInUser()->id;
        $order->request_user_id = $request_user_id;
        $order->status = $order_status;
        $order->class_student_request_id = $request['hdn_id']; 
        $order->debit_credit_reason = $debit_credit_reason; 
        $order->save();
        $order->orderid = config('constants.ORDERID_PREFIX').date('YmdHis').$order->id;
        $order->save();

        $orderItem = new OrderItem;
        $orderItem->order_id = $order->id;
        $orderItem->class_id = $request['hdn_class_id'];
        $orderItem->student_id = $request['hdn_student_id']; 
        $orderItem->amount = $request['fee_per_session'];
        $orderItem->seconds = $seconds; 
        $orderItem->save();

        $class_name = ClassDetails::find($request['hdn_class_id']);

        if($request['hdn_request_type']!='payment_request'){
            $reason = '';
            if(isset($request['add_reason'])){

                if($request['hdn_request_type']=='add_credit'){
                  $reason = $request['add_reason'];
                  if($request['add_reason']=='Others' && $request['reason']!=''){
                    $reason .= '( '.$request['reason'].' )';
                  }
                }
                else{
                  $reason = $request['reason'];
                }

            }
            
            $lessonCredits = new LessonCredit();
            $lessonCredits->user_id = $request['hdn_student_id']; 
            $lessonCredits->object_type = 'App\User';
            $lessonCredits->object_id = loggedInUser()->id;
            $lessonCredits->seconds = $seconds;
            $lessonCredits->reason = $reason;
            $lessonCredits->class_id = $request['hdn_class_id'];
            $lessonCredits->status = $lc_status;
            $lessonCredits->order_id = $order->id;
            $lessonCredits->save();
        }
        

        $data['from_email'] = config('constants.FROM_EMAIL');
        $data['from_name']  = config('constants.FROM_NAME');
        $data['attachment']  = '';
        $data['class'] = $class_name->course_name;
        $data['course'] = $class_name->course->course_name;
        $data['total_hours'] = $request['total_number_of_hours'];
        $data['total_amount'] = $request['total_fees'];
        $data['fee_per_session'] = $request['fee_per_session'];
        $data['payment_link'] = url('student/payments_due');

        if($student->parent_id){
          $data['reciever_email']  = $student->parent->email;
          $data['reciever_name']  = $student->parent->name;   
          $data['student_name']  = $student->name; 
          $payment_req_mail = 'email.payment_request_parent_email';   
          
        }
        else{
          $data['reciever_email']  = $student->email;
          $data['reciever_name']  = $student->name;  
          $payment_req_mail = 'email.payment_request_student_email';  
        }

        if($data['reciever_name']!="" || !is_null($data['reciever_name'])){
          $data['subject']  = 'JoinIvy - Payment Request Notification';
          sendMail($payment_req_mail,$data);
        }
        

        return response()->json(['success'=>true,"status"=> '1'], 200);
    }

    
    public function deleteOrders(){
        $requestData = request()->all();  
        $orders_query = Order::find($requestData['order_id']);   
        $orders_query->status = 'deleted';
        $orders_query->save();    
        return response()->json(['success'=>true,"status"=> '1'], 200); 
    }

    public function markAsPaid(){
        $requestData = request()->all();  
        $orders_query = Order::find($requestData['order_id']);   
        $orders_query->order_complete_user_id = Auth::user()->id;
        $orders_query->status = 'paid';
        $orders_query->save();    
        return response()->json(['success'=>true,"status"=> '1'], 200); 
    }

    public function creditCollection(){
        // $orders = Order::all(); 
        // $class_type=classType();
        // 
        
        $payment_status=paymentStatus();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get();
        return view('panel.admin.orders.creditcollection',compact('course_list','student_list','payment_status'));
    }


    public function orders(){
        // $orders = Order::all(); 
        // $class_type=classType();
        // 
        
        $payment_status=paymentStatus();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get();
        return view('panel.admin.orders.orders',compact('course_list','student_list','payment_status'));
    }

    public function ordersListData(){
      $requestData = request()->all();  
      $data =[];
      $course_data =[];
      $skip = $requestData['start'];
      $length = $requestData['length'];
      $orderValue = $requestData['order'][0];
      $filters = $requestData['filters'];


        $orders_query = Order::join('class_students_request', 'class_students_request.id', '=', 'orders.class_student_request_id');
        $orders_query->where('orders.status','!=','deleted');

        if(isset($filters['student_request_id']) && $filters['student_request_id']!=""){
            $orders_query->where('class_students_request.id',$filters['student_request_id']);
            $classStudentRequest = ClassStudentRequest::find($filters['student_request_id']);
            $course_data['class'] = $classStudentRequest->classdetails->course_name;
            $course_data['course'] = $classStudentRequest->classdetails->course->course_name;
           
        }

        if(isset($filters['student_id']) && $filters['student_id']!=""){
            $orders_query->where('class_students_request.student_id',$filters['student_id']);
        }

        if(isset($filters['course_id']) && $filters['course_id']!=""){
            $orders_query->join('class_details', 'class_students_request.class_details_id', '=', 'class_details.id') ; 
            $orders_query->where('class_details.course_id',$filters['course_id']);
        }

        if(isset($filters['class_name']) && $filters['class_name']!=""){
            $orders_query->where('class_students_request.class_details_id',$filters['class_name']);
        }

        if(isset($filters['payment_status']) && $filters['payment_status']!=""){
            $orders_query->where('orders.status',$filters['payment_status']);
        }

        if(isset($filters['date_from']) && !empty($filters['date_from']) && !empty($filters['date_to']))
        { 
            $date_from = $filters['date_from'];
            $date_from_split = explode("/",$date_from);
            $filer_date_from = $date_from_split[2].'-'.$date_from_split[1].'-'.$date_from_split[0];

            $date_to = $filters['date_to'];
            $date_to_split = explode("/",$date_to);
            $filer_date_to = $date_to_split[2].'-'.$date_to_split[1].'-'.$date_to_split[0];

     
            $orders_query->where('orders.order_date','>=',$filer_date_from.' 00:00:00'); 
            $orders_query->where('orders.order_date','<=',$filer_date_to.' 23:59:59');
        }

        if(isset($filters['class_type']) && $filters['class_type']!=""){
            $orders_query->where('class_students_request.class_types',$filters['class_type']);
        }

        if(isset($filters['order_no']) && $filters['order_no']!=""){
            $orders_query->where('gateway_transaction_id',$filters['order_no']);
        }

        if(isset($filters['credit_payment_request']) && $filters['credit_payment_request']=="yes"){
            $orders_query->where('orders.status','requested')->where('orders.debit_credit_reason','payment-yet-to-be-received');
        }

        $orders_query->select('orders.*');
        $total_orders = $orders_query->count();

        $orders = $orders_query->skip($skip)->take($length)->get();  
        $class_type=classType();
        $request_data = [];
        $i = $skip+1;
        foreach ($orders as $key => $order) {
            $action = '';
            if($order->status=='requested'){
              if(loggedInUser()->user_type=='3')
                $action = '<a href="'.url('student/pay_now?order_id='.$order->orderid).'" > <button class="btn btn-success btn-xs my-1">Pay Now</button>';                
              else{
                $action = '<button class="btn btn-default btn-xs my-1">Requested</button> ';
                if($order->debit_credit_reason=='payment-yet-to-be-received'){ 
                  $action .= '<button class="btn btn-info btn-xs mark_as_paid my-1" data-id="'.$order->id.'">Mark as paid</button> ';
                }
                $action .= '<button class="btn btn-danger btn-xs cancel_order_request my-1" data-id="'.$order->id.'">Delete</button> ';
              }
                

            }

            if($order->status=='paid'){
                $student_name = ($order->classStudentRequest->student)?$order->classStudentRequest->student->name:''; 
                $action = '<button class="btn btn-success btn-xs">Paid</button> <a href="'.url('admin/print_receipt?order_id='.$order->gateway_transaction_id.'&student='.$student_name).'" target="_blank" class="btn btn-info btn-xs">Print Receipt</a>';
            }
            if($order->status=='failed'){
                $action = '<button class="btn btn-danger btn-xs">Failed</button>';
            }
            if($order->status=='canceled'){
                $action = '<button class="btn btn-warning btn-xs">Canceled</button>';
            }
            if($order->status=='credited'){
                $action = '<button class="btn btn-success btn-xs">Hours Credited</button>';
            }
            if($order->status=='debited'){
                $action = '<button class="btn btn-danger btn-xs">Hours Debited</button>';
            }
              

            $date_paid = (!empty($order->payment_date))?$order->payment_date:$order->order_date;
 
            $request_data[] = [ 
                            'id' => $i,
                            'marchant_order_id' => $order->orderid,
                            'orderid' =>$order->gateway_transaction_id,
                            'date' => date('d M Y h:i a', strtotime($date_paid)),
                            'class_name' => $order->classStudentRequest->classdetails->course_name,
                            'course_name' => $order->classStudentRequest->classdetails->course->course_name,
                            'student' => ($order->classStudentRequest->student)?$order->classStudentRequest->student->name:'',
                            'hours' => $order->total_seconds/3600,
                            'amount' => 'EGP '.$order->total_amount,                            
                            'status' => $action,
                            ];
            $i++;
        }

        $json_data = array(
                "draw"            => intval( $requestData['draw'] ),
                "recordsTotal"    => intval( $total_orders ),
                "recordsFiltered" => intval( $total_orders ),
                "data"            => $request_data,
                "course_data"            => $course_data,
            );

        return $json_data;

    }

    public function getLessonUsage(){
      $requestData = request()->all();  
      $data =[];
      
      $skip = $requestData['start'];
      $length = $requestData['length'];
      $orderValue = $requestData['order'][0];
      $filters = $requestData['filters'];

      $course_data =[];

      if(isset($filters['student_request_id']) && $filters['student_request_id']!=""){
            $classStudentRequest = ClassStudentRequest::find($filters['student_request_id']);
            $course_data['class'] = $classStudentRequest->classdetails->course_name;
            $course_data['course'] = $classStudentRequest->classdetails->course->course_name;
            $course_data['student'] = $classStudentRequest->student->name;
        }


        $lessoncr_query = LessonCredit::where('user_id', '!=', '');

        if(isset($filters['student_id']) && $filters['student_id']!=""){
            $lessoncr_query->where('user_id',$filters['student_id']);
        }

        if(isset($filters['class_id']) && $filters['class_id']!=""){
            $lessoncr_query->where('class_id',$filters['class_id']);
        }

        if(isset($filters['date_from']) && !empty($filters['date_from']) && !empty($filters['date_to']))
        { 
            $date_from = $filters['date_from'];
            $date_from_split = explode("/",$date_from);
            $filer_date_from = $date_from_split[2].'-'.$date_from_split[1].'-'.$date_from_split[0];

            $date_to = $filters['date_to'];
            $date_to_split = explode("/",$date_to);
            $filer_date_to = $date_to_split[2].'-'.$date_to_split[1].'-'.$date_to_split[0];

     
            $lessoncr_query->where('created_at','>=',$filer_date_from.' 00:00:00'); 
            $lessoncr_query->where('created_at','<=',$filer_date_to.' 23:59:59');
        }

        $lessoncr_query->select('*');
        $total_lc = $lessoncr_query->count();

        $lesson_credits = $lessoncr_query->skip($skip)->take($length)->get();  //dd($orders);
        $class_type=classType();
        $request_data = [];
        $i = $skip+1;
        foreach ($lesson_credits as $key => $lc) {  

            $order =null;
            $narration = '';
            if($lc->status=='credited'){
                $action = '<button class="btn btn-success btn-xs">Credited</button>';
                if($lc->object_type=='App\User'){
                   $narration = 'Credited by admin';
                }
                if($lc->object_type=='App\Order'){
                   $narration = 'Paid for lecture credits';
                }
                
            }
            if($lc->status=='debited'){
                $action = '<button class="btn btn-danger btn-xs">Debited</button>';
                if($lc->object_type=='App\User'){
                   $narration = 'Debited by admin';
                }
                if($lc->object_type=='App\EventSession'){
                  $narration = 'Attended the lecture';
                   
                }
                
            }

            $lc_date = $lc->created_at;


            $marchant_order_id = '-';
            $orderid = '-';
            $amount = '-';
            if($lc->object_type=='App\Order'){
                $order = $lc->order;   
                $marchant_order_id =  $order->orderid;
                $orderid = $order->gateway_transaction_id;
                $amount = 'EGP '.$order->total_amount;
                $narration .= '( Txn No:'.$orderid.' | '.$amount.')';

            }

            if($lc->object_type=='App\EventSession'){
                
                $event_session = $lc->event_session; 
                $lc_date = $event_session->start_date.' '.$event_session->start_time;
                 
            }

            if($lc->reason!=""){
              $narration .= "<br>( Reason: ".$lc->reason." )";

              if($lc->status=='credited' && $lc->reason =='Payment yet to be received'){
                
                  if($lc->object_type=='App\User'){
                      if(!empty($lc->order_id)){
                          $order = $lc->creditOrder; 
                          if($order->status=='paid'){
                            $orderid = $order->gateway_transaction_id;
                            $narration .= '<br>( Txn No:'.$orderid.' | <b class="text-success">PAID</b>)';
                          }
                          
                      } 
                  }                
                  
              }
            }

            

                     
 
            $request_data[] = [ 
                            'id' => $i,
                            'date' => date('d M Y h:i a', strtotime($lc_date)),
                            'student' => ($lc->student)?$lc->student->name:'',
                            'hours' => $lc->seconds/3600,
                            'class_name' => $lc->classdetails->course_name,
                            'course_name' => $lc->classdetails->course->course_name,
                            'amount' => $amount,                            
                            'narration' => $narration,                            
                            'status' => $action,
                            ];
            $i++;
        }

        $json_data = array(
                "draw"            => intval( $requestData['draw'] ),
                "recordsTotal"    => intval( $total_lc ),
                "recordsFiltered" => intval( $total_lc ),
                "data"            => $request_data,
                "course_data"            => $course_data,
            );

        return $json_data;

    }

    public function print_receipt(){
      $order_id = $_REQUEST['order_id'];
      
      $orders_query = Order::where('orders.gateway_transaction_id','=',$order_id)->first();
      $data['student'] = $_REQUEST['student'];
      $data['merchant_id'] = 'ORD'.$orders_query->id;
      $data['transaction_id'] = $orders_query->gateway_transaction_id;
      $data['amount'] = $orders_query->total_amount;
      
      PDF::SetXY(200, 0);
      PDF::SetPrintHeader(false);
      PDF::SetPrintFooter(false);
      PDF::SetLineStyle(array('width' => 6, 'cap' => 'butt', 'join' => 'miter', 'dash' => 4, 'color' => array(255, 0, 0)));
      PDF::AddPage();

      PDF::writeHTML(view('invoice.paid_receipt', compact('data'))->render());

      PDF::output('paid_receipt.pdf', 'I');

    }
   

}

