<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\UserReferral;
use App\User;
use Validator;

class ProfileController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
   
    public function myProfile()
    {
        return view('panel.admin.profile.index');
    }

    public function getRefferedUser(){
      $requestData = request()->all();  
      $userTypes = userTypes();
      $data =[];
      $skip = $requestData['start'];
      $length = $requestData['length'];
      $orderValue = $requestData['order'][0];
      // $filters = $requestData['filters'];

      
        $referal_query = UserReferral:: where('name','!=','');

        if(loggedInUser()->user_type!="1"){
            $referal_query->where('user_id',loggedInUser()->id);
        }
                                  
        $referal_query->select('*');
        $total_referal_request = $referal_query->count();

        $referals = $referal_query->skip($skip)->take($length)->get();  
 
        $request_data = [];
        $i = $skip+1;
        foreach ($referals as $key => $referal) {
            if($referal->user_id){
              $refered_by = $referal->user->name.' | '.$referal->user->email.' | '.$userTypes[$referal->user->user_type];
            }
            else{
              $additional_data = unserialize($referal->additional_data);

              $refered_by = (isset($additional_data['referrer_name']))?'<span class="text-warning">'.$additional_data['referrer_name'].' | '.$additional_data['referrer_email'].'</span>':'-';
            }

            $reg_date = '';
            if($referal->is_registered){
              $reg_user = User::where('email',$referal->email)->first();
              $reg_date = (!empty($reg_user)) ? date('d-m-Y', strtotime($reg_user->created_at)):'';
            }

          

            $request_data[] = [ 
                            'id' => $i,
                            'name' => $referal->name,
                            'email' => $referal->email,
                            'mobile' => $referal->mobile,
                            'role' => $referal->role,
                            'has_registered' => ($referal->is_registered)?'<i class="fa fa-check text-success" aria-hidden="true"></i>':'<i class="fa fa-times text-danger" aria-hidden="true"></i>',
                            'refered_by' =>  $refered_by,
                            'date' => date('d-m-Y', strtotime($referal->created_at)),
                            'reg_date' => $reg_date,

                            ];
            $i++;
        }

        $json_data = array(
                "draw"            => intval( $requestData['draw'] ),
                "recordsTotal"    => intval( $total_referal_request ),
                "recordsFiltered" => intval( $total_referal_request ),
                "data"            => $request_data,
            );

        return $json_data;

    }

    public function saveUserReferral(){
        $request = request()->all();
        $validator = Validator::make(request()->all(), [
            'name' => 'required',
            'role' => 'required',
            'email' => 'required|email|unique:users,email',
            'mobile' => 'required|numeric',
            'country_code' => 'required',
         ],
        [
          'name.required' => 'This field is required',
          'role.required' => 'This field is required',
          'country_code.required' => 'This field is required',
          'email.required' => 'This field is required',
          'email.unique' => 'This email id is already registered',
          'mobile.required' => 'This field is required'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $mobile_no= $request['country_code'].' '.$request['mobile'];

        $user_referal = new UserReferral;
        $user_referal->user_id = loggedInUser()->id;
        $user_referal->name = $request['name'];
        $user_referal->email = $request['email'];
        $user_referal->mobile = $mobile_no;
        $user_referal->role = $request['role'];
        $user_referal->additional_data = '';
        $user_referal->save();

        //send email
        $data['from_email'] = loggedInUser()->email;
        $data['from_name']  = loggedInUser()->name;
        $data['attachment']  = '';
        $data['referred_by'] = loggedInUser()->name;
        $data['referred_user_mobile'] = loggedInUser()->mobile;
        $data['referred_user_email'] = loggedInUser()->email;
        $data['reciever_email']  = $request['email'];
        $data['reciever_name']  = $request['name'];

 
        $data['subject']  = 'JoinIvy - You have been referred!';
        sendMail('email.user_referral.user_referral',$data);

 
        $data['attachment']  = '';
        $data['name'] = $request['name'];
        $data['email'] = $request['email'];
        $data['mobile'] = $mobile_no;
        $data['role'] = $request['role'];
        $data['referred_by'] = loggedInUser()->name;
        $data['reciever_email']  = config('constants.FROM_EMAIL');
        $data['reciever_name']  = config('constants.FROM_NAME');
 
        $data['subject']  = 'User referred by '.loggedInUser()->name;
        sendMail('email.user_referral.admin_user_referral',$data);
       


         return response()->json(['success'=>true,"status"=> '1'], 200);

    }

}
