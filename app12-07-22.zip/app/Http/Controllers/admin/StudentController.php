<?php

namespace App\Http\Controllers\admin;



use Illuminate\Http\Request;


use App\Http\Requests;

use App\Http\Controllers\Controller;

use Hash;

use DB;

use App\ImageUpload;

use Validator;

use App\User;

use App\StudentDetails;

use Illuminate\Validation\Rule;


class StudentController extends Controller

{

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function __construct()

    {

        $this->middleware('auth');

    }

    /**

     * Show the application dashboard.

     *

     * @return \Illuminate\Contracts\Support\Renderable

     */

    /*----course-----*/

    public function index()

    {

        $active_student_list = User::where('is_delete','0')->where('user_type','3')->where('account_status','active')->get();
        $inactive_student_list = User::where('is_delete','0')->where('user_type','3')->where('account_status','inactive')->get();
         
        // foreach ($student_list as $key => $value) 
        // {

        //     if(empty($value->email))
        //     {   
        //         $parent_id1 = User::where('is_delete',0)->where('id', $value->parent_id)->first();
        //         //dd($parent_id1);
        //         if(!empty($parent_id1->email))
        //         {
        //         $email = $parent_id1->email;
        //         $mobile = $parent_id1->mobile;
        //         //echo "string";die;
        //         $student_list[$key]['email']=$email;
        //         $student_list[$key]['mobile']=$mobile;
        //         }
        //     }
        // }

        $deactive_student_list = User::where('is_delete','1')->where('user_type','3')->get();
        //remove new user notify  
        User::where('new_user', '1')->where('user_type','3')->update(['new_user'=>'0']);
        //dd($student_list);



        return view('panel.admin.student.index',compact('active_student_list','inactive_student_list','deactive_student_list'));

    }

    public function student_add(Request $request)

    {

        $validator = Validator::make($request->all(), [

            'name' => 'required|string|min:5|max:255',

            'student_date_of_birth' => 'required|before:today',

            'nationality' => 'required',

            'native_language' => 'required',

            'residence_country' => 'required',

            'school_name' => 'required',

            'school_address' => 'required',

            'curriculum_type' => 'required',

            'school_type' => 'required',

            'email' => 'required|string|email|max:255|unique:users',

            'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',

            'residence_address' => 'required'

        ]);

        if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }



        $password = $request->password;

        $password_confirmation = $request->password_confirmation;

        $p_password = $request->p_password;

        $p_confirmation = $request->p_password_confirmation;

        $date = date("Y-m-d H:i:s");

        $s_year = $request->s_year ? $request->s_year : ' ';
        $s_other_curriculum = $request->s_other_curriculum ? $request->s_other_curriculum : ' ';

        $dob = date("Y-m-d",strtotime($request->student_date_of_birth));

        $password = Hash::make($request->password);

        $data = array('parent_id'=>'0','user_type'=>'3','name'=>$request->name,'account_verified'=>1,'email'=>$request->email,'mobile'=>$request->mobile,'created_at'=>$date);

        $s_id = User::insertGetId($data);

        $s_data = array('student_id'=>$s_id,'s_dob'=>$dob,'s_nationality'=> implode(',', $request->nationality), 's_country'=>$request->residence_country,'s_school_type'=>$request->school_type,'s_curriculum_type'=>$request->curriculum_type,'s_other_curriculum'=>$s_other_curriculum,'s_year'=>$s_year,'s_native_language'=>$request->native_language,'s_school_name'=>$request->school_name,'s_school_address'=>$request->school_address,'s_residence_address'=>$request->residence_address,'created_at'=>$date);

        StudentDetails::insert($s_data);
          

       return response()->json(['status' => 1,'data' => $data]);

    }





    // edit student

    public function editStudent()

    {

        $get_users = User::where('id', request('user_id'))->get(); 

        foreach ($get_users as $key => $get_user) 
        {
   
            $mobile_no = ($get_user->parent_id)?$get_user->parent->mobile:$get_user->mobile;
            $studentDetails = StudentDetails::where('student_id', $get_user->id)->first();
            if(!empty($mobile_no)){
                $mobile = explode(' ',$mobile_no); 
                $get_user['country_code'] = (isset($mobile[0])) ? $mobile[0] :'';
                $get_user['mobile'] = (isset($mobile[1])) ? $mobile[1] :'';
            } 
            else{
                $get_user['country_code'] = '';
                $get_user['mobile'] = '';
            }

            $get_user['email'] = ($get_user->parent_id)?$get_user->parent->email:$get_user->email;
            $nat_arr_make = array();
            if(!empty($studentDetails)){
                $nationality_get = explode(',',$studentDetails->s_nationality);            
                foreach($nationality_get as $key_hei => $value_hei)
                {
                   $nat_qua_ar =  $value_hei;
                   array_push($nat_arr_make,$nat_qua_ar);
                }

                $get_user['nationality'] = $nat_arr_make;
                $get_user['s_country'] = $studentDetails->s_country;
                $get_user['nativelanguage'] = $studentDetails->s_native_language;
                $s_dob = $studentDetails->s_dob;
                $get_user['s_dob'] = date("d/m/Y",strtotime($s_dob));
                $get_user['s_school_name'] = $studentDetails->s_school_name;
                $get_user['s_school_address'] = strip_tags($studentDetails->s_school_address);
                $get_user['s_curriculum_type'] = $studentDetails->s_curriculum_type;                
                $get_user['s_other_curriculum'] = $studentDetails->s_other_curriculum;
                $get_user['s_school_type'] = $studentDetails->s_school_type;
                $get_user['s_year'] = $studentDetails->s_year;
                $get_user['s_residence_address'] = strip_tags($studentDetails->s_residence_address);
            }
            else{
                $get_user['nationality'] = $nat_arr_make;
                $get_user['s_country'] = '';
                $get_user['nativelanguage'] = ''; 
                $get_user['s_dob'] = '';
                $get_user['s_school_name'] = '';
                $get_user['s_school_address'] = '';
                $get_user['s_curriculum_type'] = '';         
                $get_user['s_other_curriculum'] = '';
                $get_user['s_school_type'] = '';
                $get_user['s_year'] = '';
                $get_user['s_residence_address'] = '';

            }

            
            



        }

        

        return response()->json(['status' => 1,'success' => $get_users]);

    }

    public function viewStudent()
    {
        $get_users = User::where('id', request('user_id'))->get(); 
        foreach ($get_users as $key => $get_user) 
        {
            $mobile_no = ($get_user->parent_id)?$get_user->parent->mobile:$get_user->mobile;
            $studentDetails = StudentDetails::where('student_id', $get_user->id)->first();
            if(!empty($mobile_no)){
                $mobile = explode(' ',$mobile_no); 
                $get_user['country_code'] = (isset($mobile[0])) ? $mobile[0] :'';
                $get_user['mobile'] = (isset($mobile[1])) ? $mobile[1] :'';
            }
            else{
                $get_user['country_code'] = '';
                $get_user['mobile'] = '';
            }

            $get_user['created_at'] = $get_user->created_at;
            $get_user['email'] = ($get_user->parent_id)?$get_user->parent->email:$get_user->email;
            $nat_arr_make = array(); 
            if(!empty($studentDetails)){
                $nationality_get = explode(',',$studentDetails->s_nationality);
                foreach($nationality_get as $key_hei => $value_hei)
                {
                   $nat_qua_ar =  $value_hei;
                   array_push($nat_arr_make,$nat_qua_ar);
                }
                $get_user['nationality'] = $nat_arr_make;
                $get_user['s_country'] = $studentDetails->s_country;
                $get_user['nativelanguage'] = $studentDetails->s_native_language;
                $s_dob = $studentDetails->s_dob;
                $get_user['s_dob'] = date("d/m/Y",strtotime($s_dob));
                $get_user['s_school_name'] = $studentDetails->s_school_name;
                $get_user['s_school_address'] = strip_tags($studentDetails->s_school_address);
                $get_user['s_curriculum_type'] = $studentDetails->s_curriculum_type;
                $get_user['s_other_curriculum'] = $studentDetails->s_other_curriculum;
                $get_user['s_school_type'] = $studentDetails->s_school_type;
                $get_user['s_year'] = $studentDetails->s_year;
                $get_user['s_residence_address'] = strip_tags($studentDetails->s_residence_address);
            }
            else{
                $get_user['nationality'] = $nat_arr_make;
                $get_user['s_country'] = '';
                $get_user['nativelanguage'] = '';
                $get_user['s_dob'] = '';
                $get_user['s_school_name'] = '';
                $get_user['s_school_address'] = '';
                $get_user['s_curriculum_type'] = '';
                $get_user['s_other_curriculum'] = '';
                $get_user['s_school_type'] = '';
                $get_user['s_year'] = '';
                $get_user['s_residence_address'] = '';

            }
            
            
            
            
            
            
        }
        return response()->json(['status' => 1,'success' => $get_users]);
    }

    public function updatePassword(Request $request){
         $validator = Validator::make($request->all(), [
            'password' => 'required|min:6',
            'password_confirmation' => 'same:password'

        ],
        [
          
          'password_confirmation.same' => 'Confirm password and password must match '
          
        ]
    ); 
 

        if ($validator->fails()) 
        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }

        // // set password
        // $student_update = array();
        // $student_update['password'] = Hash::make($request->password);
        // $student_update['plain_password'] = $request->password;
       
        
        $student = User::find($request->user_id_01);
        if($student->parent_id){
            $student->password = Hash::make($request->password);
            $student->plain_password = $request->password;
            $student->save();
            
            $parent = $student->parent;
            $parent->password = Hash::make($request->password);
            $parent->plain_password = $request->password;
            $parent->save();

            $reciever_email = $parent->email;
            $reciever_name = $parent->name; 
        }
        else{
            $student->password = Hash::make($request->password);
            $student->plain_password = $request->password;
            $student->save();

            $reciever_email = $student->email;
            $reciever_name = $student->name; 
        }
        

        // User::where('parent_id', $request->user_id_01)->update($student_update);

         if($request->password!=""){
            $data=array();
            $data['from_email'] = config('constants.FROM_EMAIL');
            $data['from_name']  = config('constants.FROM_NAME');
            $data['attachment']  = '';
            $data['reciever_email']  = $reciever_email;
            $data['reciever_name']  = $reciever_name; 
            $data['password']  = $request->password; 
            $data['subject']  = 'JoinIvy - Password Updated';
            sendMail('email.password_update',$data);
        }

        return response()->json(['status' => 1,'success' => true]);
    }

    public function updateStudent(Request $request)

    {

       

        $validator = Validator::make($request->all(), [

            'name' => 'required|string|min:5|max:255',

            'student_date_of_birth' => 'required|before:today',

            'nationality' => 'required',

            'native_language' => 'required',

            'residence_country' => 'required',

            'school_name' => 'required',

            'school_address' => 'required',

            'curriculum_type' => 'required',

            'school_type' => 'required',

            'email' => 'required|string|email|max:255',
            
            'country_code' => 'required',

            'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',

            'residence_address' => 'required',

            // 'password' => 'nullable|min:6',
            // 'password_confirmation' => 'min:6|same:password'

        ]);

        

        if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }

        

       
        $mobile = $request->country_code.' '.$request->mobile;
        

        $student_update = array('name'=>$request->name, 'email'=>$request->email, 'mobile'=>$mobile, 'account_status'=>$request->account_status); 
        // // set password
        // if($request->password!=""){
        //     $student_update['password'] = Hash::make($request->password);
        //     $student_update['plain_password'] = $request->password;
        // } 
        
        $student = User::find($request->user_id);
        $student->update($student_update); 
       
        $s_year = $request->s_year ? $request->s_year : '0';
        $s_other_curriculum = $request->s_other_curriculum ? $request->s_other_curriculum : '';

     /*   $originalDate = $request->student_date_of_birth;*/

        $dob_get = explode("/",$request->student_date_of_birth);

        $dob = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

       

        StudentDetails::where('student_id', $request->user_id)->limit(1)->update(array('s_dob'=>$dob,'s_nationality'=>implode(",",$request->nationality),'s_country'=>$request->residence_country,'s_school_type'=>$request->school_type,'s_curriculum_type'=>$request->curriculum_type,'s_other_curriculum'=>$s_other_curriculum,'s_year'=>$s_year,'s_native_language'=>$request->native_language,'s_school_name'=>$request->school_name,'s_school_address'=>$request->school_address,'s_residence_address'=>$request->residence_address));

        // if($request->password!=""){
        //     $data=array();
        //     $data['from_email'] = config('constants.FROM_EMAIL');
        //     $data['from_name']  = config('constants.FROM_NAME');
        //     $data['attachment']  = '';
        //     $data['reciever_email']  = $student->email;
        //     $data['reciever_name']  = $student->name; 
        //     $data['password']  = $request->password; 
        //     $data['subject']  = 'JoinIvy - Password Updated';
        //     sendMail('email.password_update',$data);
        // }

        

       return response()->json(['status' => 1,'data' => $student]);

    }

    public function delete_student($id)
    {
       /* dd($id);*/
        $student_delete = StudentDetails::where('student_id',$id)->update(['is_delete'=>'1']);
        $user_delete = User::where('id',$id)->update(['is_delete'=>'1']);
        return redirect()->route('students_list');
    }

    public function activate_student($id)
    {
       /* dd($id);*/
        $user = User::find($id);
        if($user->user_type=='4'){
            DB::table('users')->where('parent_id',$user->id)->update(['account_status' => 'active']);
        }
        elseif($user->user_type == '3' && $user->parent_id != 0){
            DB::table('users')->where('id',$user->parent_id)->update(['account_status' => 'active']);
        }
        $user->account_status = 'active';
        $user->save();
        return redirect()->route('students_list');
    }

     public function restore_student($id)
    {
       /* dd($id);*/
        $student_delete = StudentDetails::where('student_id',$id)->update(['is_delete'=>'0']);
        $user_delete = User::where('id',$id)->update(['is_delete'=>'0']);
        return redirect()->route('students_list');
    }

    

    function createPassword()
    {
        $student_password = User::where('id',request('user_id_01'))->update(['password'=>  Hash::make(request('password')) ]);

         return response()->json(['status' => 1]);

    }



}

