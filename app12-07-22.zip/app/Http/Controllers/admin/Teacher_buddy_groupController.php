<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use Validator;
use App\ImageUpload;
use App\TeacherBuddyGroup;
use App\User;

class Teacher_buddy_groupController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function teacher_buddy_group()
    {
        $teachers = User::where('user_type','2')->where('is_delete','0')->where('account_verified','1')->get();
        $teacher_list = array();
        $teacher_buddy_list = TeacherBuddyGroup::where('is_delete','0')->get();
        foreach ($teacher_buddy_list as $key => $value) 
        {
            $teacher_ids = explode(',',$value->teacher_group_list);
            $all_t_name = array();
            foreach ($teacher_ids as $key_tl => $value_tl) 
            {
                $user_name = User::where('id',$value_tl)->first(['name']);
                array_push($all_t_name,$user_name->name);
            }
            array_push($teacher_list,$all_t_name);
        }
        // dd($teacher_buddy_list);
        return view('panel.admin.teacher-buddy-group.teacher_buddy_group',compact('teachers','teacher_list','teacher_buddy_list'));

    }
     public function manage_buddy_group()
    {
        $class_list = DB::table('class')->where('is_delete','0')->get();
        $course_list = DB::table('course')->where('is_delete','0')->where('parent_id','!=','0')->get();
        $teacher_list = DB::table('users')->where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
        return view('panel.admin.teacher-buddy-group.manage_buddy_group',compact('class_list','teacher_list','course_list'));
    }
    public function AddTeacherBuddyGroup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'group_name' => 'required|string|min:5|max:255',
            'teacher_id' => 'required'
        ]);
        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }
        $date = date("Y-m-d h:i:s");
        $data = array('group_name'=>$request->group_name,'teacher_group_list'=>implode(',',$request->teacher_id),'created_at'=>$date);
        TeacherBuddyGroup::insert($data);

        return response()->json(['status' => 1,'data' => $data]);

    }

    public function ViewTeacherBuddyGroup(Request $request)
    {

        $teacher_buddy_list = TeacherBuddyGroup::where('id',$request->id)->get(); 
        /*foreach($teacher_buddy_list as $key => $value) 
        {*/
            $teacher_ids = explode(',',$teacher_buddy_list[0]->teacher_group_list);
            $teacher_ids_arr_make = array();
            foreach($teacher_ids as $key => $value)
            {
               $teacher_id_make =  $value;
               array_push($teacher_ids_arr_make,$teacher_id_make);
            }
            $teacher_buddy_list['teacher_id'] = $teacher_ids_arr_make;
            $teacher_buddy_list['group_name'] = $teacher_buddy_list[0]->group_name;
        /*}*/
        return response()->json(['status' => 1,'success' => $teacher_buddy_list]);
    }
    public function EditTeacherBuddyGroup(Request $request)
    {

        $teacher_buddy_list = TeacherBuddyGroup::where('id',$request->id)->get(); 
        /*foreach($teacher_buddy_list as $key => $value) 
        {*/
            $teacher_ids = explode(',',$teacher_buddy_list[0]->teacher_group_list);
            $teacher_ids_arr_make = array();
            foreach($teacher_ids as $key => $value)
            {
               $teacher_id_make =  $value;
               array_push($teacher_ids_arr_make,$teacher_id_make);
            }
            $teacher_buddy_list['teacher_id'] = $teacher_ids_arr_make;
            $teacher_buddy_list['group_name'] = $teacher_buddy_list[0]->group_name;
            $teacher_buddy_list['id'] = $teacher_buddy_list[0]->id;
        /*}*/
        return response()->json(['status' => 1,'success' => $teacher_buddy_list]);
    }
    public function UpdateTeacherBuddyGroup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'group_name' => 'required|string|min:5|max:255',
            'teacher_id' => 'required'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $date = date("Y-m-d h:i:s");
        $data = array('group_name'=>$request->group_name,'teacher_group_list'=>implode(',',$request->teacher_id),'created_at'=>$date);
        TeacherBuddyGroup::where('id',$request->id)->update($data);

        return response()->json(['status' => 1,'data' => $data]);

    }
    public function DeleteTeacherBuddyGroup($id)
    {   
        $teacherbuddy_group_delete = TeacherBuddyGroup::where('id',$id)->update(['is_delete'=>'1']);
        return redirect()->route('teacher_buddy_group');
    }

}
