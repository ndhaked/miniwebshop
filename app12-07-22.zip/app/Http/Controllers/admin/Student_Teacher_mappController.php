<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use Validator;
use Mail;
use App\Mail\ScheduleClassEmail;

use App\ImageUpload;
use App\Classes;
use App\ClassDetails;
use App\ScheduleClass;
use App\Course;
use App\ClassStudentRequest;
use App\User;
use App\AddAttendeeStudentClass;

class Student_Teacher_mappController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function stu_teach_mapp()
    {

        // Only Buddy Working

        
        $get_all_data1 = ClassStudentRequest::where('status',0)->where('is_delete',0)->get();

        foreach ($get_all_data1 as $key => $value1) 
        {

          // $status = ClassStudentRequest::where('status',0)->where('class_types', 2)->where('is_delete',0)->count();
          $status = 0;
          //dd( $status);
          if ($status != 0) 
          {
              $get_all_data = ClassStudentRequest::where('status',0)->orWhere('status',1)->where('class_types', 2)->where('is_delete',0)->get();
              foreach ($get_all_data as $key => $value) 
              {

                 $class_details = ClassDetails::where('id',$value->class_details_id)->first(['course_name','course_id']);

                 $class_name = $class_details->course_name;
                 $course_id = $class_details->course_id;
                 $Course = Course::where('id',$course_id)->first(['course_name']);
                 $course_name = $Course->course_name;

                 if($value->class_types=='1')
                 {
                   $class_type = "One to One Class";
                 }
                 elseif($value->class_types=='2')
                 {
                   $class_type = "Buddy Class";
                 }
                 elseif($value->class_types=='3')
                 {
                   $class_type = "Batch Class";
                 }
                 else
                 {
                   $class_type = "";
                 }

                 $student_data = User::where('id',$value->student_id)->where('is_delete',0)->first(['name']);
                 if (isset($student_data->name))
                 {
                  $student_name = $student_data->name;
                  
                 }
                 else
                 {
                   $student_name = '';
                   
                 }


                 $schedule_class = ScheduleClass::where('class_name',$value->class_details_id)->where('is_delete',0)->first();
                 if ($schedule_class == null) 
                 {
                    $value->duddy_id = 'null';
                    $value->date_time = 'null';
                    $value->class_limit = 'null';
                    $value->class_ids = 'null';
                 }
                 else
                 {

                   $value->duddy_id = $schedule_class->id;
                   $value->date_time = $schedule_class->date;
                   $value->class_limit = $schedule_class->class_limit;
                   $value->class_ids = $schedule_class->class_ids;
                 }

                 $buddy_count_user = ClassStudentRequest::where('status',0)->where('parent_id', $value->id)->where('is_delete',0)->count();
                 $value->buddy_count = $buddy_count_user + 1;


                 $value->course_id = $course_id;
                 $value->course_name = $course_name;

                 $value->class_name_new = $class_name;
                 $value->class_type_new = $class_type;
                 $value->student_name_new = $student_name;
                 $value->duration = $value->duration;
                 $value->session_start_date = $value->session_start_date;
                 $value->session_end_date = $value->session_end_date;
                 $value->session_start_time = $value->session_start_time;
                 $value->session_end_time = $value->session_end_time;


              }

          }
          else
          {

            $get_all_data = ClassStudentRequest::where('status',0)->where('is_delete',0)->get();
            foreach ($get_all_data as $key => $value) 
            {
           
               //dd($value->id);
               $class_details = ClassDetails::where('id',$value->class_details_id)->first(['course_name','course_id']);

               $class_name = $class_details->course_name;
               $course_id = $class_details->course_id;
               $Course = Course::where('id',$course_id)->first(['course_name']);
               $course_name = $Course->course_name;

               if($value->class_types=='1')
               {
                 $class_type = "One to One Class";
               }
               elseif($value->class_types=='2')
               {
                 $class_type = "Buddy Class";
               }
               elseif($value->class_types=='3')
               {
                 $class_type = "Batch Class";
               }
               else
               {
                 $class_type = "";
               }

               $student_data = User::where('id',$value->student_id)->where('is_delete',0)->first(['name']);
               if (isset($student_data->name))
               {
                $student_name = $student_data->name;
                
               }
               else
               {
                 $student_name = '';
                 
               }


               $schedule_class = ScheduleClass::where('class_name',$value->class_details_id)->where('is_delete',0)->first();
               if ($schedule_class == null) 
               {
                  $value->duddy_id = 'null';
                  $value->date_time = 'null';
                  $value->class_limit = 'null';
                  $value->class_ids = 'null';
               }
               else
               {

                 $value->duddy_id = $schedule_class->id;
                 $value->date_time = $schedule_class->date;
                 $value->class_limit = $schedule_class->class_limit;
                 $value->class_ids = $schedule_class->class_ids;
               }

               $buddy_count_user = ClassStudentRequest::where('status',0)->where('parent_id', $value->id)->where('is_delete',0)->count();
               $value->buddy_count = $buddy_count_user + 1;


               $value->course_id = $course_id;
               $value->course_name = $course_name;

               $value->class_name_new = $class_name;
               $value->class_type_new = $class_type;
               $value->student_name_new = $student_name;
               $value->duration = $value->duration;
               $value->session_start_date = $value->session_start_date;
               $value->session_end_date = $value->session_end_date;
               $value->session_start_time = $value->session_start_time;
               $value->session_end_time = $value->session_end_time;
               
            }

          }

          $perant_count = ClassStudentRequest::where('parent_id','=',$value1->parent_id)->count();
          $status = ClassStudentRequest::where('parent_id','=',$value1->parent_id)->where('status' , '=' , 1)->count();

          if ($perant_count == $status) 
          {
            ClassStudentRequest::where('id','=',request('parent_id'))->update(['buddy_status' => 0]);
          }
                     
        }

        // $currentDate = date('Y-m-d');
        // $teacher_list = User::where('is_delete','0')
        //               ->where('user_type','2')
        //               ->where('account_verified','1')
        //               ->leftJoin('available_month', 'users.id' ,'=', 'available_month.teacher_id')
        //               ->whereDate('available_month.end_date', '>=', $currentDate)
        //               ->select('users.*','available_month.id as available_id')
        //               ->get();
       // dd($teacher_list->toArray());
         $session_status = sessionStatus();
         $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
         $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
         $student_list = User::where('is_delete','0')->where('user_type','3')->where('account_verified','1')->get(); //->where('account_verified','1')
        
        return view('panel.admin.student-teacher-mapping.stu_teach_mapping',compact('get_all_data','teacher_list','course_list','student_list'));
    }

    public function student_request_class(Request $request){

      $student_request = ClassStudentRequest::find($request->id);
      $class_id = $student_request->class_details_id;
      $course_id = $student_request->classdetails->course_id;

      $days_of_week = (!empty($student_request->schedule_data)) ? unserialize($student_request->schedule_data) : [];

      return response()->json(['status' => 1,'student_request' => $student_request,'class_id' => $class_id,'course_id' => $course_id,'days_of_week' => $days_of_week]);
      

    }

    public function delete_stu_teach_mapp($student_request_id){
      $student_request = ClassStudentRequest::find($student_request_id);
      $student_request->is_delete = '1';
      $student_request->save();

      return redirect()->back();
    }

    public function student_data_get(Request $request)
    {   


        $student_id= $request->student_id;
        $class_students_request_id=$request->class_students_request_id;
        $get_all_data = ClassStudentRequest::where('is_delete',0)->where('parent_id',$class_students_request_id)->get();

        //dd($get_all_data->toArray());

        if($get_all_data->isEmpty())
        {
        ?>  
          <tr class="odd"><td colspan="9" class="dataTables_empty" valign="top">No data available in table</td></tr>
        <?php  
          
        }
        else
        {
          foreach ($get_all_data as $key => $value) 
          {
        	$check_class = AddAttendeeStudentClass::where('class_students_request_id',$value->parent_id)->first();
        	//dd($check_class);

        	$student_data = User::where('id',$value->student_id)->where('is_delete',0)->first(['name']);
           	if (isset($student_data->name))
           	{
            	$student_name = $student_data->name;
           	}
           	else
           	{
             	$student_name = '';
           	}
           	$value['student_name'] = $student_name;
            $class_details = ClassDetails::where('is_delete',0)->where('id',$value->class_details_id)->first(['course_name','course_id']);
            $value['course_name'] = $class_details->course_name;

            $course = Course::where('is_delete',0)->where('id', $class_details->course_id)->first();
            $value['class_name'] = $course->course_name;

            if($value->class_types=='1')
            {
              $class_type = "One to One Class";
            }
            elseif($value->class_types=='2')
            {
              $class_type = "Buddy Class";
            }
            else
            {
              $class_type = "Batch Class";
            }
            $value['class_type'] = $class_type;

            if ($value->student_id == 0) 
            {
               $value['student_name'] = 'Not Register Student';
            }
            else
            {
              $student = User::where('is_delete',0)->where('id', $value->student_id)->first();
              $value['student_name'] = $student->name;
              $value['mobile'] = $student->mobile;
            }
            
            ?>   


            <tr class="text-center">
                <td><?= $key + 1 ?></td>
                <td><?= $value->student_name ?></td>
                <td><?= $value->student_email_id ?></td>
                <td><?= $value->mobile ?></td>
                <!-- <td><?= $value->course_name ?></td>
                <td><?= $value->class_name ?></td>
                <td><?= $value->class_type ?></td> -->
                <!-- <td><?= $value->duration ?>  Minutes</td>
                <td><?= '<b>Start Date : </b>'.$value->session_start_date. ' <br><b>End Date : </b> '.$value->session_end_date ?></td>
                <td><?= '<b>Start Time : </b>'.$value->session_start_time. ' <br><b>End Time : </b> ' .$value->session_end_time ?></td>
                <td><?= $value->sessions_per_week ?></td>
                <td><?= $value->weeks_enrolling ?></td>
                <td><?= $value->total_sessions_per_weeks ?></td>
                <td><?= $value->fee_per_session ?></td>
                <td><?= $value->total_fee ?></td> -->
                <td>
               <?php
                if($value->payment_status=='0'){  echo '<button class="btn btn-default btn-xs">Not Payment</button>'; }
                if($value->payment_status=='1'){  echo '<button class="btn btn-success btn-xs">Success Payment</button>'; }
                if($value->payment_status=='2'){  echo '<button class="btn btn-warning btn-xs">Unsuccess Payment</button>'; }
                if($value->payment_status=='3'){  echo '<button class="btn btn-danger btn-xs">Cancel Payment</button>'; }
                ?>
                </td>
                <td>
               <?php
                //dd($check_class->class_ids);
                if($check_class == null || $check_class->class_ids == 0)
               	{  
               		echo '<button class="btn btn-default btn-xs">Class Not Found</button>'; 
               	}
               	else
               	{ 
               		if ($value->student_id == 0) 
               		{
               			echo '<button class="btn btn-warning btn-xs">Not Register Student</button>'; 
               		}
               		else
               		{
               			$check_student = AddAttendeeStudentClass::where('is_delete',0)->where('student_id', $value->student_id)->first();
               			if($check_student)
               			{
               				echo '<button class="btn btn-success btn-xs">Student schedule Done</button>'; 	
               			}
               			else
               			{

               				echo '<button onclick="add_Attendee(this)" class="btn btn-success btn-xs" data-class_students_request_id="'.$value->id.'"  data-student="'.$value->student_id.'" data-ids="'.$check_class->class_ids.'" data-schedule_class_id="'.$check_class->schedule_class_id.'" data-name="'.$value->student_name.'" data-parent="'.$class_students_request_id.'">Add Attendee</button>';
               			}

               		}
               	}
                ?>
                </td>

            </tr>
                
            <?php  

            

          }
        return response()->json(['status' => 200,'data' => $get_all_data]);
        }
        
    }


    public function batchClassUpdate(Request $request)
    {

        // dd($request->all());	
        // include(app_path().'/edu_api/AuthBase.php');
        include(app_path().'/edu_api/create.php');
        include(app_path().'/edu_api/AddAttendee.php');

        $access_key="nbaqEtPHk3E=";
        $secretAcessKey="fipzu+2E2bDJRRPjjE418w==";
        $webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";



        $student_api_array=array();
        $student_api_details['id']=request('request_id');
        $student_api_details['name']=request('student_name');
        array_push($student_api_array, $student_api_details);

        $obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl,$request->class_ids,$student_api_array);

        
        if ($obj_student['errormsg'] != null) 
        {      
            return response()->json(['status' => 401,'errors' => $obj_student['errormsg']]);
            exit();
        }

        $addClass = array();

        $addClass['class_type'] = $request->class_type;
        $addClass['student_id'] = $request->student_id;
        $addClass['schedule_class_id'] = $request->batch_id;
        $addClass['student_schedule_class_url'] = $obj_student['student_attendee_url'];
        $addClass['class_students_request_id'] = $request->request_id;
        $addClass['class_ids'] = $request->class_ids;
        $addClass['created_at'] = date('Y-m-d H:i:s');

        AddAttendeeStudentClass::insert($addClass);

       $request_update = ClassStudentRequest::where('id', $request->request_id)->update(['schedule_class_id' => $request->batch_id, 'status' => 1]);

        
        $schedule_class = ScheduleClass::where('id', $request->batch_id)->first();
        $user = User::where('id', $schedule_class->teacher_id)->where('is_delete', 0)->first();
        $teacher_name = $user->name;

        $get_class_id = ClassStudentRequest::where('id', $request->request_id)->first();
        $class_details = ClassDetails::where('id',$get_class_id->class_details_id)->first();
        $class_name = $class_details->course_name;
        

        $objDemo = new \stdClass();
        $objDemo->sender = 'JoinIvy';
        $objDemo->date = $schedule_class->date;
        $objDemo->teacher_name = $teacher_name;
        $objDemo->class_name = $class_name; 

        // dd($objDemo);

        Mail::to($get_class_id->student_email_id)->send(new ScheduleClassEmail($objDemo));


      
      return response()->json(['status' => 200,'data' => []]);
      
    }


    public function buddyClassUpdate(Request $request)
    {

        // dd(request()->all());
        $validator = Validator::make($request->all(), [

            'teacher_id' => 'required',
            'date' => 'required',
            'time' => 'required',
            'class_image' => 'image|mimes:jpeg,png,jpg',

        ],
        [
          'teacher_id.required' => 'The select teacher field is required.'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        
        include(app_path().'/edu_api/create.php');
        include(app_path().'/edu_api/AddAttendee.php');
        include(app_path().'/edu_api/Recurring.php');
        

        $access_key="nbaqEtPHk3E=";
        $secretAcessKey="fipzu+2E2bDJRRPjjE418w==";

        $webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";


       $dob_get = explode("/",request('date'));
       $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];
       $time_get1 = explode(" ",request('time'));
       $time_get2 = explode(":",$time_get1[0]);
       $newtime = $time_get2[0].':'.$time_get2[1].':'.'00';




       $addClass = array();

       $addClass['class_type'] = 2;
       $addClass['course_id'] = request('course_id_buddy');
       $addClass['teacher_id'] =request('teacher_id');
       $addClass['class_name'] = request('class_id_buddy'); // class_id
       $addClass['class_limit'] = request('class_limit_buddy');
       $addClass['duration'] = request('class_duration');
       $addClass['about_class'] = request('about_class');

       $class = ClassDetails::where('id', request('class_id_buddy'))->where('is_delete', 0)->first(['course_name']);
       $class_name = $class->course_name;

       $duration = ClassStudentRequest::where('class_details_id',request('class_id_buddy'))->first();
       $duration_time = $duration->duration;

       $teacher_id = request('teacher_id');
       $teacher = User::where('id', $teacher_id)->where('is_delete', 0)->first(['name']);
       $teacher_name = $teacher->name;

      $student = User::where('id', $duration->student_id)->where('is_delete', 0)->first();
      $student_email = $student->email;

        // dd($student_email);
        
       $attendee_limit = '1';
       if(request('is_recored') == 1)
       {
         $create_recording = 'true';
       }
       else
       {
         $create_recording = 'false';
       }

     

       if(request('repeat_type') != 0)
       {
          $week = request('specific_week');
          $repeat_type = request('repeat_type');
          @$comma_days = implode(',',request('days_of_week'));
          $newDate1 = $dob_get[1].'/'.$dob_get[0].'/'.$dob_get[2];

          $newtime1 = $time_get2[0].':'.$time_get2[1];

          // $class_end_date = request('class_end_date');
          $date_1 = explode("/",request('class_end_date'));
          $class_end_date = $date_1[1].'/'.$date_1[0].'/'.$date_1[2];

          $obj =  RecurringClass($secretAcessKey, $access_key, $webServiceUrl, $newDate1, $newtime1, $teacher_id, $teacher_name, $week, $repeat_type, $comma_days, $duration_time, $attendee_limit, $class_end_date, $create_recording, $class_name);
          
       }
       else
       {

          $obj =  ScheduleClass($secretAcessKey,$access_key,$webServiceUrl, $newDate, $newtime, $class_name, $duration_time, $teacher_id, $attendee_limit,$create_recording, $teacher_name);

       }

        

        if ($obj['errormsg'] != null) 
        {      
            return response()->json(['status' => 401,'errors' => $obj['errormsg']]);
            exit();
        }


       if(!empty(request('class_image')))
       {
           $profile_pic = ImageUpload::upload('front/class_images/',request('class_image'));
           $image = $profile_pic;
       }
       else
       {
           $image = 'course_default_img.png';
       }

        $addClass['class_ids'] = $obj['class_ids'];
        $addClass['teacher_schedule_class_url'] = $obj['presenter_urlTag'];
       	$addClass['class_image'] = $image;
       	$addClass['record'] = request('audio');
       	$addClass['recording_type'] = request('is_recored');
       	$addClass['date'] = $newDate.' '.$newtime;
       	$addClass['created_at'] = $newDate.' '.$newtime;
        $addClass['class_master_id'] =  !empty($obj['class_master_id']) ? : 0;
        

       if(ScheduleClass::insert($addClass))
       {
       		$id = DB::getPdo()->lastInsertId();
       		
       		$student_api_array=array();
	        $student_api_details['id'] = request('request_id_buddy');
	        $student_api_details['name'] = request('studentname_buddy');
	        array_push($student_api_array, $student_api_details);

	        $obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl,$obj['class_ids'],$student_api_array);

	        
	        if ($obj_student['errormsg'] != null) 
	        {      
	            return response()->json(['status' => 401,'errors' => $obj_student['errormsg']]);
	            exit();
	        }

	        $addClass1 = array();
	        $addClass1['class_type'] = 2;
	        $addClass1['student_id'] = request('student_id');
	        $addClass1['schedule_class_id'] = $id;
	        $addClass1['student_schedule_class_url'] = $obj_student['student_attendee_url'];
	        $addClass1['class_students_request_id'] =  request('request_id_buddy');
	        $addClass1['class_ids'] =$obj['class_ids'];
          $addClass1['recording_url'] = $obj['recording_url'];
	        $addClass1['created_at'] = date('Y-m-d H:i:s');
	        AddAttendeeStudentClass::insert($addClass1);

   			  $request_update = ClassStudentRequest::where('id', $request->request_id_buddy)->update(['schedule_class_id' => $id, 'status' => 1, 'buddy_status' => 1]);


        $objDemo = new \stdClass();
        $objDemo->sender = 'JoinIvy';
        $objDemo->date = $newDate.' '.$newtime;
        $objDemo->teacher_name = $teacher_name;
        $objDemo->class_name = $class_name; 

        // dd($objDemo);

        Mail::to($student_email)->send(new ScheduleClassEmail($objDemo));


       

       		return response()->json(['success'=>true,'status' => 1], 200);

       }

      
    }


    // buddyClassMore
    public function buddyClassMore()
    {
    	  // dd(request()->all());

        include(app_path().'/edu_api/create.php');
        include(app_path().'/edu_api/AddAttendee.php');

        $access_key="nbaqEtPHk3E=";
        $secretAcessKey="fipzu+2E2bDJRRPjjE418w==";

        $webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";


        $student_api_array=array();
        $student_api_details['id'] = request('class_students_request_id');
        $student_api_details['name'] = request('student_name');
        array_push($student_api_array, $student_api_details);

        $obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl, request('class_ids'),$student_api_array);
        // dd($obj_student);
        
        if ($obj_student['errormsg'] != null) 
        {      
            return response()->json(['status' => 401,'errors' => $obj_student['errormsg']]);
            exit();
        }

         

          $addClass1 = array();
          $addClass1['class_type'] = 2;
          $addClass1['student_id'] = request('student_id');
          $addClass1['schedule_class_id'] = request('schedule_class_id');
          $addClass1['student_schedule_class_url'] = $obj_student['student_attendee_url'];
          $addClass1['class_students_request_id'] =  request('class_students_request_id');
          $addClass1['class_ids'] =request('class_ids');
          // $addClass1['recording_url'] = $obj_student['recording_url'];
          $addClass1['created_at'] = date('Y-m-d H:i:s');

          if (AddAttendeeStudentClass::insert($addClass1)) 
          {
            $request_done = ClassStudentRequest::where('parent_id', request('parent_id'))->where('id', request('class_students_request_id'))->update(['status' => 1]);

            $request_update = ClassStudentRequest::where('id', request('class_students_request_id'))->update(['schedule_class_id' => request('schedule_class_id'), 'status' => 1]);

          }

        $student = User::where('id', request('student_id'))->where('is_delete', 0)->first();
        $student_email = $student->email;

        $schedule_class = ScheduleClass::where('id', request('schedule_class_id'))->first();

        $user = User::where('id', $schedule_class->teacher_id)->where('is_delete', 0)->first();
        $teacher_name = $user->name;

        $class_details = ClassDetails::where('id',$schedule_class->class_name)->first();
        $class_name = $class_details->course_name;

        //dd($class_name);

        $objDemo = new \stdClass();
        $objDemo->sender = 'JoinIvy';
        $objDemo->date = $schedule_class->date;
        $objDemo->teacher_name = $teacher_name;
        $objDemo->class_name = $class_name; 

        // dd($objDemo);

        Mail::to($student_email)->send(new ScheduleClassEmail($objDemo));




        return response()->json(['success'=>true,'status' => 1], 200);



    }


}
