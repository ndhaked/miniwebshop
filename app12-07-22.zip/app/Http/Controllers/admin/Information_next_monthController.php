<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\Classes;
use App\Course;
use App\User;
use App\AvailableMonth;
use Validator;
use Auth;
use Carbon\Carbon;

class Information_next_monthController extends Controller

{

   

    public function __construct()

    {

        $this->middleware('auth');

    }


    public function information_next_month1()
    {
        // // $teacher_id = auth::user()->id;
        $currentDate = date('Y-m-d');

        $availables = AvailableMonth::where('is_deleted' ,0)->whereDate('end_date', '>=', $currentDate)->get();
        foreach ($availables as $key => $available) 
        {
        
            $time = new Carbon($available->start_time);
            $shift_end_time = new Carbon($available->end_time);

            $total_hours = $time->diffForHumans($shift_end_time);
            $available->total_hours = $total_hours;

            $teacher_name = User::where('id', $available->teacher_id)->first();
            // dd($teacher_name);
            $available->teacher_name = $teacher_name->name;



        }
        // dd($availables->toArray());
        return view('panel.admin.information_next_month.information_next_month',compact('availables'));
    }

    

}

