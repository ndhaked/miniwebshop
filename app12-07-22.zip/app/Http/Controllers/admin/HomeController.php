<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use App\User;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware(function ($request, $next) {
            if(Auth::user()->user_type != 1){
                $redirectUrl = getDashboardPath();                
                return redirect($redirectUrl);
            }
            return $next($request);
            
        });
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $all_users = User::count();
        $teachers = User::where('user_type','2')->count();
        $students = User::where('user_type','3')->count();
        $activate_user = User::where('account_verified','1')->count();
        return view('panel.admin.home',compact('all_users','teachers','students','activate_user'));
    }
    public function course_offered()
    {
        return view('front.course_offered');
    }

    public function runCron($type){

        if($type=='session'){
            cronCreateScheduleSessions();
        }
        elseif($type=='wiziqurl'){            
            cronCreateWizIQSessions();
        }
        elseif($type=='lesson_credits'){            
            updateLessonCredits();
        }

    }

    public function user_referral()
    {
        
        return view('panel.admin.user_referral');
    }

    public function download_students()
    {
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=students ".date('d-m-Y H:i:s').".csv",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0",
        );

        $callback = function () {
            $file = fopen('php://output', 'w');
            fputcsv($file, ["No","Student Name","Email","Mobile","Status"]);
            $students = User::where('user_type','3')->get();
            foreach ($students as $index => $student) {
                fputcsv($file, [$index+1, $student->name, $student->email, $student->mobile, ($student->is_delete == 1) ? 'deleted' : $student->account_status]);
            }
            fclose($file);
        };
        return \Response::stream($callback, 200, $headers);
    }

    public function download_teachers()
    {
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=teachers ".date('d-m-Y H:i:s').".csv",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0",
        );

        $callback = function () {
            $file = fopen('php://output', 'w');
            fputcsv($file, ["No","Teacher Name","Email","Mobile","Profiled Teacher","Featured","Status"]);
            $teachers= User::join('teacher_details','teacher_details.teacher_id','users.id')->where('users.is_delete','0')->where('users.user_type','2')->get();
            foreach ($teachers as $index => $teacher) {
                $account_verified_list = [0 => 'pending', 1 => 'active', 2 => 'inactive', 10 => 'rejected'];
                fputcsv($file, [
                    $index+1,
                    $teacher->name, 
                    $teacher->email, 
                    $teacher->mobile, 
                    ($teacher->is_profiled_teacher) ? 'Yes' : 'No',
                    ($teacher->is_featured) ? 'Yes' : 'No',
                    $account_verified_list[$teacher->account_verified]
                ]);
            }
            fclose($file);
        };
        return \Response::stream($callback, 200, $headers);
    }

    public function download_past_class()
    {
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=past_class ".date('d-m-Y H:i:s').".csv",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0",
        );

        $callback = function () {
            $file = fopen('php://output', 'w');
            fputcsv($file, ["No","Course Name","Sub Course","Class Mode","Teacher Name","Student Name","Duration","Date & Time","Class ID"]);

            $get_all_live_class = \App\EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.status','!=','canceled')
            // ->whereIn('event_sessions.status',['completed'])
            ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '<=', date('Y-m-d H:i:s'))
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type')
            ->orderBy('event_sessions.start_date','desc')
            ->orderBy('event_sessions.start_time','desc')
            ->get();
            $class_type=classType();
            
            foreach ($get_all_live_class as $index => $value) {
                $student_ids = $value->schedule_class->studentClassRequestMany->where('is_delete','0')->where('status','1')->pluck('student_id');
                $students = implode(" , ",\App\User::whereIn('id', $student_ids)->pluck('name')->toArray());
                fputcsv($file, [
                    $index+1,
                    $value->schedule_class->course->course_name,
                    $value->schedule_class->class->course_name,
                    $class_type[$value->class_type],
                    $value->user->name,
                    $students,
                    $value->duration,
                    date('D, d M Y', strtotime($value->start_date))." ".date('h:i a', strtotime($value->start_time)),
                    $value->wiziq_class_id
                ]);
            }
            
            fclose($file);
        };
        return \Response::stream($callback, 200, $headers);
    }

    public function download_payments()
    {
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=payments ".date('d-m-Y H:i:s').".csv",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0",
        );

        $callback = function () {
            $file = fopen('php://output', 'w');
            fputcsv($file, ["Order No","Merchant Order Id","Date","Course Name","Sub Course Name","Student Name","Total Hours","Total Amount","Status"]);

            $orders_query = \App\Order::join('class_students_request', 'class_students_request.id', '=', 'orders.class_student_request_id');
            $orders_query->where('orders.status','!=','deleted');
            $orders_query->select('orders.*');

            $orders = $orders_query->get();
            foreach ($orders as $key => $order) {     
                $date_paid = (!empty($order->payment_date))?$order->payment_date:$order->order_date;
                fputcsv($file, [
                    $order->gateway_transaction_id,
                    $order->orderid,
                    date('d M Y h:i a', strtotime($date_paid)),
                    $order->classStudentRequest->classdetails->course->course_name,
                    $order->classStudentRequest->classdetails->course_name,
                    ($order->classStudentRequest->student)?$order->classStudentRequest->student->name:'',
                    $order->total_seconds/3600,
                    'EGP '.$order->total_amount,                            
                    $order->status,
                ]);
            }
            fclose($file);
        };
        return \Response::stream($callback, 200, $headers);
    }
}
