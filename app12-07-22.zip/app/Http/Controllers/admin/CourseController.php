<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\Course;
use App\ClassDetails;
class CourseController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function index()
    {
        $course_list = Course::where('is_delete','0')->get();
        $course_lists = Course::where('is_delete','0')->where('parent_id','0')->get();
        //$course_lists = Course::where('is_delete','0')->get();
        return view('panel.admin.course.index',compact('course_list','course_lists'));
    }
    public function add_course(Request $request)
    {
        $date = date('Y-m-d h:i:s');
        $parent_id = $request->parent_id;
        $course_name = $request->course_name;
        $description = $request->course_description;
       
        $image = $request->image;
        if(!empty($request->image))
        {
            $profile_pic = ImageUpload::upload('front/course_images/',$request->file('image'));
            $image = $profile_pic;
        }
        else
        {
            $image = 'course_default_img.png';
        }

        $data = array(['parent_id'=>$parent_id,'course_name'=>$course_name,'description'=>$description,'image'=>$image,'created_at'=>$date]);
        Course::insert($data);
        $course_list = Course::where('is_delete','0')->get();
        $course_lists = Course::where('is_delete','0')->get();
        return redirect()->route('course_list')->with(['course_list'=>$course_list,'course_lists'=>$course_lists]);
    }
    public function edit_course(Request $request)
    {
        if($request->editimage != '')
        {
            if($request->editimage != 'front/course_images/course_default_img.png')
            {
                ImageUpload::removeFile('front/course_images/'.$request->image_old);
                $course_pic = ImageUpload::uploadimg('front/course_images/',$request->file('editimage'),$request->course_id);
                $image = $course_pic;
            }
            else
            {
                $course_pic = ImageUpload::uploadimg('front/course_images/',$request->file('editimage'),$request->course_id);
                $image = $course_pic;
            }
        }
        else
        {
           $image =  $request->image_old;
        }

        $data = array('course_name'=>$request->course_name,'description'=>$request->course_description,'parent_id'=>$request->parent_id,'image'=>$image);
        Course::where('id',$request->course_id)->update($data);
        $course_list = Course::where('is_delete','0')->get();
        $course_lists = Course::where('is_delete','0')->get();
        return redirect()->route('course_list')->with(['course_list'=>$course_list,'course_lists'=>$course_lists]);
    }
    public function delete_course($id)
    {
        $course_delete = Course::where('id',$id)->update(['is_delete'=>'1']);
        $course_list = Course::where('is_delete','0')->get();
        $course_lists = Course::where('is_delete','0')->get();
       return redirect()->route('course_list')->with(['course_list'=>$course_list,'course_lists'=>$course_lists]);
    }
    /*----course-----*/

    /*----course type-----*/
    public function course_type()
    {
       $course_list_data = ClassDetails::where('is_delete','0')->get();
       $course_list = Course::where('is_delete','0')->get();
       $course_lists = Course::where('is_delete','0')->get();
       return view('panel.admin.course.course_type',compact('course_list','course_lists','course_list_data'));
    }
    public function add_course_type(Request $request)
    {

        $date = date('Y-m-d h:i:s');
        $parent_id = $request->course_id;
        $course_name = $request->course_name;
        $description = $request->description;
        $image = $request->image;

        $one_to_one_class = isset($request->one_to_one_class) ? $request->one_to_one_class : '0';
        if(!empty($one_to_one_class))
        {
            $one_to_one_60_price = isset($request->one_to_one_60_price) ? $request->one_to_one_60_price : '0';
            $one_to_one_90_price = isset($request->one_to_one_90_price) ? $request->one_to_one_90_price : '0';
            $one_to_one_120_price = isset($request->one_to_one_120_price) ? $request->one_to_one_120_price : '0';
        }
        else
        {
            $one_to_one_60_price = '0';
            $one_to_one_90_price = '0';
            $one_to_one_120_price = '0';
        }
        $buddy_class = isset($request->buddy_class) ? $request->buddy_class : '0';
        if(!empty($buddy_class))
        {
            $buddy_60_price = isset($request->buddy_60_price) ? $request->buddy_60_price : '0';
            $buddy_90_price = isset($request->buddy_90_price) ? $request->buddy_90_price : '0';
            $buddy_120_price = isset($request->buddy_120_price) ? $request->buddy_120_price : '0';
        }
        else
        {
            $buddy_60_price = '0';
            $buddy_90_price = '0';
            $buddy_120_price = '0';
        }
        $batch_class = isset($request->batch_class) ? $request->batch_class : '0';
        if(!empty($batch_class))
        {
            $batch_60_price = isset($request->batch_60_price) ? $request->batch_60_price : '0';
            $batch_90_price = isset($request->batch_90_price) ? $request->batch_90_price : '0';
            $batch_120_price = isset($request->batch_120_price) ? $request->batch_120_price : '0';
        }
        else
        {
            $batch_60_price = '0';
            $batch_90_price = '0';
            $batch_120_price = '0';
        }

        if(!empty($request->image))
        {
            $profile_pic = ImageUpload::upload('front/course_type_images/',$request->file('image'));
            $image = $profile_pic;
        }
        else
        {
            $image = 'course_default_img.png';
        }
        
        $pdf = (!empty($request->pdf)) ? ImageUpload::upload('front/course_pdf/',$request->file('pdf')) : '';
        $data = array(['course_id'=>$parent_id,'course_name'=>$course_name,'one_to_one_class'=>$one_to_one_class,'buddy_class'=>$buddy_class,'batch_class'=>$batch_class,'one_to_one_60_price'=>$one_to_one_60_price,'one_to_one_90_price'=>$one_to_one_90_price,'one_to_one_120_price'=>$one_to_one_120_price,'buddy_60_price'=>$buddy_60_price,'buddy_90_price'=>$buddy_90_price,'buddy_120_price'=>$buddy_120_price,'batch_60_price'=>$batch_60_price,'batch_90_price'=>$batch_90_price,'batch_120_price'=>$batch_120_price,'image'=>$image, 'pdf'=>$pdf,'description'=>$description,'created_at'=>$date]);
        ClassDetails::insert($data);
        $course_list_data = ClassDetails::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->get();
        $course_lists = Course::where('is_delete','0')->get();
        return redirect()->route('course_type')->with(['course_list'=>$course_list,'course_lists'=>$course_lists,'course_list_data'=>$course_list_data]);
    }
    public function edit_course_type(Request $request)
    {
        if($request->editimage != '')
        {
            if($request->editimage != 'front/course_type_images/course_default_img.png')
            {
                ImageUpload::removeFile('front/course_type_images/'.$request->image_old);
                $course_pic = ImageUpload::uploadimg('front/course_type_images/',$request->file('editimage'),$request->course_id);
                $image = $course_pic;
            }
            else
            {
                $course_pic = ImageUpload::uploadimg('front/course_type_images/',$request->file('editimage'),$request->course_id);
                $image = $course_pic;
            }
        }
        else
        {
           $image =  $request->image_old;
        }

        if($request->editpdf != '')
        {
            if($request->pdf_old != '')
            {
                ImageUpload::removeFile('front/course_pdf/'.$request->pdf_old);
                
            }
            $pdf = ImageUpload::uploadimg('front/course_pdf/',$request->file('editpdf'),$request->course_id);
        }
        else
        {
           $pdf =  $request->pdf_old;
        }
        $one_to_one_class = isset($request->one_to_one_class) ? $request->one_to_one_class : '0';
        if(!empty($one_to_one_class))
        {
            $one_to_one_60_price = isset($request->one_to_one_60_price) ? $request->one_to_one_60_price : '0';
            $one_to_one_90_price = isset($request->one_to_one_90_price) ? $request->one_to_one_90_price : '0';
            $one_to_one_120_price = isset($request->one_to_one_120_price) ? $request->one_to_one_120_price : '0';
        }
        else
        {
            $one_to_one_60_price = '0';
            $one_to_one_90_price = '0';
            $one_to_one_120_price = '0';
        }
        $buddy_class = isset($request->buddy_class) ? $request->buddy_class : '0';
        if(!empty($buddy_class))
        {
            $buddy_60_price = isset($request->buddy_60_price) ? $request->buddy_60_price : '0';
            $buddy_90_price = isset($request->buddy_90_price) ? $request->buddy_90_price : '0';
            $buddy_120_price = isset($request->buddy_120_price) ? $request->buddy_120_price : '0';
        }
        else
        {
            $buddy_60_price = '0';
            $buddy_90_price = '0';
            $buddy_120_price = '0';
        }
        $batch_class = isset($request->batch_class) ? $request->batch_class : '0';
        if(!empty($batch_class))
        {
            $batch_60_price = isset($request->batch_60_price) ? $request->batch_60_price : '0';
            $batch_90_price = isset($request->batch_90_price) ? $request->batch_90_price : '0';
            $batch_120_price = isset($request->batch_120_price) ? $request->batch_120_price : '0';
        }
        else
        {
            $batch_60_price = '0';
            $batch_90_price = '0';
            $batch_120_price = '0';
        }
        //dd($batch_class);

        $data = array('course_name'=>$request->course_name,'one_to_one_class'=>$one_to_one_class,'buddy_class'=>$buddy_class,'batch_class'=>$batch_class,'one_to_one_60_price'=>$one_to_one_60_price,'one_to_one_90_price'=>$one_to_one_90_price,'one_to_one_120_price'=>$one_to_one_120_price,'buddy_60_price'=>$buddy_60_price,'buddy_90_price'=>$buddy_90_price,'buddy_120_price'=>$buddy_120_price,'batch_60_price'=>$batch_60_price,'batch_90_price'=>$batch_90_price,'batch_120_price'=>$batch_120_price,'course_id'=>$request->course_id,'description'=>$request->edit_description,'image'=>$image, 'pdf' => $pdf);
        ClassDetails::where('id',$request->course_edit_id)->update($data);
        $course_list_data = ClassDetails::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->get();
        $course_lists = Course::where('is_delete','0')->get();
        return redirect()->route('course_type')->with(['course_list'=>$course_list,'course_lists'=>$course_lists,'course_list_data'=>$course_list_data]);
    }
    public function delete_course_type($id)
    {
        $course_delete = ClassDetails::where('id',$id)->update(['is_delete'=>'1']);
        $course_list_data = Course::where('is_delete','0')->where('parent_id','!=','0')->where('parent_id','!=','1')->where('parent_id','!=','2')->get();
        $course_list = Course::where('is_delete','0')->get();
        $course_lists = Course::where('is_delete','0')->get();
        return redirect()->route('course_type')->with(['course_list'=>$course_list,'course_lists'=>$course_lists,'course_list_data'=>$course_list_data]);
    }
    /*----course type-----*/

}
