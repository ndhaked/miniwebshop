<?php
namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use Validator;
use App\ImageUpload;
use App\FrontHowWorksJoinivy;
use App\FrontVirtualClass;
use App\HomeSlider;
use App\FrontTechnologyHuman;


class FrontController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function how_works_joinivy()
    {
        $howworksjoinivy = FrontHowWorksJoinivy::get();
        return view('panel.admin.front.how_joinivy_works',compact('howworksjoinivy'));
    }
    public function how_works_joinivy_update(Request $request)
    {
        //dd($request->all());
    	$validator = Validator::make($request->all(), [

            'heading1' => 'required',
            'heading2' => 'required',
            'heading3' => 'required',
            'heading4' => 'required',
            'description1' => 'required',
            'description2' => 'required',
            'description3' => 'required',
            'description4' => 'required',
            'image1' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image2' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image3' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image4' => 'mimes:jpeg,png,jpg,gif,svg|max:2048'            

        ],
        [
        	'heading1.required' => 'Heading is Required',
        	'heading2.required' => 'Heading is Required',
        	'heading3.required' => 'Heading is Required',
        	'heading4.required' => 'Heading is Required',
        	'description1.required' => 'Description is Required',
        	'description2.required' => 'Description is Required',
        	'description3.required' => 'Description is Required',
        	'description4.required' => 'Description is Required',
        	'image1.mimes' => 'Invalid Image Type',
        	'image2.mimes' => 'Invalid Image Type',
        	'image3.mimes' => 'Invalid Image Type',
        	'image4.mimes' => 'Invalid Image Type'
        	
        ]
         );
    	if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }

        if(!empty($request->image1))
        {
            $image = $request->image1;
            $image1 = time().'1.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/how_work_joinivy/'),$image1);
        }
        else
        {
            $image1 = $request->image1_old;
        }
        if(!empty($request->image2))
        {
            $image = $request->image2;
            $image2 = time().'2.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/how_work_joinivy/'),$image2);
        }
        else
        {
            $image2 = $request->image2_old;
        }
        if(!empty($request->image3))
        {
            $image = $request->image3;
            $image3 = time().'3.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/how_work_joinivy/'),$image3);
        }
        else
        {
            $image3 = $request->image3_old;
        }
        if(!empty($request->image4))
        {
            $image = $request->image4;
            $image4 = time().'4.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/how_work_joinivy/'),$image4);
        }
        else
        {
            $image4 = $request->image4_old;
        }
        $data = array();
    	$data1 = array('heading'=>$request->heading1,'description'=>$request->description1,'image'=>$image1);
    	$data2 = array('heading'=>$request->heading2,'description'=>$request->description2,'image'=>$image2);
    	$data3 = array('heading'=>$request->heading3,'description'=>$request->description3,'image'=>$image3);
    	$data4 = array('heading'=>$request->heading4,'description'=>$request->description4,'image'=>$image4);
        FrontHowWorksJoinivy::where('id',$request->id1)->update($data1);
        FrontHowWorksJoinivy::where('id',$request->id2)->update($data2);
        FrontHowWorksJoinivy::where('id',$request->id3)->update($data3);
        FrontHowWorksJoinivy::where('id',$request->id4)->update($data4);

        array_push($data,$data1);
        array_push($data,$data2);
        array_push($data,$data3);
        array_push($data,$data4);


        return response()->json(['status' => 1,'data' => $data]);
    }
    public function home_slider()
    {
        $homeslider = HomeSlider::first();
        return view('panel.admin.front.home_slider',compact('homeslider'));
    }
     public function home_slider_update(Request $request)
    {
        //dd($request->all());
        $validator = Validator::make($request->all(), [

            'image_1' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image_2' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image_3' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image_4' => 'mimes:jpeg,png,jpg,gif,svg|max:2048'            

        ],
        [
            'image_1.mimes' => 'Invalid Image Type',
            'image_2.mimes' => 'Invalid Image Type',
            'image_3.mimes' => 'Invalid Image Type',
            'image_4.mimes' => 'Invalid Image Type'
            
        ]
         );
        if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }

        if(!empty($request->image_1))
        {
            $image = $request->image_1;
            $image1 = time().'1.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/slider/'),$image1);
        }
        else
        {
            $image1 = $request->image1_old;
        }
        if(!empty($request->image_2))
        {
            $image = $request->image_2;
            $image2 = time().'2.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/slider/'),$image2);
        }
        else
        {
            $image2 = $request->image2_old;
        }
        if(!empty($request->image_3))
        {
            $image = $request->image_3;
            $image3 = time().'3.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/slider/'),$image3);
        }
        else
        {
            $image3 = $request->image3_old;
        }
        if(!empty($request->image_4))
        {
            $image = $request->image_4;
            $image4 = time().'4.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/slider/'),$image4);
        }
        else
        {
            $image4 = $request->image4_old;
        }
        $data = array('image_1'=>$image1,'image_2'=>$image2,'image_3'=>$image3,'image_4'=>$image4);
        HomeSlider::where('id',1)->update($data);
        return response()->json(['status' => 1,'data' => $data]);
    }
    public function virtual_class()
    {
        $virtualclass = FrontVirtualClass::get();
        return view('panel.admin.front.virtual_class',compact('virtualclass'));
    }
    public function virtual_class_update(Request $request)
    {
        //dd($request->all());
        $validator = Validator::make($request->all(), [

            'heading1' => 'required',
            'heading2' => 'required',
            'heading3' => 'required',
            'heading4' => 'required',
            'description1' => 'required',
            'description2' => 'required',
            'description3' => 'required',
            'description4' => 'required',
            'image1' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image2' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image3' => 'mimes:jpeg,png,jpg,gif,svg|max:2048',            
            'image4' => 'mimes:jpeg,png,jpg,gif,svg|max:2048'            

        ],
        [
            'heading1.required' => 'Heading is Required',
            'heading2.required' => 'Heading is Required',
            'heading3.required' => 'Heading is Required',
            'heading4.required' => 'Heading is Required',
            'description1.required' => 'Description is Required',
            'description2.required' => 'Description is Required',
            'description3.required' => 'Description is Required',
            'description4.required' => 'Description is Required',
            'image1.mimes' => 'Invalid Image Type',
            'image2.mimes' => 'Invalid Image Type',
            'image3.mimes' => 'Invalid Image Type',
            'image4.mimes' => 'Invalid Image Type'
            
        ]
         );
        if ($validator->fails()) 

        {  

            $error=json_decode($validator->errors());          

            return response()->json(['status' => 401,'error1' => $error]);

            exit();

        }

        if(!empty($request->image1))
        {
            $image = $request->image1;
            $image1 = time().'1.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/virtual_class/'),$image1);
        }
        else
        {
            $image1 = $request->image1_old;
        }
        if(!empty($request->image2))
        {
            $image = $request->image2;
            $image2 = time().'2.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/virtual_class/'),$image2);
        }
        else
        {
            $image2 = $request->image2_old;
        }
        if(!empty($request->image3))
        {
            $image = $request->image3;
            $image3 = time().'3.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/virtual_class/'),$image3);
        }
        else
        {
            $image3 = $request->image3_old;
        }
        if(!empty($request->image4))
        {
            $image = $request->image4;
            $image4 = time().'4.'.$image->getClientOriginalExtension();
            $image->move(public_path('front/virtual_class/'),$image4);
        }
        else
        {
            $image4 = $request->image4_old;
        }
        $data = array();
        $data1 = array('heading'=>$request->heading1,'description'=>$request->description1,'image'=>$image1);
        $data2 = array('heading'=>$request->heading2,'description'=>$request->description2,'image'=>$image2);
        $data3 = array('heading'=>$request->heading3,'description'=>$request->description3,'image'=>$image3);
        $data4 = array('heading'=>$request->heading4,'description'=>$request->description4,'image'=>$image4);
        FrontVirtualClass::where('id',$request->id1)->update($data1);
        FrontVirtualClass::where('id',$request->id2)->update($data2);
        FrontVirtualClass::where('id',$request->id3)->update($data3);
        FrontVirtualClass::where('id',$request->id4)->update($data4);

        array_push($data,$data1);
        array_push($data,$data2);
        array_push($data,$data3);
        array_push($data,$data4);


        return response()->json(['status' => 1,'data' => $data]);
    }
    public function technology_human()
    {
        $technology_list = FrontTechnologyHuman::get();
        return view('panel.admin.front.technology_human',compact('technology_list'));
    }
    public function technology_human_update(Request $request)
    {
        //dd($request->all());
        $validator = Validator::make($request->all(), [

            'description1' => 'required',
            'description2' => 'required',
            'description3' => 'required',
            'description4' => 'required',        
            'description5' => 'required'         
        ],
        [
            'description1.required' => 'Description is Required',
            'description2.required' => 'Description is Required',
            'description3.required' => 'Description is Required',
            'description4.required' => 'Description is Required',            
            'description5.required' => 'Description is Required'            
        ]
         );
        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();

        }

        $data = array();
        $data1 = array('icon'=>$request->icon_select1,'description'=>$request->description1);
        $data2 = array('icon'=>$request->icon_select2,'description'=>$request->description2);
        $data3 = array('icon'=>$request->icon_select3,'description'=>$request->description3);
        $data4 = array('icon'=>$request->icon_select4,'description'=>$request->description4);
        $data5 = array('icon'=>$request->icon_select5,'description'=>$request->description5);
        FrontTechnologyHuman::where('id',$request->id1)->update($data1);
        FrontTechnologyHuman::where('id',$request->id2)->update($data2);
        FrontTechnologyHuman::where('id',$request->id3)->update($data3);
        FrontTechnologyHuman::where('id',$request->id4)->update($data4);
        FrontTechnologyHuman::where('id',$request->id5)->update($data5);

        array_push($data,$data1);
        array_push($data,$data2);
        array_push($data,$data3);
        array_push($data,$data4);
        array_push($data,$data5);


        return response()->json(['status' => 1,'data' => $data]);
    }
}
