<?php
namespace App\Http\Controllers\front;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB; 
use Auth; 
use Validator;
use Carbon\Carbon;
use Mail;
use App\Mail\EnrollsEmail;
use App\Mail\ScheduleClassEmail;
use View;
use App\Course;
use App\User;
use App\ClassDetails;
use App\ScheduleClass;
use App\ClassStudentRequest;
use App\BuddyClassStudentRequest;
use App\AddAttendeeStudentClass;

use App\EventSchedule;



class MenuController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware(function ($request, $next)
    //     {
    //         if (!Auth::user()) 
    //         {
    //             return redirect('/');
    //         }
    //         return $next($request);
    //     });
    // }

    public function __construct()
    {
        $courses_header = Course::where('parent_id',1)->where('is_delete','=',0)->get();
        $courses2_header = Course::where('parent_id',2)->where('is_delete','=',0)->get();
        View::share(['courses_header'=>$courses_header,'courses2_header'=>$courses2_header]);
        
    }

    public function course_offered()
    {
       
        // type 1
        $courses = Course::where('parent_id',1)->where('is_delete','=',0)->get();
        //type 2
        $courses2 = Course::where('parent_id',2)->where('is_delete','=',0)->get();
        
        return view('front.course_offered',compact('courses','courses2'));
    }

    public function courseOfferedSingle($id)
    {
        
        $course = ClassDetails::where('id',$id)->where('is_delete','=',0)->first();
        $get_title = Course::where('id',$course->course_id)->where('is_delete','=',0)->first();
        
        $course_details = ClassDetails::where('course_id',$id)->where('is_delete','=',0)->get();
        foreach ($course_details as $key => $value) 
        {
            $batch = DB::table('schedule_class')->where('class_type','=',3)->where('class_name',$value->id)->where('schedule_class.is_delete', '=', 0)
            ->join('class_details', 'schedule_class.course_id', '=', 'class_details.id')
            ->select('schedule_class.*', 'class_details.course_name')
            ->first();
            $value->batch = $batch;

        }
        //dd($course_details->toArray());

       

        return view('front.course_offered_single',compact('course','get_title','course_details'));


    }

    public function student_parent()
    {
        return view('front.student_parent');
    }
    public function fee_plan()
    {
        return view('front.fee_plan');
    }
    public function teachers()
    {
        return view('front.teachers');
    }
    public function faq()
    {
        return view('front.faq');
    }
    public function contact()
    {
        return view('front.contact');
    }
    public function about()
    {
        return view('front.about');
    }
    public function virtual_class()
    {
        return view('front.virtual_class');
    }
    public function teacher_terms_condition()
    {
        return view('front.terms_condition_teacher');
    }
    public function student_terms_condition()
    {
        return view('front.terms_condition_student');
    }
    public function comman_terms_condition()
    {
        return view('front.comman_terms_condition');
    }
    public function comman_privacy_policy()
    {
        return view('front.comman_privacy_policy');
    }
    public function thankyou()
    {
        return view('front.thankyou');
    }
    public function student_thankyou()
    {
        return view('front.student_thankyou');
    }
    public function helpdesk()
    {
        return view('front.helpdesk');
    }
    public function support()
    {
        return view('front.support');
    }
     public function sitemap()
    {
        return view('front.sitemap');
    }
    

    // courseEnrol
    public function courseEnrol($id)
    {
        if (!Auth::user()) 
        {
            session(['url.intended' => url()->full()]);
            return redirect('/login');
        }

        // $course_name = ClassDetails::where('id',$id)->where('is_delete','=',0)->first();
        // $course_type = ClassDetails::where('id',$id)->where('is_delete','=',0)->first();
        
        // $batch = DB::table('schedule_class')->where('class_type','=',3)->where('class_name',$id)
        //     ->join('class_details', 'schedule_class.course_id', '=', 'class_details.id')
        //     ->select('schedule_class.*', 'class_details.course_name')
        //     ->first();
        // $course_type->batch = $batch;
        
        $student_list = array();
        if(Auth::user()->user_type=='4'){
            $student_list = User::where('parent_id',Auth::user()->id)->where('is_delete','0')->where('user_type','3')->get();
         
        }

        $class_type = classType();
        $course_name = ClassDetails::where('id',$id)->where('is_delete','=',0)->first(); 
        $batch_names = ScheduleClass::where('class_name',$id)->where('class_type','3')->where('is_delete','=',0)->get();
        

        return view('front.course_enrol',compact('course_name','class_type','batch_names','student_list'));

    }

    public function courseEnrolAdd(){
        $user = auth()->user();
        $request = request()->all();
        $validator = Validator::make($request, [
            'batch_name' => 'required_if:type,3',
            'student_id' => 'required',
            'type' => 'required',
            'time_duration' => 'required_if:type,1',
             
         ],
        [
          // 'days_of_week[].required_if' => 'The select days.',
          'batch_name.required_if' => 'Please select a Batch to view it\'s details.',
          'student_id.required' => 'This field is required.',
          'type.required' => 'This field is required.',
          'time_duration.required_if' => 'This field is required.'
        ]);

        $days_of_week = array();

        if(isset($request['type']) && $request['type']=="1"){
            if(!isset($request['days_of_week'])){
                $days_of_week[] = 'Please select atleaast one day and time' ;
            }
            else{ 
              foreach ($request['days_of_week'] as $key => $day) { //dd($request[$day.'_time']);
                  if(is_null($request[$day.'_time']) || $request[$day.'_time']==''){
                    $days_of_week[] = 'Please enter time for '.$day;

                  }
              }

            }
        }
        $student_error = array();
        if((isset($request['batch_name']) && $request['batch_name']!="") && (isset($request['student_id']) && $request['student_id']!="") && (isset($request['type']) && $request['type']=="3")){
            $student_exist = ClassStudentRequest::where('schedule_class_id',$request['batch_name'])->where('is_delete','0')->where('student_id',$request['student_id'])->first();

            if(!empty($student_exist)){
                $student_error[] = 'Already enrolled for this batch' ;
            }
        }
        
        
        

        if ($validator->fails() || !empty($days_of_week) || !empty($student_error)) 
        {  
            $error=json_decode($validator->errors());

            if(!empty($error)){
                foreach ($days_of_week as $key => $err) {
                  $error->days_of_week[] =$err;
               }

               foreach ($student_error as $key => $err) {
                  $error->batch_name[] =$err;
               }
            }
            else{
                $error['days_of_week']=$days_of_week;
                $error['batch_name']=$student_error;
            }
        
            
                  
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $schedule_data = [];
        $days_of_week = request('days_of_week');
        if(!empty($days_of_week)){
            foreach ($days_of_week as $key => $day) {
                $schedule_data[$day] = request($day.'_time');
            }
        }
        


        $input = array();
        if(request('type')=='1'){
            $input['class_details_id'] = request('class_id');
            $input['class_types'] = request('type');
            $input['student_id'] = request('student_id');
            $input['duration'] = request('time_duration');
            $input['creator_id'] = \Auth::user()->id;
            $input['session_start_date'] = date('Y-m-d H:i:s');
            $input['session_end_date'] = date('Y-m-d H:i:s');
            $input['schedule_data'] = serialize($schedule_data);
            $input['schedule_type'] = '4';
            $input['schedule_class_url'] = '';
            $input['created_at'] = date('Y-m-d H:i:s');
            $input['updated_at'] = date('Y-m-d H:i:s');
        }
        elseif(request('type')=='3'){
            $schedule_class = ScheduleClass::find(request('batch_name'));
            $input['schedule_class_id'] = request('batch_name');
            $input['class_details_id'] = $schedule_class->class_name; 
            $input['class_types'] = request('type');
            $input['student_id'] = request('student_id');
            $input['duration'] = $schedule_class->duration;
            $input['creator_id'] = \Auth::user()->id;
            $input['session_start_date'] = date('Y-m-d H:i:s');
            $input['session_end_date'] = date('Y-m-d H:i:s');
            $input['schedule_data'] = serialize(array());
            $input['schedule_type'] = '4';
            $input['schedule_class_url'] = '';
            $input['created_at'] = date('Y-m-d H:i:s');
            $input['updated_at'] = date('Y-m-d H:i:s');
        }
        
        ClassStudentRequest::insert($input);
        

        return response()->json(['success'=>true,"status"=> '1'], 200);
    }


    /*** old code ***/
    //courseEnrolAdd
    // public function courseEnrolAdd()
    // {
    //     $user = auth()->user();
        
       
    //     if (request('type') == 2) 
    //     {
    //         $validator = Validator::make(request()->all(), [
    //         'email' => 'required',
    //         'email.*' => 'email'
    //         ],
    //         [
    //             'email.*' => 'The email must be a valid email address.'
    //         ]);
    //         if ($validator->fails()) 
    //         {  
    //             $error=json_decode($validator->errors());          
    //             return response()->json(['status' => 401,'error1' => $error]);
    //             exit();
    //         }

    //         // current user first insert
    //         $input = array();
    //         $input['class_details_id'] = request('class_id');
    //         $input['class_types'] = request('type');
    //         $input['student_id'] = $user->id;
    //         $input['registration_status'] = 1;
    //         $input['student_email_id'] = $user->email;
    //         $input['duration'] = request('time_duration');
    //         $input['session_start_date'] = request('start_date');
    //         $input['session_end_date'] = request('end_date');
    //         $input['session_start_time'] = request('start_time');
    //         $input['session_end_time'] = request('end_time');
    //         $input['sessions_per_week'] = request('per_week');
    //         $input['weeks_enrolling'] = request('r_week_enrol');
    //         $input['total_sessions_per_weeks'] = request('total_sessions');
    //         $input['fee_per_session'] = request('r_fee');
    //         $input['total_fee'] = request('total_enrol_fee');
    //         $input['created_at'] = date('Y-m-d H:i:s');
    //         $input['updated_at'] = date('Y-m-d H:i:s');
    //         ClassStudentRequest::insert($input);

    //         $parent_id = DB::getPdo()->lastInsertId();

    //         $count = count(request('email'));
    //         for ($i=0; $i < $count; $i++) 
    //         { 
    //             $input = array();
    //             $input['class_details_id'] = request('class_id');
    //             $input['class_types'] = request('type');
    //             $input['student_email_id'] = request('email')[$i];

    //             $check = User::where('email',request('email')[$i])->where('is_delete', '=' , 0)->first();
    //             if($check == null) 
    //             {
    //                 $input['student_id'] = 0;
    //                 $input['registration_status'] = 0;
    //             }
    //             else
    //             {   
    //                 $input['student_id'] = $check->id;
    //                 $input['registration_status'] = 1;
    //             }
    //             $userId = Auth::id();
    //             $input['buddy_owner_id'] = $userId;
    //             $input['parent_id'] = $parent_id;
    //             $input['duration'] = request('time_duration');
    //             $input['session_start_date'] = request('start_date');
    //             $input['session_end_date'] = request('end_date');
    //             $input['session_start_time'] = request('start_time');
    //             $input['session_end_time'] = request('end_time');
    //             $input['sessions_per_week'] = request('per_week');
    //             $input['weeks_enrolling'] = request('r_week_enrol');
    //             $input['total_sessions_per_weeks'] = request('total_sessions');
    //             $input['fee_per_session'] = request('r_fee');
    //             $input['total_fee'] = request('total_enrol_fee');
    //             $input['created_at'] = date('Y-m-d H:i:s');
    //             $input['updated_at'] = date('Y-m-d H:i:s');
    //             ClassStudentRequest::insert($input);
                
    //         }
    //         return response()->json(['status' => 1]);
    //     } 
    //     else
    //     {
    //         $input = array();
    //         $input['class_details_id'] = request('class_id');
    //         $input['class_types'] = request('type');
    //         $input['student_id'] = request('student_id');
    //         $input['student_email_id'] = $user->email;
    //         $input['registration_status'] = 1;
    //         $input['duration'] = request('time_duration');
    //         $input['session_start_date'] = request('start_date');
    //         $input['session_end_date'] = request('end_date');
    //         $input['session_start_time'] = request('start_time');
    //         $input['session_end_time'] = request('end_time');
    //         $input['sessions_per_week'] = request('per_week');
    //         $input['weeks_enrolling'] = request('r_week_enrol');
    //         $input['total_sessions_per_weeks'] = request('total_sessions');
    //         $input['fee_per_session'] = request('r_fee');
    //         $input['total_fee'] = request('total_enrol_fee');
    //         $input['created_at'] = date('Y-m-d H:i:s');
    //         $input['updated_at'] = date('Y-m-d H:i:s');
    //         ClassStudentRequest::insert($input);

    //         $objDemo = new \stdClass();
    //         $objDemo->sender = 'JoinIvy';

    //         // $objDemo->receiver = $check_email[0]->name;


    //         Mail::to("info@Joinivy.com")->send(new EnrollsEmail($objDemo));
    //         return response()->json(['status' => 1]);

    //     }  
        
    //     return response()->json(['status' => 401]);
    // }


    // Second Thank You Page
    public function thankYou1()
    {

        return view('front.thankyou1');

    }


    // Learn More
    public function learnMore($id)
    {
        /*if (!Auth::user()) 
        {
            return redirect('/');
        }*/

        $course_details = ClassDetails::where('id',$id)->where('is_delete','=',0)->first();

        $get_title = Course::where('id',$course_details->course_id)->where('is_delete','=',0)->first();
        $get_type = Course::where('id',$get_title->parent_id)->where('is_delete','=',0)->first();


        return view('front.learn_more',compact('course_details','get_type'));
    }


    public function getBatch(Request $request)
    {
        // dd(request()->all());
        $batch = DB::table('schedule_class')->where('class_type','=',3)->where('class_name',$request->batch_id)
            ->join('class_details', 'schedule_class.course_id', '=', 'class_details.id')
            ->select('schedule_class.*', 'schedule_class.id as s_id', 'class_details.*')
            ->first();

        $start_date = date("Y-m-d", strtotime($batch->date));
        $end_date = date("Y-m-d", strtotime($batch->end_date));

        
        if ($batch->week == null) 
        {


            $date = date("Y-m-d", strtotime($batch->date));
            $week = date('l', strtotime($date));

            if ($batch->repeat_type == 0) 
            {
                // $batch->week = $week;
                // $count = count($batch->week);
                $total_weeks = ceil(abs(strtotime($start_date) - strtotime($end_date)) / 60 / 60 / 24 / 7);
                $count = (int)$total_weeks;
                $batch->week = $total_weeks ? 0 : 1; ;
            }
            else
            {
                $total_weeks = ceil(abs(strtotime($start_date) - strtotime($end_date)) / 60 / 60 / 24 / 7);
                $count = (int)$total_weeks;
                $batch->week = $total_weeks ? 0 : 1; 
            }

            

        }    
        else
        {
            // $total_weeks = ceil(abs(strtotime($start_date) - strtotime($end_date)) / 60 / 60 / 24 / 7);
            // $count = (int)$total_weeks;
            $tat = explode(",",$batch->week);    
            $count = count($tat);
        }
        

        if ($batch->repeat_type != 0) 
        {
            $repeat_every = $batch->repeat_type;
        }
        else if ($batch->repeat_every == null) 
        {

            $repeat_every = $batch->repeat_every ? '' : 1;
        }
        elseif ($batch->repeat_every != null) 
        {
            // $repeat_every = $batch->repeat_every;
            $total_weeks = ceil(abs(strtotime($start_date) - strtotime($end_date)) / 60 / 60 / 24 / 7);
            $repeat_every = (int)$total_weeks;
        }
        else
        {
            $repeat_every = $batch->repeat_type ? 0 : 1;
        }
        
        


        $check_limit = AddAttendeeStudentClass::where('schedule_class_id', '=',$batch->s_id)->count();
        // echo $check_limit;
        $total_class = $batch->class_limit - $check_limit;

       if ($batch->class_limit == $check_limit) 
       {
       ?>

        <div class="row">
            <div class="col-md-12 text-center">
                <h1 style="color: red;"> Class Limit End. </h1>
            </div>
        </div>


       <?php
       }
       else
       {
       ?>

            <div class="row">

               <input type="hidden" name="batch_class_id" id="batch_class_id" value="<?php echo $batch->class_name; ?>">
               <input type="hidden" name="student_id" id="student_id" value="<?php echo Auth::user()->id; ?>">
               <input type="hidden" name="student_email" id="student_email" value="<?php echo Auth::user()->email; ?>">

                <div class="col-md-6"> 
                    <div class="form-group">
                        <label for="email">Session duration:</label>
                        <input type="text" name="" id="duration" value="<?php echo $batch->duration; ?>" readonly="" class="form-control">
                    </div>
                </div>
           
                <div class="col-md-6">
                 <div class="form-group">
                        <label for="email">Class Limit:</label> 
                        <input type="text" name="" value="<?php echo $total_class; ?>" readonly="" class="form-control">
                        <label style="color: red;"><?php echo $total_class; ?> class left.</label>
                </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                <div class="form-group">
                    <label for="email">Class Date & Time :</label>
                    <input type="text" name="" id="date" value="<?php echo $batch->date; ?>" readonly="" class="form-control">
                </div>
                </div>
                 <div class="col-md-6">
                <div class="form-group">
                    <label for="email">Class End Date:</label>
                    <input type="text" name="" id="end_date" value="<?php echo $batch->end_date; ?>" readonly="" class="form-control">
                </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                <div class="form-group">
                    <label for="email">Repeat Every :</label>
                    <input type="text" name="" id="repeat_every" value="<?php echo $repeat_every; ?>" readonly="" class="form-control">
                </div>
                </div>
                 <div class="col-md-6">
                <div class="form-group">
                    <label for="email">Week :</label>
                    <input type="text" name="" id="week" value="<?php echo $batch->week; ?>" readonly="" class="form-control">
                </div>
                </div>
            </div>

            <?php if ($batch->duration == 60) 
            {
            ?>

                <div class="row">
                <div class="col-md-12">
                <div class="form-group">
                    <!-- <label for="email">Fee per session : </label>
                    <? echo '₹ '.$batch->one_to_one_60_price; ?> -->
                    <input type="hidden" name="" id="fee_per_s" value="<?php echo $batch->one_to_one_60_price; ?>">

                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <!-- <label for="email"> Total Fee : </label>
                    <? echo '₹ '.$batch->one_to_one_60_price * $repeat_every; ?> -->
                    <input type="hidden" name="" id="total_fee" value="<?php echo $batch->one_to_one_60_price * $repeat_every; ?>">

                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <!-- <label for="email"><?php echo 'No. of sessions per week : '; ?></label> <?php echo $count.' Week'; ?> <br>
                    <?php $dis = '₹ '.$batch->one_to_one_60_price * $repeat_every.'&nbsp;&nbsp;X&nbsp;&nbsp;'.  $count.' Weeks'; ?>
                    <label>Total Amount : </label> 
                    <?php echo $dis.'&nbsp;&nbsp;=&nbsp;&nbsp;'.$batch->one_to_one_60_price * $repeat_every * $count; ?> -->
                </div>
                </div>
                <div class="col-lg-12 col-md-12 col-12 pt-5 pb-5">
                  <div id="divider"></div>
                    <div class="col-lg-12 col-md-12 col-12 text-center">
                      <button type="submit" id="confirm_batch" onclick="a();" class="btn btn-success btn-lg">Confirm</button>
                    </div>
                </div>
                </div>

            <?php 
            } 
            ?>

            <?php if ($batch->duration == 90) 
            {
            ?>

                <div class="row">
                <div class="col-md-12">
                <div class="form-group">
                    <!-- <label for="email">Fee per session : </label>
                    <? echo '₹ '.$batch->one_to_one_90_price; ?> -->
                    <input type="hidden" name="" id="fee_per_s" value="<?php echo $batch->one_to_one_90_price; ?>">

                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <!-- <label for="email"> Total Fee : </label>
                    <? echo '₹ '.$batch->one_to_one_90_price * $repeat_every; ?> -->
                    <input type="hidden" name="" id="total_fee" value="<?php echo $batch->one_to_one_90_price * $repeat_every; ?>">
                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                   <!--  <label for="email"><?php echo 'No. of sessions per week : '; ?></label> <?php echo $count.' Week'; ?> <br>
                    <?php $dis = '₹ '.$batch->one_to_one_90_price * $repeat_every.'&nbsp;&nbsp;X&nbsp;&nbsp;'.  $count.' Weeks'; ?>
                    <label>Total Amount : </label> 
                    <?php echo $dis.'&nbsp;&nbsp;=&nbsp;&nbsp;'.$batch->one_to_one_90_price * $repeat_every * $count; ?> -->

                </div>
                </div>
                <div class="col-lg-12 col-md-12 col-12 pt-5 pb-5">
                  <div id="divider"></div>
                    <div class="col-lg-12 col-md-12 col-12 text-center">
                      <button type="submit" id="confirm_batch" onclick="a();" class="btn btn-success btn-lg">Confirm</button>
                    </div>
                </div>
                </div>

            <?php 
            } 
            ?>


            <?php if ($batch->duration == 120) 
            {
            ?>

                <div class="row">
                <div class="col-md-12">
                <div class="form-group">
                    <!-- <label for="email">Fee per session : </label>
                    <? echo '₹ '.$batch->one_to_one_120_price; ?> -->
                    <input type="hidden" name="" id="fee_per_s" value="<?php echo $batch->one_to_one_120_price; ?>">

                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                   <!--  <label for="email"> Total Fee : </label>
                    <? echo '₹ '.$batch->one_to_one_120_price * $repeat_every; ?> -->
                    <input type="hidden" name="" id="total_fee" value="<?php echo $batch->one_to_one_120_price * $repeat_every; ?>">
                </div>
                </div>
                <div class="col-md-12">
                <div class="form-group">
                    <!-- <label for="email"><?php echo 'No. of sessions per week : '; ?></label> <?php echo $count.' Week'; ?> <br>
                    <?php $dis = '₹ '.$batch->one_to_one_120_price * $repeat_every.'&nbsp;&nbsp;X&nbsp;&nbsp;'.  $count.' Weeks'; ?>
                    <label>Total Amount : </label> 
                    <?php echo $dis.'&nbsp;&nbsp;=&nbsp;&nbsp;'.$batch->one_to_one_120_price * $repeat_every * $count; ?> -->

                </div>
                </div>
                <div class="col-lg-12 col-md-12 col-12 pt-5 pb-5">
                  <div id="divider"></div>
                    <div class="col-lg-12 col-md-12 col-12 text-center">
                      <button type="submit" id="confirm_batch" onclick="a();" class="btn btn-success btn-lg">Confirm</button>
                    </div>
                </div>
                </div>

            <?php 
            } 
            ?>


       <?php
       }            
        

    }



    public function AddBatch(Request $request)
    {
        


        $created_at = Carbon::now(); 

        $time_date = request('date');

        $time = date("H:i:s", strtotime(request('date')));
        $date = date("Y-m-d", strtotime(request('date')));

        $enrolling = explode(",",request('week'));

        // d($a);

        $count = count($enrolling);
        // dd($time.' '.$date);
        
       $addClass = array(); 
       $addClass['class_details_id'] = request('class_id');
       $addClass['class_types'] = 3;
       $addClass['student_id'] = request('student_id');
       $addClass['student_email_id'] = request('student_email');
       $addClass['registration_status'] = 1;
       $addClass['duration'] = request('duration');
       $addClass['date'] = $date;
       $addClass['time'] = $time;
       $addClass['session_start_date'] = $date;
       $addClass['session_end_date'] = request('end_date');
       $addClass['sessions_per_week'] = request('repeat_every');
       $addClass['weeks_enrolling'] =  $count;
       $addClass['total_sessions_per_weeks'] =  $count;
       $addClass['fee_per_session'] =  request('fee_per_s');
       $addClass['total_fee'] =  request('total_fee');
       $addClass['created_at'] = $created_at; //2019-09-28
       // dd($addClass);
       ClassStudentRequest::insert($addClass);

       
        $class_details = ClassDetails::where('id',$request->class_id)->first();
        $class_name = $class_details->course_name;

        //dd($class_name);

        $objDemo = new \stdClass();
        $objDemo->sender = 'JoinIvy';
        $objDemo->date = $request->date;
        $objDemo->teacher_name = 'not allow teacher';
        $objDemo->class_name = $class_name; 

        // dd($objDemo);

        Mail::to($request->student_email)->send(new ScheduleClassEmail($objDemo));
        // dd($request->all());die;
       return response()->json(['status' => 1]);
    }

    public function getBatchDetails(Request $request)
    {
        
        $batch_id = $request->batch_id;
        $frequencytype= getFrequency();
        $event_sessions = ScheduleClass::where('schedule_class.id',$batch_id)
            ->join('event_sessions', 'event_sessions.schedule_class_id', '=', 'schedule_class.id')  
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.batch_name','schedule_class.date', 'schedule_class.class_type')
            ->first(); 
        
        $batch_schedule = array();
        if(!empty($event_sessions)){

            $batch_name = $event_sessions->batch_name;
            $class_type = $event_sessions->class_type;
            $duration = $event_sessions->duration;           

            $event_schedule = EventSchedule::where('schedule_class_id',$batch_id)->where('is_delete','0')->orderby('start_date','asc')->get()->toArray();
            $batch_start_date = $event_sessions->date;
            
            $batch_schedule['batch_name'] = $batch_name;
            $batch_schedule['class_type'] = $class_type;
            $batch_schedule['duration'] = $duration;
            
            $batch_schedule['start_date'] = date('dS F Y',strtotime($batch_start_date));
            
            $batch_schedule_data =array();
            foreach ($event_schedule as $key => $schedule) {
                $batch_schedule['frequency'] = $frequencytype[$schedule['schedule_type']];
                if($schedule['schedule_type']=='0'){
                    $batch_schedule_data[] = date('H:i A',strtotime($schedule['start_time']));
                }
                else{
                    $batch_schedule_data[] = ucfirst($schedule['day']).', '.date('H:i A',strtotime($schedule['start_time']));
                }
            }
            $batch_schedule['batch_schedule_data'] = $batch_schedule_data;
        }
         

        return response()->json(['status' => 1,'batch_schedule' => $batch_schedule]);

    }

}
