<?php
namespace App\Http\Controllers\front;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Hash;
use DB;
use Auth;
use Session;
use View;
use App\Course;

class  LoginsController extends Controller
{   
     public function __construct()
    {
        $courses_header = Course::where('parent_id',1)->where('is_delete','=',0)->get();
        $courses2_header = Course::where('parent_id',2)->where('is_delete','=',0)->get();
        View::share(['courses_header'=>$courses_header,'courses2_header'=>$courses2_header]);
        
    }
    public function index()
    {
        return view('front.register');
    }

    public function register(Request $request)
    {
     
        $password = $request->password;
        $password_confirmation = $request->password_confirmation;
        $p_password = $request->p_password;
        $p_confirmation = $request->p_password_confirmation;
        $date = date("Y-m-d H:i:s");
        if($p_password===$p_confirmation)
        {
            $p_password = Hash::make($request->password);
        	$p_data = array('parent_id'=>'0','user_type'=>'2','p_relation_student'=>$request->p_relation_student,'name'=>$request->p_name,'email'=>$request->p_email,'mobile'=>$request->p_mobile,'residence_address'=>$request->p_r_address,'password'=>$p_password,'created_at'=>$date);
        	$id = DB::table('users')->insertGetId($p_data);
        }
        $dob = date("Y-m-d",strtotime($request->s_dob));
        if($password===$password_confirmation)
        {
            $password = Hash::make($request->password);
       		$data = array('parent_id'=>$id,'user_type'=>'3','name'=>$request->name,'s_dob'=>$dob,'s_nationality'=>implode(',',$request->nationality),'s_native_language'=>implode(',',$request->native_language),'s_residence_country'=>implode(',',$request->residence_country),'school_name'=>$request->school_name,'school_address'=>$request->school_address,'curriculum_type'=>$request->curriculum_type,'school_type'=>$request->school_type,'email'=>$request->email,'mobile'=>$request->mobile,'residence_address'=>$request->r_address,'password'=>$password,'referrer_name'=>$request->r_name,'referrer_mobile'=>$request->r_mobile,'referrer_email'=>$request->r_email,'created_at'=>$date);
       	    DB::table('users')->insert($data);
        }
        return redirect()->route('f_home');
    }
    public function login(Request $request)
    {
        if (Auth::attempt ( array (
                'email' => $request->email,
                'password' => $request->password,
                'user_type' => $request->user_type 
        ) )) {
            session ( [ 
                    'name' => $request->get ( 'email' ) 
            ] );
             return redirect()->route('f_home');
        } else {
             return redirect()->route('f_home')
                    ->with('message', 'Your username and password combination is wrong');
        }
       
    }
     public function f_logout()
    {
       Auth::logout();
       return redirect('/');
    }
}
