<?php
namespace App\Http\Controllers\front;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use App\User;
use App\Course;
use App\ClassDetails;
use App\ScheduleClass;
use App\FrontHowWorksJoinivy;
use App\FrontVirtualClass;
use App\FrontTechnologyHuman;
use App\HomeSlider;
use View;
use PayMob;

use App\EventSession;

class HomeController extends Controller
{
    public function __construct()
    {
        $courses_header = Course::where('parent_id',1)->where('is_delete','=',0)->get();
        $courses2_header = Course::where('parent_id',2)->where('is_delete','=',0)->get();
        View::share(['courses_header'=>$courses_header,'courses2_header'=>$courses2_header]);
        
    }

    public function verifyUserToken($token){

      if(Auth::check()){
        $user = User::where('verification_token',$token)->where('id', loggedInUser()->id)->first();
        $route = getDashboardPath();
      }
      else{
        $user = User::where('verification_token',$token)->first();
        $route ='/login';
      }
      

      if(empty($user)){
        return redirect('/');
      }
      else{
        if($user->account_status == 'active'){
          return redirect($route.'?verification=already_verified');
        }
        else{
          if($user->user_type=='4'){
              DB::table('users')->where('parent_id',$user->id)->update(['account_status' => 'active']);
          }
          elseif($user->user_type == '3' && $user->parent_id != 0){
            DB::table('users')->where('id',$user->parent_id)->update(['account_status' => 'active']);
          }
          $user->account_status = 'active';
          $user->save();
          return redirect($route.'?verification=verified');
        }
        
        
      }

    }

    public function userLogino(){
        \Session::put('redirect_before_login_url', \URL::previous());
        return view('front.userlogin');
    }


     public function test()
    {

       

      $auth = PayMob::authPaymob();
      // Run this method to get a sample response of auth request.
      PayMob::sample('authPaymob');



        /*$paymobOrder = PayMob::makeOrderPaymob(
            $auth->token, // this is token from step 1.
            $auth->profile->id, // this is the merchant id from step 1.
            10 * 100, // total amount by cents/piasters.
            10 // your (merchant) order id.
        );
        // Run this method to get a sample response of make order request.
        PayMob::sample('makeOrderPaymob');*/


        //print_r($paymobOrder);

      $paymentKey = PayMob::getPaymentKeyPaymob(
          $auth->token, // from step 1.
          10 * 100, // total amount by cents/piasters.
          //$paymobOrder->id, // paymob order id from step 2.
          3685505,
          // For billing data
          'ravi.vagadiya@gmail.com', // optional
          'ravi vagadiya', // optional
          'vagadiya ravi', // optional
          '8000099907', // optional
          'ravivagadiya11', // optional
          'india' // optional
      );
      // Run this method to get a sample response of payment key request.
      PayMob::sample('getPaymentKeyPaymob');








      //dd($paymentKey);
        return view('front.test',compact('paymentKey'));
        //return view('front.test');
    }
    public function index()
    {
       return redirect(config('constants.MARKETING_SITE_URL'));
       
       $get_courses_type = Course::where('is_delete','0')->get();
       $get_courses_type_ex = Course::where('is_delete','0')->get();
       $get_courses_details = ClassDetails::where('is_delete','0')->get();
       $howjoinivyworks = FrontHowWorksJoinivy::get();
       $homeslider = HomeSlider::first();
       $virtual_class = FrontVirtualClass::get();
       $front_technology_human = FrontTechnologyHuman::get();
      //   $get_course_name = request()->all();
       // $courses_header = ClassDetails::where('is_delete','0')->where('batch_class')->get();

        $courses_header11 = ClassDetails::where('is_delete','=',0)->get();
        foreach ($courses_header11 as $key => $value) 
        {
            $batch = DB::table('schedule_class')->where('class_type','=',3)->where('class_name',$value->id)->where('schedule_class.is_delete', '=', 0)
            ->join('class_details', 'schedule_class.course_id', '=', 'class_details.id')
            ->select('schedule_class.*', 'class_details.course_name')
            ->first();
            $value->batch = $batch;

        }


       return view('front.welcome',compact('get_courses_type','get_courses_details','get_courses_type_ex','howjoinivyworks','homeslider','virtual_class','front_technology_human','courses_header11'));
    }

    public function userDashboardRedirect(){
      return redirect('/');
    }

    public function get_logged_user(){
      if(Auth::check()){
        $user = Auth::user();
      }
      else{
        $user = false;
      }

      return response()->json(['status' => 1,'data' => $user],200);
    }

    public function getClasses(){
        $request = request()->all();
        $class_types=classType(); 
        $start_date = $request['start'];
        $end_date = $request['end'];

        // $event_sessions = \App\EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
        //     ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
        //     ->where('schedule_class.is_delete','0')->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])
        //     ->where('schedule_class.is_delete','0') 
        //     ->where('event_sessions.is_delete','0')
        //     ->where('class_students_request.is_delete','0')
        //     ->where('class_students_request.status','1')
        //     ->where('start_date','>=',$start_date)->where('start_date','<=',$end_date);

        $event_sessions = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id'); 
        if(loggedInUser()->user_type=="3"){
          $event_sessions->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id'); 
        }  
        $event_sessions->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->where('event_sessions.status','!=','canceled')
                      
            ->where('event_sessions.start_date','>=',$start_date.' 00:00:00')->where('event_sessions.start_date','<=',$end_date.' 23:59:59'); 
        
        if(loggedInUser()->user_type=="3"){
            $event_sessions->where('class_students_request.status','1')->where('class_students_request.is_delete','0');
            $event_sessions->where('class_students_request.student_id',loggedInUser()->id);
        }
        elseif(loggedInUser()->user_type=="2"){
          $userId = loggedInUser()->id;
          $event_sessions->where(function ($query) use ($userId){
              $query->where('event_sessions.teacher_id',$userId)
                    ->orWhere('event_sessions.assistant_teacher_id',$userId);
          });
        }
        elseif(loggedInUser()->user_type=="4"){
            // $event_sessions->where('event_sessions.teacher_id',loggedInUser()->id);
        }

        $event_sessions->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type');
         

        $sessions = $event_sessions->get(); 
        $class_frequency = getFrequency();

            

        $calendar_data = [];

        if($sessions->count()){
            foreach ($sessions as $key => $session) {
                $duration = $session->duration.' Minutes';
                $class_name = $session->schedule_class->class->course_name;
                $class_type = (isset($class_types[$session->schedule_class->class_type]))?$class_types[$session->schedule_class->class_type]:'';
                
                // $time = date("h:i a", strtotime($session->start_time)) .' - '.date("h:i a", strtotime('+'.$session->duration.' minute', strtotime($session->end_time))); ;  
                $time = date("h:i A", strtotime($session->start_time));  
                $schedule_type = $session->schedule_class->eventSchedule()->first();

                $frequency = '-';
                if(!empty($schedule_type)){
                    $frequency = $class_frequency[$schedule_type->schedule_type];
                }
                $student ='';
                if(loggedInUser()->user_type=="2" && $session->schedule_class->class_type=='1'){
                    $student = (!empty($session->schedule_class->studentClassRequestMany->where('is_delete','0')->count()))? 'Student: '.$session->schedule_class->studentClassRequestMany->where('is_delete','0')->first()->student->name:'';
                }
                

                 

                $calendar_data[] = ['title'=> $class_name.' - '.$duration.' - '.$class_type,
                                    'start'=> date('D, d M Y', strtotime($session->start_date)).' '.date('h:i A', strtotime($session->start_time)),
                                    'className'=> ($session->status!='canceled')?'fc-success':'fc-danger',
                                    'duration'=> $duration,
                                    'time'=> $time,
                                    'date'=>date('D, d M Y', strtotime($session->start_date)),
                                    'batch'=> $session->schedule_class->batch_name,
                                    'class_type'=> $session->schedule_class->class_type,
                                    'course'=> $session->schedule_class->course->course_name,
                                    'subcourse'=> $session->schedule_class->class->course_name,
                                    'frequency'=> $frequency,
                                    'class_mode'=> $class_type,
                                    'student'=> $student,
                                    ];
            }
        }

        return response()->json($calendar_data, 200);


    }
}
