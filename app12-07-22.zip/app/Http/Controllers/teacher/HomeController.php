<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use App\Course;
use App\User;
use App\EventSession;
use Auth;
class HomeController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $all_users = User::count();
        $teachers = User::where('user_type','2')->count();
        $students = User::where('user_type','3')->count();
        $activate_user = User::where('account_verified','1')->count();

        $id = Auth::user()->id;

        // upcoming class
        // $classes_data = DB::table('schedule_class')->where('teacher_id',$id)->where('schedule_class.status', 0)
        // ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
        // ->get();
        
        $upcoming_classes = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])
            ->where('event_sessions.is_delete','0')
            ->where(function ($query) use ($id){
                $query->where('event_sessions.teacher_id',$id)
                      ->orWhere('event_sessions.assistant_teacher_id',$id);
            })
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '>=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type')//,'class_students_request.creator_id'
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->limit(5)->get();   
        

        // past class
        $pasts_classs = DB::table('schedule_class')->where(function ($query) use ($id){
                $query->where('schedule_class.teacher_id',$id)
                      ->orWhere('schedule_class.assistant_teacher_id',$id);
            })->where('schedule_class.status', 1)
        ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
        ->get();

        // dd($classes_data);

        return view('panel.teacher.home',compact('all_users','teachers','students','activate_user','upcoming_classes','pasts_classs'));
    }
    public function course_offered()
    {
        return view('front.course_offered');
    }

    public function user_referral()
    {
        
        return view('panel.teacher.user_referral');
    }
  
}
