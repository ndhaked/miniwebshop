<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\Classes;
use App\Course;
use App\ScheduleClass;
use App\User;
use Auth;
use Carbon\Carbon;

use App\EventSession;
use App\EventSchedule;

class ClassController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/

    public function upcoming_class()
    { 
        $class_list = Classes::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();


        // Upcoming Class Details Teacher
        $userId = Auth::id();
        // $upcoming_class_list =  DB::table('schedule_class')->where('schedule_class.is_delete',0)->where('teacher_id', $userId)
        //                     ->where('schedule_class.status','=',0)
        //                     ->leftJoin('class_students_request', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')
        //                     ->leftJoin('users', 'schedule_class.teacher_id', '=', 'users.id')
        //                     ->leftJoin('course', 'schedule_class.course_id', '=', 'course.id')
        //                     ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
        //                     ->where('class_students_request.is_delete',0)
        //                     ->get();
        // foreach ($upcoming_class_list as $key => $s_name) 
        // {
        //     $user = User::where('id', $s_name->student_id)->first();
        //     $s_name->student_name = $user->name;
        // }            
        // 
        $upcoming_class_list = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->where(function ($query) use ($userId){
                $query->where('event_sessions.teacher_id',$userId)
                      ->orWhere('event_sessions.assistant_teacher_id',$userId);
            })
            ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '>=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type', 
            DB::raw("if(CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)<=NOW(), 'live', event_sessions.status) as status"),
            DB::raw("if(event_sessions.teacher_id = ".$userId.", 'teacher', 'assistant_teacher') as role"))
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->get();  

        $class_type=classType();           
        return view('panel.teacher.class.upcoming_class',compact('class_list','class_type','teacher_list','course_list','upcoming_class_list'));
    }

    public function past_class()
    {
        $userId = Auth::user()->id;

        $past_class_list = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.status','!=','canceled')
            // ->whereIn('event_sessions.status',['completed'])
            ->where('event_sessions.is_delete','0')
            ->where('event_sessions.teacher_id',$userId)
            ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '<=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type')//,'class_students_request.creator_id'
            ->orderBy('event_sessions.start_date','desc')
            ->orderBy('event_sessions.start_time','desc')
            ->get();  
        $class_type=classType();

        // $past_class_list =  DB::table('schedule_class')->where('schedule_class.is_delete',0)->where('teacher_id', $id)
        //                     ->where('schedule_class.status','=',1)
        //                     ->leftJoin('class_students_request', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')
        //                     ->leftJoin('users', 'schedule_class.teacher_id', '=', 'users.id')
        //                     ->leftJoin('course', 'schedule_class.course_id', '=', 'course.id')
        //                     ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
        //                     ->select('schedule_class.*', 'class_students_request.student_id','users.*','course.*','class_details.*')
        //                     ->get();

        // foreach ($past_class_list as $key => $s_name) 
        // {
        //     $user = User::where('id', $s_name->student_id)->first();
        //     // dd($user);
        //     if ($user != null) 
        //     {
        //         $s_name->student_name = $user->name;
        //     }
        //     else
        //     {
        //         $s_name->student_name = 'Not Available';

        //     }
        // }  
        // dd($past_class_list);                    
        return view('panel.teacher.class.past_class',compact('past_class_list','class_type'));
    }
    
    public function reschedule_upcoming_class()
    {
        $class_list = Classes::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
        return view('panel.teacher.class.reschedule_upcoming_class',compact('class_list','teacher_list','course_list'));
    }


   
}
