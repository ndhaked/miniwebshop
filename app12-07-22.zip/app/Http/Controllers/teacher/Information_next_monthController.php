<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\Classes;
use App\Course;
use App\User;
use App\AvailableMonth;
use Validator;
use Auth;
use Carbon\Carbon;

class Information_next_monthController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function information_next_month()
    {
        $teacher_id = auth::user()->id;
        $currentDate = date('Y-m-d');

        $availables = AvailableMonth::where('teacher_id', $teacher_id)->where('is_deleted' ,0)->whereDate('end_date', '>=', $currentDate)->get();
        foreach ($availables as $key => $available) 
        {
        
            $time = new Carbon($available->start_time);
            $shift_end_time = new Carbon($available->end_time);

            $total_hours = $time->diffForHumans($shift_end_time);
            $available->total_hours = $total_hours;

        }
        // dd($availables->toArray());
        return view('panel.teacher.information_next_month.information_next_month',compact('availables'));
    }


    public function saveAvailable()
    {
        // dd(request()->all());
        $validator = Validator::make(request()->all(), [
            'start_date' => 'required',
            'end_date' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $teacher_id = auth::user()->id;

        $data = array([

                'teacher_id' => $teacher_id,
                'start_date' => request('start_date'),
                'start_time' => request('start_time'),
                'end_date' => request('end_date'),
                'end_time' => request('end_time'),
            ]);

         AvailableMonth::insert($data);

        return response()->json(['status' => 1]);
    }

    public function deleteAvailable($id)
    {
        $delete = AvailableMonth::findOrFail($id);

        $delete->delete();

        return redirect()->route('information_next_month');  

    }

}
