<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use Auth;
use App\User;
use App\Course;
use App\TeacherDetails;

class ProfileController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
   
    public function myProfile()
    {
        $id = Auth::id();
        $teacher_details = User::join('teacher_details','teacher_details.teacher_id','users.id')->where('users.id',$id)->first();
        $select_subject = Course::where('is_delete',0)->get();
        //dd($teacher_details);
        return view('panel.teacher.profile.index',compact('teacher_details','select_subject'));
    }
    public function myProfile_get(Request $request)
    {
        //dd($request->id);
        $teacher_details = User::join('teacher_details','teacher_details.teacher_id','users.id')->where('teacher_details.id',$request->id)->get();
        $teacher_nationality = explode(',',$teacher_details[0]->nationality);
        $teacher_nationality_arr_make = array();
        foreach($teacher_nationality as $key => $value)
        {
           $teacher_nat =  $value;
           array_push($teacher_nationality_arr_make,$teacher_nat);
        }

        $teacher_details['teacher_dob'] =  date("d/m/Y",strtotime($teacher_details[0]->teacher_dob));
        $teacher_details['nationality'] = $teacher_nationality_arr_make;
        $teacher_details['residence_country'] = $teacher_details[0]->residence_country;
        $teacher_details['highest_qualification'] = $teacher_details[0]->highest_qualification;
        $teacher_details['teacher_certification_y_n'] = $teacher_details[0]->teacher_certification_y_n;
        $teacher_details['teacher_certification'] = $teacher_details[0]->teacher_certification;
        $teacher_details['teacher_certification_issued'] = $teacher_details[0]->teacher_certification_issued;
        $teacher_details['teacher_experience_year'] = $teacher_details[0]->teacher_experience_year;
        $teacher_details['teacher_experience_total'] = $teacher_details[0]->teacher_experience_total;
        $teacher_details['school_address'] = $teacher_details[0]->school_address;
        $teacher_details['image'] = $teacher_details[0]->image;

        $grade_interested = explode(',',$teacher_details[0]->grade_interested);
        $grade_interested_arr_make = array();
        foreach($grade_interested as $key => $value)
        {
           $grade =  $value;
           array_push($grade_interested_arr_make,$grade);
        }
        $teacher_details['grade_interested'] = $grade_interested_arr_make;
        
        $subject_teaching_experience = explode(',',$teacher_details[0]->subject_teaching_experience);
        $subject_teaching_experience_arr_make = array();
        foreach($subject_teaching_experience as $key => $value)
        {
           $subject_teaching =  $value;
           array_push($subject_teaching_experience_arr_make,$subject_teaching);
        }
        $teacher_details['subject_teaching_experience'] = $subject_teaching_experience;
        $teacher_details['residence_address'] = $teacher_details[0]->residence_address;
        $teacher_details['bank_name'] = $teacher_details[0]->bank_name;
        $teacher_details['branch_name'] = $teacher_details[0]->branch_name;
        $teacher_details['branch_address'] = $teacher_details[0]->branch_address;
        $teacher_details['branch_country'] = $teacher_details[0]->branch_country;
        $teacher_details['swift_code'] = $teacher_details[0]->swift_code;
        $teacher_details['account_number'] = $teacher_details[0]->account_number;
        $teacher_details['account_name'] = $teacher_details[0]->account_name;
        $teacher_details['account_currency'] = $teacher_details[0]->account_currency;
        $teacher_details['account_type'] = $teacher_details[0]->account_type;
        return response()->json(['status' => 1,'success' => $teacher_details]);
    }
    public function update_profile(Request $request)
    {
       //dd($request->all());

         $dob_get = explode("/",request('teacher_dob'));
         $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];

         if(!empty($request->profile_image))
         {
            $profile_pic = ImageUpload::upload('teachers/',$request->profile_image);
            $image = $profile_pic;
         }
         else
         {
            $image = $request->profile_old_image;
         }

         $nationality = !empty($request->nationality) ? implode(',',$request->nationality) : "";
         $subject_experience = !empty($request->subject_experience) ? implode(',',$request->subject_experience) : "";
         $grade_teaching_experience = !empty($request->grade_teaching_experience) ? implode(',',$request->grade_teaching_experience) : "";



        $teacher_data = array('nationality'=>$nationality,'teacher_dob'=>$newDate,'residence_country'=>$request->residence_country,'highest_qualification'=>$request->highest_qualification,'teacher_certification_y_n'=>$request->teacher_certification_y_n,'school_address'=>$request->school_address,'teacher_certification'=>$request->teacher_certification,'teacher_certification_issued'=>$request->teacher_certification_issued,'teacher_experience_year'=>$request->teacher_experience_year,'teacher_experience_total'=>$request->total_experience,'school_address'=>$request->school_address,'grade_interested'=>$grade_teaching_experience,'subject_teaching_experience'=>$subject_experience ,'residence_address'=>$request->residence_address,'bank_name'=>$request->bank_name,'branch_name'=>$request->branch_name,'branch_address'=>$request->branch_address,'branch_country'=>$request->branch_country,'swift_code'=>$request->swift_code,'account_name'=>$request->account_name,'account_number'=>$request->account_number,'account_currency'=>$request->account_currency,'account_type'=>$request->account_type);
        TeacherDetails::where('id',$request->id)->update($teacher_data);

        $image_data = array('image'=>$image);
        User::where('id',$request->teacher_id)->update($image_data);

        $teacher_data['id'] = $request->id;
        return response()->json(['status' => 1,'success' => $teacher_data]);
    }

}
