<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use Validator;
use File;

use App\ImageUpload;
use App\Classes;
use App\Course;
use App\User;
use App\Assignment;
use App\AssignmentSubmit;
use Auth;



class AssignmentController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function sub_checked_assignment()
    {
        $teacher_id = auth::user()->id;

        $submit_assignments = DB::table('assignment_submited_student')
            ->where('assignment_submited_student.teacher_id', $teacher_id)
            ->where('assignment_submited_student.status','=', 2)
            ->join('users', 'assignment_submited_student.teacher_id', '=', 'users.id')
            ->join('course', 'assignment_submited_student.course_id', '=', 'course.id')
            ->join('class_details', 'assignment_submited_student.class_id', '=', 'class_details.id')
            ->join('assignment', 'assignment_submited_student.ass_id', '=', 'assignment.id')
            ->select('assignment_submited_student.*','users.name', 'course.course_name', 'class_details.course_name as class_name', 'assignment.document_file as teacher_document')
            ->get();

       
        return view('panel.teacher.assignment.submited_n_checked_assignment',compact('submit_assignments'));
    }

     public function due_for_check_assignment()
    {
       
        $teacher_id = auth::user()->id;

        $submit_assignments = DB::table('assignment_submited_student')
            ->where('assignment_submited_student.teacher_id', $teacher_id)
            ->where('assignment_submited_student.status','=', 1)
            ->join('users', 'assignment_submited_student.teacher_id', '=', 'users.id')
            ->join('course', 'assignment_submited_student.course_id', '=', 'course.id')
            ->join('class_details', 'assignment_submited_student.class_id', '=', 'class_details.id')
            ->join('assignment', 'assignment_submited_student.ass_id', '=', 'assignment.id')
            ->select('assignment_submited_student.*','users.name', 'course.course_name', 'class_details.course_name as class_name', 'assignment.document_file as teacher_document')
            ->get();

        return view('panel.teacher.assignment.due_for_check_assignment',compact('submit_assignments'));
    }

    public function due_from_student_assignment()
    {
        $class_list = Classes::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();

        $teacher_id = auth::user()->id;

        // Get Upload Assignment 
        $assignments = DB::table('assignment')->where('teacher_id', $teacher_id)
            ->where('assignment.status','=',0)
            ->join('users', 'assignment.teacher_id', '=', 'users.id')
            ->join('course', 'assignment.course_id', '=', 'course.id')
            ->join('class_details', 'assignment.class_id', '=', 'class_details.id')
            ->select('assignment.*','users.name', 'course.course_name', 'class_details.course_name as class_name')
            ->get();

        // dd($assignments->toArray());    
       
        return view('panel.teacher.assignment.due_from_student_assignment',compact('class_list','course_list','assignments'));
    }

    // Upload Assignment 
    public function uploadAssignment()
    {

        $validator = Validator::make(request()->all(), [
            'course_id' => 'required',
            'class_id' => 'required',
            'document' => 'required|mimes:doc,docx',
            'document_name' => 'required',
        ],
        [
          'class_id.required' => 'The select class field is required.',
          'course_id.required' => 'The select course field is required.'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $teacher_id = auth::user()->id;

        $date = date('Y-m-d h:i:s');
        $class_id = request()->class_id;
        $course_id = request()->course_id;
        $document_name = request()->document_name;

        if(!empty(request()->document))
        {
            $document_data = ImageUpload::upload('assignment_document/',request()->file('document'));
            $document = $document_data;
        }
        else
        {
            $document = 'course_default_img.png';
        }

        $data = array([

                'class_id' => $class_id,
                'teacher_id' => $teacher_id,
                'course_id' => $course_id,
                'document_name' => $document_name,
                'document_file' => $document,
                'created_at' => $date
            ]);

        Assignment::insert($data);

        return response()->json(['status' => 1,'data' => $data]);

    }


    public function assignmentDelete($id)
    {

        $file = Assignment::where('id', $id)->first();

        $file_path = base_path().'/public/assignment_document/'.$file->document_file;

        if(File::exists($file_path)) File::delete($file_path);

        $delete = Assignment::findOrFail($id);

        $delete->delete();

        return redirect()->route('due_from_student_assignment');


    }

    
    public function assignmentApprove($id)
    {

        $update = AssignmentSubmit::where('id', $id)->update(['status' => 2]);


        return redirect()->route('due_for_check_assignment');

    }    


}
