<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use Auth;
use Validator;
use App\ImageUpload;
use App\Classes;
use App\Course;
use App\User;
use App\Library;
use App\ScheduleClass;
use App\ClassDetails;
use Illuminate\Support\Str;

class LibraryController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function universal_library()
    {

      $userId = Auth::user()->id;  
      $universal_lib_list = Library::join('schedule_class', 'schedule_class.class_name', '=', 'library.class_id') 
            ->join('event_sessions', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->where('schedule_class.is_delete','0')->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])
            ->where('event_sessions.is_delete','0')
            ->where(function ($query) use ($userId){
                $query->where('event_sessions.teacher_id',$userId)
                      ->orWhere('event_sessions.assistant_teacher_id',$userId);
            })
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '>=', date('Y-m-d H:i:s'))
            ->select('library.*')->get();  
      $class_list = ScheduleClass::where('is_delete','0')->get();
      $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
 
        
       return view('panel.teacher.library.universal',compact('universal_lib_list','class_list','course_list'));
    }
    public function teacher_universal_library_view(Request $request)
    {
        $universal_library = Library::where('id',$request->document_id)->get();

        foreach ($universal_library as $key => $value) 

        {

            $universal_library['id'] = $request->document_id;

            $universal_library['document_name'] = $value->document_name;

            $universal_library['course_id'] = $value->course_id;

            $universal_library['class_id'] = $value->class_id;

            $universal_library['document'] = $value->document_file;

        }

        return response()->json(['status' => 1,'success' => $universal_library]);

    }

    public function personal_library()
    {
       $id = Auth::user()->id;
       $class_list = ScheduleClass::where('is_delete','0')->get();
       $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
       $personal_library_list = Library::where('is_delete','0')->where('teacher_id',$id)->get();
       foreach ($personal_library_list as $key => $value)
       {
           $course = Course::where('id', $value->course_id)->where('is_delete','0')->get();
           foreach ($course as $key => $name)
           {
               $value['course_name'] = $name->course_name;
           }
           $course_details = ClassDetails::where('id', $value->class_id)->where('is_delete','0')->get();
           foreach ($course_details as $key_class => $name_class)
           {
               $value['class_name'] = $name_class->course_name;
           }
       }

       return view('panel.teacher.library.personal_library',compact('class_list','personal_library_list','course_list'));

    }
    public function personal_library_add(Request $request)
    {

        $validator = Validator::make(request()->all(), [
            'course_id' => 'required',
            'class_id' => 'required',
            'document' => 'required',
            'document_name' => 'required',

         ],
        [
          'class_id.required' => 'The select class field is required.',
          'course_id.required' => 'The select course field is required.',
          'document.required' => 'This field is required.',
          'document_name.required' => 'This field is required.'
        ]);
        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }


        $date = date('Y-m-d h:i:s');
        $class_id = $request->class_id;
        $course_id = $request->course_id;
        $document_name = $request->document_name;
        if(!empty($request->document))
        {
            $document_data = ImageUpload::upload('library_document/',$request->file('document'));
            $document = $document_data;
        }
        else
        {
            $document = 'course_default_img.png';
        }

        // $data = array(['class_id'=>$class_id,'teacher_id'=>$request->teacher_id,'course_id'=>$course_id,'document_name'=>$document_name,'document_file'=>$document,'created_at'=>$date,'type'=>'personal']);
        // Library::insert($data);

        $course_name = Course::find($course_id)->course_name;
        $class_name = ClassDetails::find($class_id)->course_name;
        $folder_path = Str::slug($course_name, '-').'/'.Str::slug($class_name, '-');

        $presenter = ['id'=>Auth::user()->id,'name'=>Auth::user()->name];
        $accesslevel = '1';
        $upload_file = public_path('library_document/').$document;
        $access_key= config('constants.WIZIQ_SECRET_KEY');  
        $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
        $webServiceUrl= config('constants.WIZIQ_RESTAPI_URL');
        include(app_path().'/edu_api/UploadContent.php');
        $obj =  uploadContent($secretAcessKey,$access_key,$webServiceUrl,$document_name,$presenter,$upload_file,$folder_path,$accesslevel); 
        if(!empty($obj) && $obj['status'] == true){
            $library = new Library;
            $library->class_id=$class_id;
            $library->course_id=$course_id;
            $library->teacher_id=$request->teacher_id;
            $library->document_name=$document_name;
            $library->document_file=$document;
            $library->type='personal';
            $library->content_id=$obj['response']['content_id'];
            $library->save();

            return response()->json(['status' => 1]);
        }
        else{
            $error[] = ['document'=>'Failed to upload document. Please Try Again'];
            return response()->json(['status' => 401,'error1' => $error]);
        }
       
        
    }
    public function personal_library_view(Request $request)
    {
        $universal_library = Library::where('id',$request->document_id)->get();

        foreach ($universal_library as $key => $value) 

        {

            $universal_library['id'] = $request->document_id;

            $universal_library['document_name'] = $value->document_name;

            $universal_library['course_id'] = $value->course_id;

            $universal_library['class_id'] = $value->class_id;

            $universal_library['document'] = $value->document_file;

        }

        return response()->json(['status' => 1,'success' => $universal_library]);

    }
    public function personal_library_edit(Request $request)
    {
        $universal_library = Library::where('id',$request->document_id)->get();

        foreach ($universal_library as $key => $value) 

        {

            $universal_library['id'] = $request->document_id;

            $universal_library['document_name'] = $value->document_name;

            $universal_library['course_id'] = $value->course_id;

            $universal_library['class_id'] = $value->class_id;

            $universal_library['document'] = $value->document_file;

        }

        return response()->json(['status' => 1,'success' => $universal_library]);

    }

    public function personal_library_update(Request $request)
    {
        $validator = Validator::make(request()->all(), [
            'course_id' => 'required',
            'class_id' => 'required',
            'document' => 'required',
            'document_name' => 'required',
         ],
        [
          'class_id.required' => 'The select class field is required.',
          'course_id.required' => 'The select course field is required.',
          'document.required' => 'This field is required.',
          'document_name.required' => 'This field is required.'
        ]);
        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }


        $date = date('Y-m-d h:i:s');
        $personal_doc_id = $request->personal_lib_doc_id;
        $class_id = $request->class_id;
        $course_id = $request->course_id;
        $document_name = $request->document_name;
        if(!empty($request->document))
        {
            $document_data = ImageUpload::upload('library_document/',$request->file('document'));
            $document = $document_data;
        }
        else
        {
            $document = $request->old_document_file;
        }

        $library = Library::find($personal_doc_id);
        $course_name = Course::find($course_id)->course_name;
        $class_name = ClassDetails::find($class_id)->course_name;
        $folder_path = Str::slug($course_name, '-').'/'.Str::slug($class_name, '-');
        $presenter = ['id'=>Auth::user()->id,'name'=>Auth::user()->name];
        $accesslevel = '1';

        $upload_file = public_path('library_document/').$document;
        $access_key= config('constants.WIZIQ_SECRET_KEY');  
        $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
        $webServiceUrl= config('constants.WIZIQ_RESTAPI_URL');
        include(app_path().'/edu_api/UploadContent.php');

        if(!empty($library->content_id)){
            $deleteobj =  DeleteUploadContent($secretAcessKey,$access_key,$webServiceUrl,$library->content_id);
        }

        $obj =  uploadContent($secretAcessKey,$access_key,$webServiceUrl,$document_name,$presenter,$upload_file,$folder_path,$accesslevel); 
        
        if(!empty($obj) && $obj['status'] == true){
             
            $library->class_id=$class_id;
            $library->course_id=$course_id;
            $library->document_name=$document_name;
            $library->document_file=$document;
            $library->content_id=$obj['response']['content_id'];
            $library->save();

            return response()->json(['status' => 1]);
        }
        else{
            $error[] = ['document'=>'Failed to upload document. Please Try Again'];
            return response()->json(['status' => 401,'error1' => $error]);
        }

        // $data = array('class_id'=>$class_id,'course_id'=>$course_id,'document_name'=>$document_name,'document_file'=>$document);
        // Library::where('id',$personal_doc_id)->update($data);
        // return response()->json(['status' => 1,'data' => $data]);
    }
     public function personal_library_delete($id)
    {
        $library = Library::find($id);
        
        if(!empty($library->content_id)){
            $access_key= config('constants.WIZIQ_SECRET_KEY');  
            $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
            $webServiceUrl= config('constants.WIZIQ_RESTAPI_URL');
            include(app_path().'/edu_api/UploadContent.php');
            $obj =  DeleteUploadContent($secretAcessKey,$access_key,$webServiceUrl,$library->content_id);
        }

        $library->is_delete='1';
        $library->save();

        // $teacher_delete = Library::where('id',$id)->update(['is_delete'=>'1']);
        return redirect()->route('personal_library');
    }
}
