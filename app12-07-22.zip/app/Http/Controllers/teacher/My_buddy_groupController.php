<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\Classes;
use App\Course;
use App\User;
use App\TeacherBuddyGroup;
use Auth;

class My_buddy_groupController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function my_buddy_group()
    {
        $teachers = User::where('user_type','2')->where('is_delete','0')->where('account_verified','1')->get();
        $teacher_list = array();

        $myId = auth::user()->id;

        // $teacher_buddy_list = TeacherBuddyGroup::where('is_delete','0')->get();

        $teacher_buddy_list = \DB::table("teacher_buddy_group")->where('is_delete','0')
            ->select("teacher_buddy_group.*")
            ->whereRaw("find_in_set('".$myId."',teacher_buddy_group.teacher_group_list)")
            ->get();

        foreach ($teacher_buddy_list as $key => $value) 
        {

            $teacher_ids = explode(',',$value->teacher_group_list);
            $all_t_name = array();
            foreach ($teacher_ids as $key_tl => $value_tl) 
            {
                $user_name = User::where('id',$value_tl)->first(['name']);
                array_push($all_t_name,$user_name->name);
            }
            array_push($teacher_list,$all_t_name);
        }

        return view('panel.teacher.my_buddy_group.my_buddy_group',compact('teachers','teacher_list','teacher_buddy_list'));
    }


    // public function AddTeacherBuddyGroup(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'group_name' => 'required|string|min:5|max:255',
    //         'teacher_id' => 'required'
    //     ]);
    //     if ($validator->fails()) 
    //     {  
    //         $error=json_decode($validator->errors());          
    //         return response()->json(['status' => 401,'error1' => $error]);
    //         exit();
    //     }

       

    //     $date = date("Y-m-d h:i:s");
    //     $data = array('group_name'=>$request->group_name,'teacher_group_list'=>implode(',',$request->teacher_id),'created_at'=>$date);
    //     TeacherBuddyGroup::insert($data);

    //     return response()->json(['status' => 1,'data' => $data]);

    // }


    // public function UpdateTeacherBuddyGroup(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'group_name' => 'required|string|min:5|max:255',
    //         'teacher_id' => 'required'
    //     ]);

    //     if ($validator->fails()) 
    //     {  
    //         $error=json_decode($validator->errors());          
    //         return response()->json(['status' => 401,'error1' => $error]);
    //         exit();
    //     }

    //     $date = date("Y-m-d h:i:s");
    //     $data = array('group_name'=>$request->group_name,'teacher_group_list'=>implode(',',$request->teacher_id),'created_at'=>$date);
    //     TeacherBuddyGroup::where('id',$request->id)->update($data);

    //     return response()->json(['status' => 1,'data' => $data]);

    // }
    public function DeleteTeachermyGroup($id)
    {   
        $teacherbuddy_group_delete = TeacherBuddyGroup::where('id',$id)->update(['is_delete'=>'1']);
        return redirect()->route('my_buddy_group');
    }


}
