<?php
namespace App\Http\Controllers\teacher;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use App\Classes;
use App\Course;
use App\User;
class MyWalletController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $class_list = Classes::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
        return view('panel.teacher.wallet.wallet',compact('class_list','teacher_list','course_list'));
    }
}
