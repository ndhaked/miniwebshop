<?php
namespace App\Http\Controllers\student;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use App\ImageUpload;
use App\Course;
use App\ClassDetails;
use Validator;
use App\User;
use App\StudentDetails;
use App\ClassStudentRequest;
use App\EventSession;
use App\ScheduleClass;
use Session;

class HomeController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $id = Auth::user()->id;
        $student_image = StudentDetails::where('student_id',$id)->get();

        $class_details = ScheduleClass::join('class_students_request', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')->where('class_students_request.student_id',$id)->where('class_students_request.status',1)->where('class_students_request.is_delete',0)->where('schedule_class.is_delete',0)->select(DB::raw('DISTINCT(schedule_class.class_name)'))->get();
        
        foreach ($class_details as $key => $class) {
           $class_name = ClassDetails::find($class->class_name)->course_name;
           $class->course_name= $class_name;
        }

         

        // $classes_data = DB::table('class_students_request')->where('class_students_request.student_id',$id)->where('class_students_request.status',1)
        // ->leftJoin('schedule_class', 'class_students_request.schedule_class_id', '=', 'schedule_class.id')
        // ->leftJoin('class_details', 'class_students_request.class_details_id', '=', 'class_details.id')
        // ->get();
         $upcoming_classes = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])
            ->where('event_sessions.is_delete','0')
            ->where('class_students_request.student_id',$id)
            ->where('class_students_request.is_delete','0')
            ->where('class_students_request.status','1')
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '>=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type','class_students_request.creator_id')
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->limit(5)->get();
        // dd($classes_data);

        return view('panel.student.home',compact('student_image','class_details','upcoming_classes'));
    }
    public function course_offered()
    {
        return view('front.course_offered');
    }
    public function parent_login(Request $request)
    {

         $validator = Validator::make($request->all(), [
            'id' => 'required'
            ]);
        $get_parent = User::where('id',$request->id)->where('is_delete',0)->where('account_verified',1)->first();

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }
  
        $data = array ('email' => $get_parent->email,'password' => $get_parent->plain_password,'user_type'=>4,'account_verified' => 1,'is_delete' => 0);
            Session::flush();
        if (Auth::attempt ($data)) 
        { 
            return response()->json(['status' => 1,'data' => $data]);
        } else {
            return response()->json(['status' => 4011,'error1' => "Invalid data.Please try again."]);
             exit();
        }
    }

    public function resendVerificationLink(Request $request){
        $token = str_random(50);
        $user = User::find($request->user_id);
        $user->verification_token = $token;
        $user->save();


        if($user->parent_id){
            $parent = $user->parent;
            $reciever_email = $parent->email;
            $reciever_name = $parent->name; 
        }
        else{

            $reciever_email = $user->email;
            $reciever_name = $user->name; 
        }


        $data['confirmation_link'] = url('verification/'.$token);

        $data['from_email'] = config('constants.FROM_EMAIL');
        $data['from_name']  = config('constants.FROM_NAME');
        $data['attachment']  = '';
        $data['reciever_email']  = $reciever_email;
        $data['reciever_name']  = $reciever_name;
        $data['subject']  = 'JoinIvy - Account Verification';
        sendMail('email.email_verification',$data);

         return response()->json(['status' => 1,'success' => true]);

    }
    
    public function user_referral()
    {
        
        return view('panel.student.user_referral');
    }
}
