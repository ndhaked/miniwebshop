<?php
namespace App\Http\Controllers\student;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use Auth;
use Validator;
use App\ImageUpload;
use App\Classes;
use App\ClassDetails;
use App\Course;
use App\User;
use App\ClassStudentRequest;
use App\ScheduleClass;
use App\AddAttendeeStudentClass;

use App\EventSession;
use App\EventSchedule;

use App\Order;
use App\OrderItem;

class ClassController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/

    public function upcoming_class()
    {
        $id = Auth::user()->id;  

        $get_all_data = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->where('class_students_request.student_id',$id)
            ->where('class_students_request.is_delete','0')
            ->where('class_students_request.status','1')
            ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '>=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type','class_students_request.creator_id', 
            DB::raw("if(CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)<=NOW(), 'live', event_sessions.status) as status"))
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->get();   

        // $get_all_data =   DB::table('class_students_request')->where('class_students_request.student_id',$id)->where('class_students_request.is_delete',0)->where('class_students_request.status',1)
        //   ->leftJoin('class_details', 'class_students_request.class_details_id', '=', 'class_details.id')
        //   ->leftJoin('schedule_class', 'class_students_request.schedule_class_id', '=', 'schedule_class.id')->where('schedule_class.status',0)
        //   ->leftJoin('course', 'schedule_class.course_id', '=', 'course.id')
        //   ->select('class_students_request.*','class_details.course_name as class_name1','schedule_class.*')
        // ->get();
                         
        // $get_all_data = ClassStudentRequest::where('student_id',$id)->where('is_delete',0)->get();
        // // dd($get_all_data);
        // foreach ($get_all_data as $key => $value) 
        // {
        //    $class_details = ClassDetails::where('id',$value->class_details_id)->first(['course_name']);
        //    $class_name = $class_details->course_name;

        //    if($value->class_types=='1')
        //    {
        //      $class_type = "One to One Class";
        //    }
        //    elseif($value->class_types=='2')
        //    {
        //      $class_type = "Buddy Class";
        //    }
        //    else
        //    {
        //      $class_type = "Batch Class";
        //    }

        //    if($value->status=='0')
        //    {
        //      $status = 'Pending';   
        //    }
        //    else
        //    {
        //      $status = 'Set';   
        //    }

        //   if($value->class_types=='1')
        //   {  
        //     // dd($value->schedule_class_id);
        //     if(isset($value->schedule_class_id))
        //     {
        //       $student_schedule = ScheduleClass::where('is_delete','0')->where('status','0')->where('id',$value->schedule_class_id)->first();

        //       if ($student_schedule != null) 
        //       {
        //         $value->student_schedule_class_url = $student_schedule->student_schedule_class_url;
        //         $value->schedule_date=$student_schedule->date;
        //       }
        //       //else
        //       // {
        //       //   $get_all_data = '';
        //       //   // $value->schedule_date =  null;
        //       // }
              
        //     }
        //     else
        //     {
        //       $value->student_schedule_class_url = '';
        //       $value->schedule_date='Not Schedule Class';
        //     } 


        //   }  
        //   elseif($value->class_types=='2')
        //   {
        //      if(isset($value->schedule_class_id))
        //     {
        //       $student_schedule = AddAttendeeStudentClass::where('is_delete','0')->where('student_id',$id)->where('schedule_class_id',$value->schedule_class_id)->first(['student_schedule_class_url']);

        //       if ($student_schedule != null) 
        //       {
        //         $value->student_schedule_class_url = $student_schedule->student_schedule_class_url;
        //       }
        //       // else
        //       // {
        //       //   $get_all_data = '';
        //       //   // $value->student_schedule_class_url =  null;
        //       // }

        //       $student_schedule1 = ScheduleClass::where('is_delete','0')->where('status','0')->where('id',$value->schedule_class_id)->first(['student_schedule_class_url','date']);

        //      if ($student_schedule1 != null) 
        //       {
        //         $value->schedule_date = $student_schedule1->date;
        //       }
        //       // else
        //       // {
        //       //   $get_all_data = '';
        //       //   // $value->schedule_date =  null;
        //       // }
 

        //     }
        //     else
        //     {
        //       $value->student_schedule_class_url = '';
        //       $value->schedule_date='Not Schedule Class';

        //     } 

        //   }
        //   elseif($value->class_types=='3')
        //   {
        //     if(isset($value->schedule_class_id))
        //     {
        //       $student_schedule = AddAttendeeStudentClass::where('is_delete','0')->where('student_id',$id)->where('schedule_class_id',$value->schedule_class_id)->first(['student_schedule_class_url']);

        //       if($student_schedule != null) 
        //       {
        //         $value->student_schedule_class_url = $student_schedule->student_schedule_class_url;
        //       }
        //       else
        //       {
        //         $get_all_data = '';
        //         // $value->student_schedule_class_url =  null;
        //       }

              

        //       $student_schedule1 = ScheduleClass::where('is_delete','0')->where('status','0')->where('id',$value->schedule_class_id)->first(['student_schedule_class_url','date']);
        //       if ($student_schedule1 != null) 
        //       {
        //         $value->schedule_date=$student_schedule1->date;
        //       }
        //       else
        //       {
        //         $get_all_data = '';
        //         // $value->schedule_date =  null;
        //       }

        //     }
        //     else
        //     {
        //       $value->student_schedule_class_url = '';
        //       $value->schedule_date='Not Schedule Class';

        //     } 

        //   }

        //   // Get Teacher Name
        //   if ($value->schedule_class_id != null) 
        //   {
        //     $teacher = ScheduleClass::where('id',$value->schedule_class_id)->where('is_delete',0)->first();
        //     $user = User::where('id',$teacher->teacher_id)->first();
        //     $value->teacher_name = $user->name;
        //   }

        //   $value->class_name_new = $class_name;
        //   $value->class_type_new = $class_type;
        //   $value->duration = $value->duration.' Minutes';
        //   $value->session_start_date = $value->session_start_date;
        //   $value->session_end_date = $value->session_end_date;
        //   $value->session_start_time = $value->session_start_time;
        //   $value->session_end_time = $value->session_end_time;
        //   $value->session_status = $status;
           
        // }
        // dd($get_all_data->toArray());
        
        $session_status = sessionStatus(); 
        $class_type=classType(); 
        return view('panel.student.class.upcoming_class',compact('get_all_data','session_status','class_type'));
    }
    public function past_class()
    {
        $class_list = Classes::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();

        $userId = Auth::id();
        // $past_class =   DB::table('class_students_request')->where('student_id',$userId)->where('class_students_request.is_delete',0)
        //                 ->leftJoin('schedule_class', 'class_students_request.schedule_class_id', '=', 'schedule_class.id')
        //                 ->leftJoin('users', 'schedule_class.teacher_id', '=', 'users.id')
        //                 ->leftJoin('course', 'schedule_class.course_id', '=', 'course.id')
        //                 ->leftJoin('class_details', 'schedule_class.class_name', '=', 'class_details.id')
        //                 ->where('schedule_class.status','=',1)->where('schedule_class.is_delete',0)
        //                 ->get();
        // dd($past_class);       
        $past_class = EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.status','!=','canceled')
            // ->whereIn('event_sessions.status',['completed'])
            ->where('event_sessions.is_delete','0')
            ->where('class_students_request.is_delete','0')
            ->where('class_students_request.status','1')
           ->where('class_students_request.student_id',$userId)
           ->Where(DB::raw("DATE_ADD(CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`), INTERVAL event_sessions.`duration` MINUTE)"), '<=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type', 'schedule_class.class_type','class_students_request.creator_id')
            ->orderBy('event_sessions.start_date','desc')
            ->orderBy('event_sessions.start_time','desc')
            ->get();  
        $class_type=classType();

        return view('panel.student.class.past_class',compact('class_list','teacher_list','course_list','past_class','class_type'));
    }

    public function my_courses()
    {  
        $class_types=classType();        
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();        
        return view('panel.student.course.my_course',compact('student_list','class_types','course_list'));
    }

    public function get_my_courses(){
      $requestData = request()->all();  
      $data =[];
      $skip = $requestData['start'];
      $length = $requestData['length'];
      $orderValue = $requestData['order'][0];
      $filters = $requestData['filters'];

      $user_id = Auth::user()->id;
      

        $student_request_query = ClassStudentRequest::join('users', 'users.id', '=', 'class_students_request.student_id')  
                                ->join('schedule_class', 'schedule_class.id', '=', 'class_students_request.schedule_class_id')                          
                                ->where('class_students_request.student_id',$user_id)
                                ->where('users.account_verified','1')
                                ->where('users.is_delete',0)
                                ->where('schedule_class.is_delete',0)
                                ->where('class_students_request.is_delete',0)->where('class_students_request.status',1);


        if(isset($filters['student_id']) && $filters['student_id']!=""){
            $student_request_query->where('class_students_request.student_id',$filters['student_id']);
        }

        if(isset($filters['course_id']) && $filters['course_id']!=""){
            $student_request_query->join('class_details', 'class_students_request.class_details_id', '=', 'class_details.id') ; 
            $student_request_query->where('class_details.course_id',$filters['course_id']);
        }

        if(isset($filters['class_name']) && $filters['class_name']!=""){
            $student_request_query->where('class_students_request.class_details_id',$filters['class_name']);
        }

        if(isset($filters['class_type']) && $filters['class_type']!=""){
            $student_request_query->where('class_students_request.class_types',$filters['class_type']);
        }




                                  
        $student_request_query->select('class_students_request.*')->orderBy('id','desc');
        $total_student_request = $student_request_query->count();

        $student_request = $student_request_query->skip($skip)->take($length)->get();  
        $class_type=classType();
        $class_frequency = getFrequency();
        $request_data = [];
        $i = $skip+1;
        foreach ($student_request as $key => $request) {

            $duration = ($request->schedule_class_id)? $request->scheduleClass->duration:$request->duration;

            $can_launch = canLaunchClass($request->student_id,$request->scheduleClass->class_name,$duration); 
            $total_remaining_hours = 'Not Applicable';

            $schedule_type = $request->scheduleClass->eventSchedule()->first();
            $frequency = '-';
            if(!empty($schedule_type)){
                $frequency = $class_frequency[$schedule_type->schedule_type];
            }
            

            $action = '';
            $has_active_schedule = $request->scheduleClass->eventSchedule()->where('is_delete','0')->count();

            if($has_active_schedule && $schedule_type->schedule_type=='0'){   
                $event_session = $request->scheduleClass->eventSessions()->where('is_delete','0')->first();
                $event_start_date = $event_session['start_date'].' '.$event_session['start_time'];
                $event_end_date = date("Y-m-d H:i:s", strtotime($event_start_date . "+".$duration." minutes"));
 
                if(isPastDate($event_end_date)){ 
                    $has_active_schedule = 0;
                }
               
            }

            if($request->schedule_class_id && $request->scheduleClass->class_payment_type=='paid'){               

                $action = '<button class="btn btn-success btn-xs my-1" data-toggle="modal" data-target="#showViewPaymentsModal" student-id="'.$user_id.'" data-id="'.$request->scheduleClass->class_name.'"  data-req-id="'.$request->id.'" id="studentViewPayment">View History</button> ';
                if($has_active_schedule){
                    $action .= '<button class="btn btn-success btn-xs my-1" data-toggle="modal" data-target="#showAddCreditsModal" data-id="'.$request->id.'" id="studentPaymentRequest">Add Credits</button>';

                }
                
                $total_remaining_hours = $can_launch['total_remaining_hours'];
            }
 
            $request_data[] = [ 
                            'id' => $i,
                            'class_name' => $request->classdetails->course_name,
                            'course_name' => $request->classdetails->course->course_name,
                            'class_type' => (isset($class_type[$request->class_types]))?$class_type[$request->class_types]:'',
                            'duration' => ($duration).' Minutes',
                            'frequency' => $frequency,
                            'total_remaining_hours' => $total_remaining_hours,
                            'status' => ($has_active_schedule)?'Ongoing':'Completed',
                            
                            'action' => $action,
                            ];
            $i++;
        }

        $json_data = array(
                "draw"            => intval( $requestData['draw'] ),
                "recordsTotal"    => intval( $total_student_request ),
                "recordsFiltered" => intval( $total_student_request ),
                "data"            => $request_data,
            );

        return $json_data;

    }


    public function add_credits(){

        $request = request()->all();
        $validator = Validator::make($request, [

            'fee_per_session' => 'required|integer|min:1',
            'total_number_of_hours' => 'required|numeric|min:4',
            'total_fees' => 'required|min:1',
            

        ],
        [
          'fee_per_session.required' => 'This field is required.',
          'total_number_of_hours.required' => 'This field is required.',
          'total_fees.required' => 'This field is required.'
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }

        $request_user_id = (loggedInUser()->parent_id)? loggedInUser()->parent_id : loggedInUser()->id; 
        $student = loggedInUser();

        $seconds = ($request['total_number_of_hours'] * 3600);

        $order = new Order;
        $merchant_order_id =config('constants.ORDERID_PREFIX').date('YmdHis').$order->id;

        $order->order_date = date('Y-m-d H:i:s');
        $order->total_amount = $request['total_fees'];
        $order->total_seconds = $seconds; 
        $order->gateway_transaction_id = '';
        $order->user_id = loggedInUser()->id;
        $order->request_user_id = $request_user_id;
        $order->status = 'requested';
        $order->class_student_request_id = $request['hdn_id']; 
        $order->save();
        $order->orderid = $merchant_order_id;
        $order->save();

        $orderItem = new OrderItem;
        $orderItem->order_id = $order->id;
        $orderItem->class_id = $request['hdn_class_id'];
        $orderItem->student_id = loggedInUser()->id;
        $orderItem->amount = $request['fee_per_session'];
        $orderItem->seconds = $seconds; 
        $orderItem->save();

        // $class_name = ClassDetails::find($request['hdn_class_id']);
        

        // $data['from_email'] = config('constants.FROM_EMAIL');
        // $data['from_name']  = config('constants.FROM_NAME');
        // $data['attachment']  = '';
        // $data['class'] = $class_name->course_name;
        // $data['course'] = $class_name->course->course_name;
        // $data['total_hours'] = $request['total_number_of_hours'];
        // $data['total_amount'] = $request['total_fees'];
        // $data['fee_per_session'] = $request['fee_per_session'];
        // $data['payment_link'] = url('student/payments_due');

        // if($student->parent_id){
        //   $data['reciever_email']  = $student->parent->email;
        //   $data['reciever_name']  = $student->parent->name;   
        //   $data['student_name']  = $student->name; 
        //   $payment_req_mail = 'email.add_credits_parent_email';   
          
        // }
        // else{
        //   $data['reciever_email']  = $student->email;
        //   $data['reciever_name']  = $student->name;  
        //   $payment_req_mail = 'email.add_credits_student_email';  
        // }

        // if($data['reciever_name']!="" || !is_null($data['reciever_name'])){
        //   $data['subject']  = 'JoinIvy - Add Credits';
        //   sendMail($payment_req_mail,$data);
        // }
        
        $data_res =['merchant_order_id'=>$merchant_order_id];

        return response()->json(['success'=>true,"status"=> '1','data_res'=>$data_res], 200);
    }

    public function view_payments(){
       
        $payment_status=paymentStatus();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        
        return view('panel.student.orders.orders',compact('course_list','student_list','payment_status'));
    }

        
}
