<?php
namespace App\Http\Controllers\student;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\Classes;
use App\Course;
use App\User;
use Auth;
use Validator;
use App\AssignmentSubmit;
use App\Assignment;




class AssignmentController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function sub_n_checked_assignment()
    {
       $student_id = auth::user()->id;

        // Get Upload Assignment 
        $submit_assignments = DB::table('assignment_submited_student')
        ->where('assignment_submited_student.student_id', $student_id)
            ->where('assignment_submited_student.status','=', 2)
            ->join('users', 'assignment_submited_student.teacher_id', '=', 'users.id')
            ->join('course', 'assignment_submited_student.course_id', '=', 'course.id')
            ->join('class_details', 'assignment_submited_student.class_id', '=', 'class_details.id')
            ->join('assignment', 'assignment_submited_student.ass_id', '=', 'assignment.id')
            ->select('assignment_submited_student.*','users.name', 'course.course_name', 'class_details.course_name as class_name', 'assignment.document_file as teacher_document')
            ->get();


        return view('panel.student.assignment.sub_n_checked_assignment',compact('submit_assignments'));
    }


     public function submitted_n_to_be_check_assignment()
    {
        $student_id = auth::user()->id;

        // Get Upload Assignment 
        $submit_assignments = DB::table('assignment_submited_student')
        ->where('assignment_submited_student.student_id', $student_id)
            ->where('assignment_submited_student.status','=', 1)
            ->join('users', 'assignment_submited_student.teacher_id', '=', 'users.id')
            ->join('course', 'assignment_submited_student.course_id', '=', 'course.id')
            ->join('class_details', 'assignment_submited_student.class_id', '=', 'class_details.id')
            ->join('assignment', 'assignment_submited_student.ass_id', '=', 'assignment.id')
            ->select('assignment_submited_student.*','users.name', 'course.course_name', 'class_details.course_name as class_name', 'assignment.document_file as teacher_document')
            ->get();

        // dd($submit_assignments);    

        return view('panel.student.assignment.sub_n_to_be_check_assignment',compact('submit_assignments'));
    }


    public function due_from_me_assignment()
    {
       

        $student_id = auth::user()->id;

        $assignments = DB::table('class_students_request')
            ->where('student_id', $student_id)
            ->join('assignment', 'class_students_request.class_details_id', '=', 'assignment.class_id')
            ->join('users', 'assignment.teacher_id', '=', 'users.id')
            ->join('course', 'assignment.course_id', '=', 'course.id')
            ->join('class_details', 'assignment.class_id', '=', 'class_details.id')
            ->select('class_students_request.*','assignment.*','users.name','course.course_name', 'class_details.course_name as class_name')
            ->where('assignment.status', '=' ,0)    
            ->get();


        return view('panel.student.assignment.due_from_me_assignment',compact('class_list','teacher_list','course_list','assignments'));
    }

    public function submitAssignment()
    {

        $validator = Validator::make(request()->all(), [
            'document' => 'required|mimes:doc,docx',
            'description' => 'required',
        ]);

        if ($validator->fails()) 
        {  
            $error=json_decode($validator->errors());          
            return response()->json(['status' => 401,'error1' => $error]);
            exit();
        }


        $date = date('Y-m-d h:i:s');
        $ass_id = request()->ass_id;
        $class_id = request()->class_id;
        $course_id = request()->course_id;
        $teacher_id = request()->teacher_id;
        $description = request()->description;
        $student_id = auth::user()->id;

        if(!empty(request()->document))
        {
            $document_data = ImageUpload::upload('submit_assignment/',request()->file('document'));
            $document = $document_data;
        }
        else
        {
            $document = 'course_default_img.png';
        }

        $data = array([

                'ass_id' => $ass_id,
                'teacher_id' => $teacher_id,
                'student_id' => $student_id,
                'class_id' => $class_id,
                'course_id' => $course_id,
                'description' => $description,
                'document_file' => $document,
                'status' => 1,
                'created_at' => $date
        ]);

        if (AssignmentSubmit::insert($data)) 
        {

            Assignment::where('id', $ass_id)->update(['status' => 1]);

        }

        return response()->json(['status' => 1]);



    }
}
