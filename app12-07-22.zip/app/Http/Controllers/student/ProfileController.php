<?php
namespace App\Http\Controllers\student;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\User;
use App\StudentDetails;
use Auth;

class ProfileController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
   
    public function myProfile()
    {
        $id = Auth::id();
        $student_details = User::join('student_details','student_details.student_id','users.id')->where('users.id',$id)->first();
        $parents_details = User::where('id',$student_details->parent_id)->first();
        return view('panel.student.profile.index',compact('student_details','parents_details'));
    }
    public function myProfile_get(Request $request)
    {
        $student_details = User::join('student_details','student_details.student_id','users.id')->where('users.id',$request->id)->get();
        if(!empty($student_details[0]->s_nationality))
        {
            $stud_nationality = explode(',',$student_details[0]->s_nationality);
            $stud_nationality_arr_make = array();
            foreach($stud_nationality as $key => $value)
            {
               $st_nat =  $value;
               array_push($stud_nationality_arr_make,$st_nat);
            }
        }
        $student_details['id'] = $request->id;
        $student_details['nationality'] = !empty($stud_nationality_arr_make) ? $stud_nationality_arr_make : '';
        $student_details['image'] = !empty($student_details[0]->image) ? $student_details[0]->image : '';
        $student_details['school_name'] = !empty($student_details[0]->s_school_name) ? $student_details[0]->s_school_name : '';
        $student_details['school_address'] = !empty($student_details[0]->s_school_address) ? $student_details[0]->s_school_address : '';
        $student_details['residence_address'] = !empty($student_details[0]->s_residence_address) ? $student_details[0]->s_residence_address : '';
        if(!empty($student_details[0]->parent_id))
        {
            $parents_details = User::where('id',$student_details[0]->parent_id)->get();
            $student_details['parent_residence_address'] = !empty($parents_details[0]->p_residence_address) ? $parents_details[0]->p_residence_address : '';
        }
        return response()->json(['status' => 1,'success' => $student_details]);
    }
    public function update_profile(Request $request)
    {
       // dd($request->all());

        if(!empty($request->profile_image))
        {
            $profile_pic = ImageUpload::upload('students/',$request->profile_image);
            $image = $profile_pic;
        }
        else
        {
            $image = $request->profile_old_image;
        }

        $nationality = !empty($request->nationality) ? implode(',',$request->nationality) : "";

        $student_data =  array('s_nationality'=>$nationality,'s_school_name'=>$request->school_name,'s_school_address'=>$request->school_address,'s_residence_address'=>$request->residence_address);
        StudentDetails::where('student_id',$request->id)->update($student_data);

        $image_data = array('image'=>$image);
        User::where('id',$request->id)->update($image_data);

        if(!empty($request->parent_residence_address))
        {
            $check_parent = User::where('id',$request->parent_id)->get();
            //dd($check_parent);
            if(count($check_parent)!=0)
            {
                $parent_data = array('p_residence_address'=>$request->parent_residence_address);
                User::where('id',$request->parent_id)->update($parent_data);
            }
        }
        $student_data['id'] = $request->id;
        return response()->json(['status' => 1,'success' => $student_data]);
    }

}
