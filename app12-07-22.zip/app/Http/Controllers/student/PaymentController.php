<?php
namespace App\Http\Controllers\student;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Hash;
use DB;
use App\ImageUpload;
use App\Classes;
use App\Course;
use App\User;
use App\Order;
use Session;

class PaymentController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    /*----course-----*/
    public function payment()
    {
        $class_list = Classes::where('is_delete','0')->get();
        $course_list = Course::where('is_delete','0')->where('parent_id','!=','0')->get();
        $teacher_list = User::where('is_delete','0')->where('user_type','2')->where('account_verified','1')->get();
        return view('panel.student.payment.payment',compact('class_list','teacher_list','course_list'));
    }

    public function paymentsDue()
    {
        $user = loggedInUser();
        $student_id = $user->id;

        if($user->user_type=='4'){
            Session::put('STUDENT_REDIRECT_PAYMENTDUE',true);
            return redirect("parent/home");
        }

         //echo \Auth::id(); echo $user_id; exit;
        if($user->parent_id){
            $parent_id = $user->parent_id;
            $orders_list = Order::join('order_items', 'order_items.order_id', '=', 'orders.id')->where('order_items.student_id',$student_id) 
            ->where('orders.request_user_id',$parent_id)->where('orders.status','requested')->get(); 
        }
        else{
            $user_id = $user->id;
            $orders_list = Order::where('request_user_id',$student_id)->where('status','requested')->get(); 
        }
        

        return view('panel.student.payment.payment_due',compact('orders_list'));
    }

    public function payNow()
    {
        $user_id = loggedInUser()->id;  
        $order_id = $_REQUEST['order_id'];
        $order = Order::where('orderid',$order_id)->first(); 
        $payment_key = '';
        if(!empty($order) && $order->status == 'requested'){           


            $order_total_amount = $order->total_amount * config('constants.AMOUNT_CENT_VAL');

            $auth = createPayMobAuthToken();
            $payment_key = '';
            $token = '';

            if($auth['status'] == "success"){
                $auth_response = json_decode($auth['response']); 
                $token = $auth_response->token;
            }

            $transaction_id = $order->gateway_transaction_id;
            if($token!="" && $order->gateway_transaction_id==""){       
                
                $marchant_id = $auth_response->profile->id;
                
                //register order request
                $register_order_data = array();
                $register_order_data['auth_token'] = $token;
                $register_order_data['delivery_needed'] = false;
                $register_order_data['merchant_id'] = $marchant_id;
                $register_order_data['amount_cents'] = $order_total_amount;
                $register_order_data['currency'] = config('constants.CURRENCY');
                $register_order_data['merchant_order_id'] = $order_id;
                $register_order_data['items'] = [];
                $register_order_request = registerOrderRequest($register_order_data);  

                if($register_order_request['status'] == "success"){
                    $register_order_request_response = json_decode($register_order_request['response']);  
                    $transaction_id = $register_order_request_response->id;
                    $order->gateway_transaction_id = $transaction_id;
                    $order->order_complete_user_id = loggedInUser()->id;
                    $order->save();
                }
                    
                
            }

            if($token!="" && $transaction_id!=""){
                $payment_keyrequest_data = [];
                $payment_keyrequest_data['auth_token'] = $token;
                $payment_keyrequest_data['amount_cents'] = $order_total_amount;
                $payment_keyrequest_data['expiration'] = 3600;
                $payment_keyrequest_data['order_id'] = $transaction_id;
                $payment_keyrequest_data['currency'] = config('constants.CURRENCY');
                $payment_keyrequest_data['integration_id'] = config('constants.INTEGRATION_ID');
                $payment_keyrequest_data['billing_data'] = userBillingData($order->request_user_id);
                $payment_key_request = paymentKeyRequest($payment_keyrequest_data);

                if($payment_key_request['status'] == "success"){
                    $payment_key_request_response = json_decode($payment_key_request['response']); 
                    $payment_key = $payment_key_request_response->token;
                }
            }
        
        }



        $iframe_id = config('constants.IFRAME_ID');
        return view('panel.student.payment.payment_now',compact('payment_key','iframe_id'));
    }

    public function updatePaymentStatus(){ //dd($_REQUEST);

      $user_id = loggedInUser()->id;  
      $merchant_order_id = (isset($_REQUEST['merchant_order_id']))?$_REQUEST['merchant_order_id']:'';
      $order = Order::where('orderid',$merchant_order_id)->where('order_complete_user_id',$user_id)->first();
      
      if(empty($order)){
        return redirect("/");
      }

      $order_amount = config('constants.CURRENCY').' '.$order->total_amount;

      $status = (isset($_REQUEST['success']))?$_REQUEST['success']:'';
      $message = (isset($_REQUEST['data_message']))?$_REQUEST['data_message']:'';
      // $message = str_replace("+", " ", $message);


      if($status=='false' && $order->status == 'requested'){
        $order->status = 'failed';
        $order->save();
      }
      

      return view('panel.student.payment.payment_response',compact('status','message','merchant_order_id','order_amount'));
    }
}
