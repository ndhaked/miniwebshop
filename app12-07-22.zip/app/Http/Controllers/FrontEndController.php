<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\EventSession;
use App\EventSchedule;
use App\WizIqResponse;
use App\PaymentResponse;
use App\Order;
use App\LessonCredit  ;

class FrontEndController extends Controller
{
    public function updateClassStatus(){  
        $wiziqStatus = wiziqStatus();
        $class_id = $_REQUEST['class_id'];
        $class_status = $_REQUEST['class_status'];

        
        $wizIqResponse = new WizIqResponse;
        $wizIqResponse->cron_type = 'session_status_webhook';
        $wizIqResponse->response_data = serialize($_REQUEST);
        $wizIqResponse->save();

        if(isset($wiziqStatus[$class_status])){
          $eventSession = EventSession::where('wiziq_class_id',$class_id)->first();
          $eventSession->status = $wiziqStatus[$class_status];
          $eventSession->save();
        }
        
    }

    public function paymobNotification(){
      $request = request()->all();  

      $paymentResponse = new PaymentResponse;
      $paymentResponse->type = 'payment_notification';
      $paymentResponse->response_data = serialize($request);
      $paymentResponse->save();

      if(isset($request['type']) && $request['type']=="TRANSACTION"){
          $transction = $request['obj'];
          $order = $request['obj']['order'];
          $order_id =$order['id'];
          $order = Order::where('gateway_transaction_id',$order_id)->first();

          $orderitem = $order->orderItems()->first();
          
          if($transction['success']=='true'){
            $order->status = 'paid';
            $data['subject']  = 'JoinIvy - Payment Success';

            $lc_entry = LessonCredit::where('order_id',$order->id)->first();

            if(empty($lc_entry)){
                $lessonCredits = new LessonCredit();
                $lessonCredits->user_id = $orderitem->student_id;
                $lessonCredits->object_type = 'App\Order';
                $lessonCredits->object_id = $order->id;
                $lessonCredits->seconds = $orderitem->seconds;
                $lessonCredits->class_id = $orderitem->class_id;
                $lessonCredits->status = 'credited';
                $lessonCredits->save();
            }


          }
          elseif($transction['success']=='false'){
            $order->status = 'failed';
            $data['subject']  = 'JoinIvy - Payment Failed';
          }
          $order->payment_date = date('Y-m-d H:i:s');
          $order->save();

          $notification_user = $order->orderCompletedUser;
        
          
          $data['from_email'] = config('constants.FROM_EMAIL');
          $data['from_name']  = config('constants.FROM_NAME');
          $data['attachment']  = '';
          $data['class'] = $order->classStudentRequest->classdetails->course_name;
          $data['total_hours'] = $order->total_seconds/3600;
          $data['total_amount'] = $order->total_amount;
          $data['orderid'] = $order->orderid;
         

          if($notification_user->user_type=='4'){
            $data['reciever_email']  = $notification_user->email;
            $data['reciever_name']  = $notification_user->name;   
            $data['student_name']  = $order->classStudentRequest->student->name; 
            if($transction['success']=='true'){
              $payment_response_mail = 'email.payment_request_success_parent_email';  
            }
            elseif($transction['success']=='false'){
              $payment_response_mail = 'email.payment_request_failure_parent_email';  
            }
 
          }
          else{
            $data['reciever_email']  = $notification_user->email;
            $data['reciever_name']  = $notification_user->name;  

            if($transction['success']=='true'){
              $payment_response_mail = 'email.payment_request_success_student_email';  
            }
            elseif($transction['success']=='false'){
              $payment_response_mail = 'email.payment_request_failure_student_email';  
            }
          }
          
          if($data['reciever_name']!="" || !is_null($data['reciever_name'])){            
            sendMail($payment_response_mail,$data);
          }

        return response()->json(['success' => true,'msg' => 'Transaction Updated'],200);
      }

      return response()->json(['success' => false,'msg' => 'Faled To Transaction Updated'],200);
    }

    public function testMails(){
      // $data = getScheduleSessionData('403');
      // $data = getScheduleSessionData('385');
      // // $data['event_sessions'] = getSessionData('81');
      // $data['reciever_name'] = 'Prajay';
      // $data['student_name'] = 'Ajay';

      $data = ["from_email" => "info@joinivy.com",
  "from_name" => "JoinIvy",
  "attachment" => "",
  "class" => "Reading Comprehension for grades 2-12",
  "course" => "Reading Comprehension for grades 2-12",
  "fee_per_session" => "5",
  "total_hours" => "10",
  "total_amount" => "50",
  "payment_link" => "http://localhost/joinivy-live/student/payments_due",
  "reciever_email" => "riju_march@yahoo.com",
  "reciever_name" => "Mr. Riju Trivedi",
  "student_name" => "Mr. Student under 18 0210"];
    
   
     
      return view('email.payment_request_parent_email',compact('data'));

    }
}
