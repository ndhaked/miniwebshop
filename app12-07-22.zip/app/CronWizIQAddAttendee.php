<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CronWizIQAddAttendee extends Model
{
    Protected $table = 'cron_wiziq_add_attendee'; 

    

}
