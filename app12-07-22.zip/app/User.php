<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Auth;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','mobile','role','account_status'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function parent() {
        return $this->belongsTo( 'App\User' ,'parent_id');
    }

    public function details() {
        return $this->hasOne( 'App\StudentDetails' ,'student_id');
    }

    public function teacherdetails() {
        return $this->hasOne( 'App\TeacherDetails' ,'teacher_id');
    }

    public function getUserSession(){
        if(Auth::check()){
            return Auth::user();
        }
        else{
            return false;
        }
    }
}
