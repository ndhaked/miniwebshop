<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScheduleCron extends Model
{
    protected $table = 'session_schedule_cron';
    protected $fillable = ['schedule_class_id','last_session_created'];
    public $timestamps = false;
}
