<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class AddAttendeeStudentClass extends Model

{

    Protected $table = 'add_attendee_student_class';  

}
