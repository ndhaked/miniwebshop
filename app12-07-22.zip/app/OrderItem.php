<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    // 
    Protected $table = 'order_items';

    public function classdetails() {
        return $this->belongsTo( 'App\ClassDetails' ,'class_id');
    }  
}
