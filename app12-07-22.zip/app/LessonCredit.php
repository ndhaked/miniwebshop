<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LessonCredit extends Model
{
    public function order()
    {
    	return $this->belongsTo( 'App\Order','object_id');
    }

    public function user() {
        return $this->belongsTo( 'App\User','object_id');
    }

    public function student() {
        return $this->belongsTo( 'App\User','user_id');
    }

    public function event_session() {
        return $this->belongsTo( 'App\EventSession','object_id');
    }

    public function classdetails() {
        return $this->belongsTo( 'App\ClassDetails' ,'class_id');
    }

    public function creditOrder()
    {
        return $this->belongsTo( 'App\Order','order_id');
    }
}
