<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Defaults extends Model
{
    Protected $table = 'defaults';  
}
