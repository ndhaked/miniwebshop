<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class AssignmentSubmit extends Model
{

    Protected $table = 'assignment_submited_student';  
    public $timestamps = false;

}

