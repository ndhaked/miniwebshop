<?php



namespace App;



use Illuminate\Database\Eloquent\Model;



class ScheduleClass extends Model

{

    Protected $table = 'schedule_class';  

    public function course() {
        return $this->belongsTo( 'App\Course','course_id');
    }

    public function class() {
        return $this->belongsTo( 'App\ClassDetails' ,'class_name');
    }

    public function studentClassRequest() {
        return $this->hasOne( 'App\ClassStudentRequest' ,'schedule_class_id');
    }

    // :P
    public function studentClassRequestMany() {
        return $this->hasMany( 'App\ClassStudentRequest' ,'schedule_class_id');
    }

    public function eventSessions() {
        return $this->hasMany( 'App\EventSession' ,'schedule_class_id');
    }

    public function eventSchedule() {
        return $this->hasMany( 'App\EventSchedule' ,'schedule_class_id');
    }

}

