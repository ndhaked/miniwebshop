<?php
 function cronCreateScheduleSessions(){

 	$session_length = getDefaultValue('db_event_upcoming_weeks_length'); 
 	$occurance_type = [4];
	$additional_data =[]; 

	$class_schedule = \App\EventSchedule::where('is_delete','0')->whereIn('schedule_type',$occurance_type)->select(DB::raw('DISTINCT(schedule_class_id) as schedule_class_id'))->get(); 
	foreach ($class_schedule as $key => $schedule) {
		addRecurringSessions($schedule->schedule_class_id,$occurance_type,$session_length,0,$additional_data);
	}
 	
 	//update last cron run
 	$last_cron_run = \App\Defaults::where('type','db_event_session_cron_last_run')->first();
 	$last_cron_run->value= date('Y-m-d H:i:s');
 	$last_cron_run->save();

 }

  function cronCreateWizIQSessions(){

    if(is_develop())
    {
      return true;
    }  
    
 	$add_minutes = getDefaultValue('wiziq_create_api_from_x_minutes');  
 	$current_date = date('Y-m-d H:i:s');  
 	$date_check = date('Y-m-d H:i:s', strtotime($current_date.' + '.$add_minutes.' minute'));
 	$splitdate = explode(" ", $date_check);
 	$new_date = $splitdate[0];
 	$new_time = $splitdate[1];
  

 	$access_key= config('constants.WIZIQ_SECRET_KEY');  
    $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
    $webServiceUrl= config('constants.WIZIQ_API_URL');
 	 
 	// $access_key="nbaqEtPHk3E=";
  //   $secretAcessKey="fipzu+2E2bDJRRPjjE418w==";
  //   $webServiceUrl="https://classapi.wiziqxt.com/apimanager.ashx";

 	include(app_path().'/edu_api/create.php');
 	include(app_path().'/edu_api/AddAttendee.php');
  include(app_path().'/edu_api/AddCopresenter.php');

 	$sessions = \App\EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
 			// ->leftjoin('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->whereNull('event_sessions.wiziq_class_id')
            ->where('event_sessions.status','!=','canceled')
            ->where('event_sessions.is_delete','0')
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '<=', $date_check)
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '>', $current_date)
            // ->where('event_sessions.start_date','<=',$new_date)
            // ->where('event_sessions.start_time','<=',$new_time)
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'event_sessions.teacher_id')//,'class_students_request.id as class_students_request_id','class_students_request.student_id'
            ->orderBy(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"),'asc')
            ->limit(5)
            ->get();


	foreach ($sessions as $key => $session) { 

		$date = explode("-",$session->start_date);
    	$start_date = $date[1].'/'.$date[2].'/'.$date[0];

		$time = explode(':', $session->start_time);
		$start_time = $time[0].':'.$time[1];

 
		$class_name = $session->schedule_class->class->course_name;
		$duration_time = $session->duration;
		$teacher_id = $session->teacher_id;
    $assistant_teacher_id = $session->assistant_teacher_id;
		$attendee_limit = '2';
		$create_recording = 'true';
		$teacher_name = $session->user->name;
    
		// $student_name = $session->schedule_class->studentClassRequest->student->name;

 
		$obj =  ScheduleClass($secretAcessKey,$access_key,$webServiceUrl, $start_date, $start_time, $class_name, $duration_time, $teacher_id, $attendee_limit,$create_recording, $teacher_name);  
		 
		if($obj['errormsg']== null){
			$class_master_id = (isset($obj['class_master_id'])) ? $obj['class_master_id']:'0';
			$teacher_recording_url = $obj['presenter_urlTag'];
			$recording_url = $obj['recording_url'];

       $session->wiziq_master_class_id = $class_master_id;
       $session->wiziq_class_id = $obj['class_ids'];
       $session->recording_url = $recording_url;
       // $session->student_recording_url = $obj_student['student_attendee_url'];
       $session->teacher_recording_url = $teacher_recording_url;
       $session->status = 'upcoming_booked';

     if(!is_null($session->assistantTeacher)){
        $assistant_teacher_name = $session->assistantTeacher->name;

        $assistant_teacher_recording_url =  AddCopresenter($secretAcessKey,$access_key,$webServiceUrl, $start_date, $start_time, $class_name, $duration_time, $assistant_teacher_id, $attendee_limit,$create_recording, $assistant_teacher_name, $obj['class_ids']); 
        if(isset($assistant_teacher_recording_url['errormsg'])){
          \Log::info('AddCopresenter Error: '.$assistant_teacher_recording_url['errormsg'].', Session: '.json_encode($session));
        }
        else{
          $session->assistant_teacher_recording_url = $assistant_teacher_recording_url; 
        }
      }
      $session->save(); 

			$student_api_array=array();
      $all_students = \App\ClassStudentRequest::where('schedule_class_id',$session->schedule_class_id)->where('status','1')->where('is_delete','0')->get();

      foreach ($all_students as $key => $enrolledstudent) {
          $student_api_array[] = ['id'=>$enrolledstudent->student_id,'name'=>$enrolledstudent->student->name];
      }

          	// $student_api_details['id']= $session->class_students_request_id;
          	// $student_api_details['name']=$student_name;
          	// array_push($student_api_array, $student_api_details);


          	$obj_student =  AddAttendee($secretAcessKey,$access_key,$webServiceUrl,$obj['class_ids'],$student_api_array);  
          	// if($obj['errormsg']== null){
          	// 	$session->wiziq_master_class_id = $class_master_id;
          	// 	$session->wiziq_class_id = $obj['class_ids'];
          	// 	$session->recording_url = $recording_url;
          	// 	$session->student_recording_url = $obj_student['student_attendee_url'];
          	// 	$session->teacher_recording_url = $teacher_recording_url;
          	// 	$session->status = 'upcoming_booked';

          	// 	$session->save();
          	// }
            if(!isset($obj['errormsg'])){ 
              $insert_student_wiziqurl = array();
              foreach ($obj_student as $key => $wizstudent) {
                 $insert_student_wiziqurl[] = array('event_session_id'=>$session->id, 'user_id'=>$wizstudent['attendee_id'],'student_wiziq_url'=>$wizstudent['student_attendee_url']);
              }

              \App\EventParticipant::insert($insert_student_wiziqurl);
            }
		}
		
	}
 

 }

 function updateLessonCredits(){
    $get_all_live_class = \App\EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->whereIn('event_sessions.status',['upcoming_booked','live'])
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '<=', date('Y-m-d H:i:s'))
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ',event_sessions.`start_time`) + INTERVAL event_sessions.`duration` MINUTE + INTERVAL 120 MINUTE"), '>=', date('Y-m-d H:i:s'))
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name',  'schedule_class.class_payment_type', 'schedule_class.class_type')
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->limit(5)
            ->get();
 
    foreach ($get_all_live_class as $key => $live_class) {
        if($live_class->status == 'upcoming_booked'){
          $live_class->status = 'live';
          $live_class->should_debit = 1;
          $live_class->save();
        }
        $class_datetime = new DateTime($live_class->start_date.' '.$live_class->start_time);
        $class_datetime->add(new DateInterval("PT120M"));
        $current_datetime = new DateTime('now');
        if($live_class->class_payment_type == 'paid' && $live_class->should_debit == 1 && $current_datetime > $class_datetime ){
          $class_id = $live_class->class_name;

          // minutes to seconds
          $seconds = ($live_class->duration * 60);

          $student_debits = array();
          $event_participants = \App\EventParticipant::where('event_session_id',$live_class->id)->get(); 
          if($event_participants->count()){
            foreach ($event_participants as $key => $participant) {
               $student_debits[] = array('user_id'=>$participant->user_id, 'object_type'=>'App\EventSession','object_id'=>$live_class->id,'seconds'=>$seconds,'class_id'=>$class_id,'status'=>'debited','created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'));
            }

            \App\LessonCredit::insert($student_debits);
          }
          $live_class->should_debit = 0;
          $live_class->save();
        }

    }

 }


 function cronCreateWizIQSessionstest(){
 	$add_minutes = getDefaultValue('wiziq_create_api_from_x_minutes');  
 	$current_date = date('Y-m-d H:i:s');  
 	$date_check = date('Y-m-d H:i:s', strtotime($current_date.' + '.$add_minutes.' minute'));
 	$splitdate = explode(" ", $date_check);
 	$new_date = $splitdate[0];
 	$new_time = $splitdate[1];
  

 	$access_key= config('constants.WIZIQ_SECRET_KEY');  
    $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
    $webServiceUrl= config('constants.WIZIQ_API_URL');
 	 
 	include(app_path().'/edu_api/create.php');
 	include(app_path().'/edu_api/AddAttendee.php');

 	$sessions = \App\EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
 			->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->whereNull('event_sessions.wiziq_class_id')
            ->where('event_sessions.is_delete','0')
            ->Where(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"), '>=', $date_check)
            // ->where('event_sessions.start_date','<=',$new_date)
            // ->where('event_sessions.start_time','<=',$new_time)
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'event_sessions.teacher_id','class_students_request.id as class_students_request_id','class_students_request.student_id')
            ->orderBy(DB::raw("CONCAT(event_sessions.`start_date`, ' ', event_sessions.`start_time`)"),'asc')
            ->limit(5)
            ->get();

	dd($sessions);
 }
