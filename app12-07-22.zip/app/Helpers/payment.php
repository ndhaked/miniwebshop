<?php


function createPayMobAuthToken(){ 
	$post_data = array();
	$post_data['api_key'] = config('constants.PAYMOB_APIKEY');
	$json = json_encode($post_data);
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => "https://accept.paymobsolutions.com/api/auth/tokens",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => $json,
	  CURLOPT_HTTPHEADER => array(
	    "cache-control: no-cache",
	    "content-type: application/json"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return ['status'=>'error','error'=>"cURL Error #:" . $err];
	} else {
		return ['status'=>'success','response'=>$response];
	   
	}
	
}

function registerOrderRequest($post_data){ 
	$json = json_encode($post_data);
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => "https://accept.paymobsolutions.com/api/ecommerce/orders",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => $json,
	  CURLOPT_HTTPHEADER => array(
	    "cache-control: no-cache",
	    "content-type: application/json"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return ['status'=>'error','error'=>"cURL Error #:" . $err];
	} else {
		return ['status'=>'success','response'=>$response];
	   
	}
	
}

function paymentKeyRequest($post_data){ 
	
	$json = json_encode($post_data);
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => "https://accept.paymobsolutions.com/api/acceptance/payment_keys",
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => "",
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 30,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => "POST",
	  CURLOPT_POSTFIELDS => $json,
	  CURLOPT_HTTPHEADER => array(
	    "cache-control: no-cache",
	    "content-type: application/json"
	  ),
	));

	$response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return ['status'=>'error','error'=>"cURL Error #:" . $err];
	} else {
		return ['status'=>'success','response'=>$response];
	   
	}
	
}

function userBillingData($user_id){
	$user = \App\User::find($user_id);
	$name = explode(" ", $user->name);
	 
	$fname = (isset($name[0])) ? $name[0] :'';
	$lname = (isset($name[1])) ? $name[1] :'';  
	$lname .= (isset($name[2])) ? ' '.$name[2] :'';

	
	$billing_data['apartment'] = "NA";
	$billing_data['email'] = $user->email;
	$billing_data['floor'] = "NA";
	$billing_data['first_name'] = $fname;
	$billing_data['street'] = "NA";
	$billing_data['building'] = "NA";
	$billing_data['phone_number'] = $user->mobile;
	$billing_data['shipping_method'] = "PKG";
	$billing_data['postal_code'] = "NA"; 
	$billing_data['city'] =  "NA";
	$billing_data['country'] = (!empty($user->details))?$user->details->s_country:'-';
	$billing_data['last_name'] = $lname; 
	$billing_data['state'] =  "NA";
 
	return $billing_data;
	 
}



