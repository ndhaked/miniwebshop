<?php

function loggedInUser(){
	return \Auth::user();
}

function testwp(){

	return session()->get('loggedin_user');
}

function hasDashboardAccess($type){  
	if(\Auth::check()){
		if(loggedInUser()->user_type!=$type){
        	return redirect(getDashboardPath());
    	}

	}	
    else
    {
    	return redirect('/');
    }
}


function getDashboardPath(){
	if(\Auth::user()->user_type=='1') { 
        return '/admin/home';
    }
    if(\Auth::user()->user_type=='3') { 
        return '/student/home';
    } 
    if(\Auth::user()->user_type=='2') {
        return '/teacher/home';
    } 
    if(\Auth::user()->user_type=='4') { 
        return '/parent/home';
    }
}

function userTypes(){
	return ['1'=>'Admin','2'=>'Teacher','3'=>'Student','4'=>'Parent'];
}

function isPastDate($date){
	// $today = \Carbon\Carbon::now();  
 	if (\Carbon\Carbon::parse($date)->lt(\Carbon\Carbon::now())){		 
         return true;
    }
     
    return false;
}

function canCanelClass($date){
	 
	$minutes = getDefaultValue('allow_cancel_class_x_mins_before');  
	$add_duration = date("Y-m-d H:i:s", strtotime('-'.$minutes.' minute', strtotime($date))); 
	// echo $add_duration;
	// echo \Carbon\Carbon::now();
 	if (\Carbon\Carbon::parse($add_duration)->lt(\Carbon\Carbon::now())){		 
         return false;
    }
     
    return true;
}

function currentRouteName(){
	return \Route::currentRouteName();
}


function getDefaultValue($type){
	return \App\Defaults::where('type',$type)->pluck('value')->first();

}

function newTeacherNotify(){
	return \App\User::where('user_type','2')->where('new_user','1')->count();

}

function newStudentNotify(){
	return \App\User::where('user_type','3')->where('new_user','1')->count();

}

function newUsersNotify(){
	return \App\User::whereIn('user_type',['3','2'])->where('new_user','1')->count();

}

function sessionStatus(){
	return ['upcoming_proposed'=>'Upcoming Proposed','upcoming_booked'=>'Upcoming Booked','live'=>'Live','completed'=>'Completed','canceled'=>'Cancelled','cancel_request'=>'Cancel Request','expired'=>'Expired'] ;

}

function paymentStatus(){
	return ['requested'=>'Requested','paid'=>'Paid','canceled'=>'Canceled','failed'=>'Failed','credited'=>'Credited','debited'=>'Debited'] ;

}

function wiziqStatus(){
	return ['live'=>'live','completed'=>'completed','expired'=>'expired'] ;
}

function durations(){
	return ['30'=>'30 minutes','60'=>'60 minutes','90'=>'90 minutes','120'=>'120 minutes'] ;

}

function classType(){
	return ['1'=>'One to One Class','3'=>'Batch Class'] ; //,'2'=>'Buddy Class'

}

function startOfTheWeekDate($date){
	$day = strtolower(date("l", strtotime($date)));
        
    if($day!='sunday'){
      $startoftheweek = date("Y-m-d", strtotime('last sunday', strtotime($date)));
    }
    else{
      $startoftheweek =$date;
    }

    return $startoftheweek;
}

function endOfTheWeekDate($session_start_date){
	$day = strtolower(date("l", strtotime($session_start_date)));
	 
    if($day!='saturday'){
      $endoftheweek = date("Y-m-d", strtotime('next saturday', strtotime($session_start_date)));
    }
    else{
      $endoftheweek =$session_start_date;
    }

    return $endoftheweek;
}

function createNewSchedue($request,$schedule_class_id){

	$session_length = getDefaultValue('db_event_upcoming_weeks_length');   

	//add sessions
	$recurring_data = [];
	if(isset($request['occurance_type'])){
		if($request['occurance_type'] == '0'){
			$session_length = 1;
			addSchedule($request['occurance_type'],'',$request['onetime_date'],$request['onetime_time'],$schedule_class_id);
		}
		elseif($request['occurance_type'] == '4'){

			$days_of_week = $request['days_of_week']; 
			foreach ($days_of_week as  $day) {
				addSchedule($request['occurance_type'],$day,$request['weekly_date'],$request[$day.'_time'],$schedule_class_id);
			}
		}

	}

	$additional_data['teacher_name'] = $request['teacher_name'];
	if(isset($request['assistant_teacher_name'])){
		$additional_data['assistant_teacher_name'] = $request['assistant_teacher_name'];
	}
	$additional_data['duration'] = $request['time_duration'];
	$additional_data['submit_mode'] = $request['submit_mode'];
	addRecurringSessions($schedule_class_id,[$request['occurance_type']],$session_length,0,$additional_data);
	 
 
}

function addRecurringSessions($schedule_class_id,$occurance_type=[],$session_length,$added_count,$additional_data){
	$schedules = \App\EventSchedule::where('schedule_class_id',$schedule_class_id)->where('is_delete','0')->whereIn('schedule_type',$occurance_type)->orderBy('start_date','asc')->get();
	
	$is_edit = (!empty($additional_data) && isset($additional_data['submit_mode']) && $additional_data['submit_mode']=='edit') ? true :false;

	$last_event_session = (!$is_edit)? \App\EventSession::where('schedule_class_id',$schedule_class_id)->where('is_delete','0')->orderBy('start_date','desc')->first():array();
	 
	$class_schedule = \App\ScheduleClass::find($schedule_class_id);

	$teacher_id = $class_schedule->teacher_id;
	$assistant_teacher_id = $class_schedule->assistant_teacher_id;
	$duration = $class_schedule->duration;

	if(!empty($additional_data)){
		$teacher_id = $additional_data['teacher_name'];
		if(isset($additional_data['assistant_teacher_name'])){
			$assistant_teacher_id = $additional_data['assistant_teacher_name'];
		}
		$duration = $additional_data['duration'];
	}

	$created_by = (loggedInUser()) ?loggedInUser()->id:config('constants.CRON_USER');

 
	// dd($schedules);
	foreach ($schedules as $key => $schedule) {

		if(!empty($last_event_session)){
			 
			$start_date = $last_event_session->start_date;		
			
			if($schedule->day!=""){
			 
				$date = new DateTime($start_date);			 
				$date->modify('next '.$schedule->day);			 
				$schedule_start_date = $date->format('Y-m-d');
				
			}

		}
		else{
			$schedule_start_date = $schedule->start_date;
		}

		//date is not past date
		 
        if(isPastDate($schedule_start_date))
        {  
            $schedule_start_date = date("Y-m-d");
        }
 
		if($added_count < $session_length){
			$event_session = new \App\EventSession;
			$event_session->teacher_id = $teacher_id;
			$event_session->assistant_teacher_id = ($assistant_teacher_id) ? $assistant_teacher_id : 0;
			$event_session->schedule_class_id = $schedule_class_id;
			$event_session->event_schedule_id =$schedule->id;
			$event_session->start_date=$schedule_start_date;
			$event_session->start_time=$schedule->start_time;
			$event_session->duration = $duration;
			$event_session->created_by = $created_by;
			$event_session->status = 'upcoming_proposed';
			$event_session->save();

			$schedule->start_date=$schedule_start_date;
			$schedule->save();

			
			
		}
		

		
	}
	$added_count++;
	if($added_count < $session_length){
		addRecurringSessions($schedule_class_id,$occurance_type,$session_length,$added_count,$additional_data);
	}

 

	// $schedule_cron = \App\ScheduleCron::firstOrNew(array('schedule_class_id' => $schedule_class_id));
	// $schedule_cron->last_session_created = $schedule_start_date.' '.$schedule->start_time;
	// $schedule_cron->save();



}

function addSchedule($schedule_type,$day,$date,$time,$schedule_class_id){
	//add schedule frequency
	
	$dob_get = explode("/",$date);
    $newDate = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];
    $day_by_date = strtolower(date("l", strtotime($newDate)));

    $newtime='';
    if($time!=''){
    	$time_get1 = explode(" ",$time);
	    $time_get2 = explode(":",$time_get1[0]);
	    $newtime = $time_get2[0].':'.$time_get2[1];
    }

	// Modify the date it contains

	if($day!="" && $day_by_date!=$day){
		$date = new DateTime($newDate);
		$date->modify('next '.$day);
		$schedule_start_date = $date->format('Y-m-d');
	}
	else{
		$schedule_start_date = $newDate;
	}
	

    

	$event_schedule = new \App\EventSchedule;
	$event_schedule->schedule_class_id = $schedule_class_id;
	$event_schedule->schedule_type =$schedule_type;
	$event_schedule->day=$day;
	$event_schedule->start_date=$schedule_start_date;
	$event_schedule->start_time=$newtime;
	$event_schedule->status = 'active';
	$event_schedule->save();

	 
}

function editSession($request){
	$event_session_id = $request['one_to_one_class_id'];
	$teacher_id = $request['edit_teacher_name'];
	$start_date = $request['edit_seesion_date'];
	$start_time = $request['edit_session_time'];

	$dob_get = explode("/",$start_date);
    $new_start_date = $dob_get[2].'-'.$dob_get[1].'-'.$dob_get[0];
     

 
	$time_get1 = explode(" ",$start_time);
    $time_get2 = explode(":",$time_get1[0]);
    $new_start_time = $time_get2[0].':'.$time_get2[1];
     


	include(app_path().'/edu_api/CancelClass.php');
 	$access_key= config('constants.WIZIQ_SECRET_KEY');  
    $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
    $webServiceUrl= config('constants.WIZIQ_API_URL');


    //delete existing session
	$event_session = \App\EventSession::find($event_session_id);

	if($event_session->wiziq_class_id!=""){
		CancelClass($secretAcessKey,$access_key,$webServiceUrl,$event_session->wiziq_class_id);
	}

	$event_session->is_delete = '1';
	$event_session->save();

	$new_event_session = new \App\EventSession;
	$new_event_session->teacher_id = $teacher_id;
	$new_event_session->schedule_class_id = $event_session->schedule_class_id;
	$new_event_session->event_schedule_id = $event_session->event_schedule_id;
	$new_event_session->start_date=$new_start_date;
	$new_event_session->start_time=$new_start_time;
	$new_event_session->duration = $event_session->duration;
	$new_event_session->status = 'upcoming_proposed';
	$new_event_session->created_by = loggedInUser()->id;
	$new_event_session->is_edited = 1;
	$new_event_session->save();


	$data['from_email'] = config('constants.FROM_EMAIL');
    $data['from_name']  = config('constants.FROM_NAME');
    $data['attachment']  = '';
	$data['event_sessions'] = getSessionData($new_event_session->id);
	$data['old_event_sessions_date'] = $event_session->start_date;
	$data['old_event_sessions_time'] = $event_session->start_time;

    $class_schedule_students = \App\ClassStudentRequest::where('schedule_class_id',$new_event_session->schedule_class_id)->get();
    

    /************** student mail **********/
    foreach ($class_schedule_students as $key => $class_schedule_student) {
    	$student = $class_schedule_student->student;
    	if($student->parent_id){
	      $data['reciever_email']  = $student->parent->email;
	      $data['reciever_name']  = $student->parent->name;   
	      $data['student_name']  = $student->name; 
	      $student_parent_template_session_edit = 'email.event_session_edit_parent_email'; 
	    }
	    else{
	      $data['reciever_email']  = $student->email;
	      $data['reciever_name']  = $student->name;  
	      $student_parent_template_session_edit = 'email.event_session_edit_email';
	    }

	    $data['subject']  = 'JoinIvy - Your session has been revised'; 
	    sendMail($student_parent_template_session_edit,$data);
    }
    
    

    /********* teacher mail************/
    $data['reciever_email']  = $data['event_sessions']->user->email;
    $data['reciever_name']  = $data['event_sessions']->user->name;  
       
    $data['subject']  = 'JoinIvy - Your session has been edited';
    sendMail('email.event_session_edit_teacher_email',$data);


	 
}

function getFrequency(){
	// return ["0"=>'One Time',"1"=>'Daily(All 7 Days)',"2"=>'6 Days(Mon-Sat)',"3"=>'5 Days(Mon-Fri)',"4"=>'Weekly',"5"=>'Once every month'];
	return ["0"=>'One Time',"4"=>'Weekly'];
}

function deleteSchedules($schedule_class_id){
	// $event_schedule = \App\EventSchedule::where('schedule_class_id',$schedule_class_id)->first();
	// $event_schedule->is_delete = '1';
	// $event_schedule->save();

	\DB::table('event_schedules')->where('schedule_class_id',$schedule_class_id)->update(['is_delete' => '1']);

	 

 }

function hasBatchClassExpired($batch){
	$schedule = $batch->eventSchedule()->where('is_delete','0')->first();
	
	if(!empty($schedule)){
		if($schedule->schedule_type=='0' && isPastDate($schedule->start_date.' '.$schedule->start_time))
			return true;
		else
			return false;
	}
	else{
		return true;
	} 	 
	
		

}

 function deleteSessions($schedule_class_id,$startoftheweek,$endoftheweek=''){
	// $event_sessions = \App\EventSession::where('schedule_class_id',$schedule_class_id)->where('start_date','>=',$datefrom)->get();
	// $event_sessions->is_delete = '1';
	// $event_sessions->save();

	// \DB::table('event_sessions')->where('schedule_class_id',$schedule_class_id)->where('start_date','>=',$datefrom)->update(['is_delete' => '1']);
 	include(app_path().'/edu_api/CancelClass.php');
 	$access_key= config('constants.WIZIQ_SECRET_KEY');  
    $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
    $webServiceUrl= config('constants.WIZIQ_API_URL');

    if($endoftheweek == '')
 	   $event_sessions = \App\EventSession::where('schedule_class_id',$schedule_class_id)->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])->where('start_date','>=',$startoftheweek)->get();
 	else
 		$event_sessions = \App\EventSession::where('schedule_class_id',$schedule_class_id)->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])->where('start_date','>=',$startoftheweek)->where('start_date','<=',$endoftheweek)->get();


 	foreach ($event_sessions as $key => $event_session) {
 		
 		if($event_session->wiziq_class_id!=""){
 			CancelClass($secretAcessKey,$access_key,$webServiceUrl,$event_session->wiziq_class_id);
 		}

 		$event_session->is_delete = '1';
 		$event_session->save();
 	}

 	\DB::table('event_schedules')->where('schedule_class_id',$schedule_class_id)->update(['is_delete' => '1']);
 	 
 	
 }


 function deleteClass($class_id){
 	include(app_path().'/edu_api/CancelClass.php');
 	$access_key= config('constants.WIZIQ_SECRET_KEY');  
    $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
    $webServiceUrl= config('constants.WIZIQ_API_URL');

    $event_session = \App\EventSession::find($class_id);
    if($event_session->wiziq_class_id!=""){
		CancelClass($secretAcessKey,$access_key,$webServiceUrl,$event_session->wiziq_class_id);
	}

	$event_session->is_delete = '1';
	$event_session->save();


 }

  function cancelEventClass($class_id){
 	include(app_path().'/edu_api/CancelClass.php');
 	$access_key= config('constants.WIZIQ_SECRET_KEY');  
    $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
    $webServiceUrl= config('constants.WIZIQ_API_URL');

    $event_session = \App\EventSession::find($class_id);
    if($event_session->wiziq_class_id!=""){
		CancelClass($secretAcessKey,$access_key,$webServiceUrl,$event_session->wiziq_class_id);
	}

	$event_session->status = 'canceled';
	$event_session->save();
	 
	$schedule_type = $event_session->schedule_class->eventSchedule()->first()->schedule_type;
             
 
	if($schedule_type=='0'){
		\DB::table('event_schedules')->where('schedule_class_id',$event_session->schedule_class_id)->update(['is_delete' => '1']);
	}

	// send email
 	sendClassCancelationMail($event_session->schedule_class_id);


 }

 function sendClassCancelationMail($schedule_class_id){
 	$data = getScheduleSessionData($schedule_class_id);
 	$class_type = $data['event_sessions']->schedule_class->class_type;
    $data['from_email'] = config('constants.FROM_EMAIL');
    $data['from_name']  = config('constants.FROM_NAME');
    $data['attachment']  = '';

    if($class_type=='1'){
      $student = $data['event_sessions']->schedule_class->studentClassRequest->student;
      sendCancelationMailStudent($student,$data);
      
    }
    elseif($class_type=='3'){
      $all_students = $data['event_sessions']->schedule_class->studentClassRequestMany(); 
      foreach ($all_students as $key => $classstudent) {
        $student = User::find($classstudent->student_id);
        sendCancelationMailStudent($student,$data);
      }
      
    }

    sendCancelationMailTeacher($data);

 }

  function cancelSessions($event_class_id){
  	$event_session = \App\EventSession::find($event_class_id);
 //  	$startoftheweek = startOfTheWeekDate($event_session->start_date);
	// $endoftheweek = endOfTheWeekDate($startoftheweek);
 	$startoftheweek = $event_session->start_date;
	$endoftheweek = '';

 	include(app_path().'/edu_api/CancelClass.php');
 	$access_key= config('constants.WIZIQ_SECRET_KEY');  
    $secretAcessKey= config('constants.WIZIQ_ACCESS_KEY');
    $webServiceUrl= config('constants.WIZIQ_API_URL');

    if($endoftheweek == '')
 	   $event_sessions = \App\EventSession::where('schedule_class_id',$event_session->schedule_class_id)->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])->where('start_date','>=',$startoftheweek)->get();
 	else
 		$event_sessions = \App\EventSession::where('schedule_class_id',$event_session->schedule_class_id)->whereIn('event_sessions.status',['upcoming_proposed','upcoming_booked'])->where('start_date','>=',$startoftheweek)->where('start_date','<=',$endoftheweek)->get();


 	foreach ($event_sessions as $key => $event_session) {
 		
 		if($event_session->wiziq_class_id!=""){
 			CancelClass($secretAcessKey,$access_key,$webServiceUrl,$event_session->wiziq_class_id);
 		}

 		$event_session->status = 'canceled';
		$event_session->save();
 	}

 	\DB::table('event_schedules')->where('schedule_class_id',$event_session->schedule_class_id)->update(['is_delete' => '1']);

 	sendClassCancelationMail($event_session->schedule_class_id);
 }

 function sendCancelationMailStudent($student,$data){
 	if($student->parent_id){
      $data['reciever_email']  = $student->parent->email;
      $data['reciever_name']  = $student->parent->name;   
      $data['student_name']  = $student->name; 
      $student_parent_template_onetime = 'email.event_onetime_session_cancel_parent_edit_email';   
      $student_parent_template_recurring = 'email.event_recurring_session_cancel_parent_email'; 
    }
    else{
      $data['reciever_email']  = $student->email;
      $data['reciever_name']  = $student->name;  
      $student_parent_template_onetime = 'email.event_onetime_session_cancel_email';   
      $student_parent_template_recurring = 'email.event_recurring_session_cancel_email';  
    }

    if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
        $data['subject']  = 'JoinIvy - Weekly Session Canceled'; 
        sendMail($student_parent_template_recurring,$data);
    }
    elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){
         
        $data['subject']  = 'JoinIvy - One Time Session Canceled';
        sendMail($student_parent_template_onetime,$data);
    }
 }

  function sendCancelationMailTeacher($data){

  	$data['reciever_email']  = $data['event_sessions']->user->email;
  	$data['reciever_name']  = $data['event_sessions']->user->name;  

	if(isset($request['occurance_type']) && $request['occurance_type']=='4'){             
		$data['subject']  = 'JoinIvy - Weekly Session Canceled';
		sendMail('email.event_recurring_session_cancel_teacher_email',$data);
	}
	elseif(isset($request['occurance_type']) && $request['occurance_type']=='0'){             
		$data['subject']  = 'JoinIvy - One Time Session Canceled';
		sendMail('email.event_onetime_session_cancel_teacher_email.blade',$data);
	}

 }

 function deleteSchedulesfortheweek($request,$schedule_class_id,$startoftheweek,$endoftheweek){
 	//delete session
 	// \DB::table('event_sessions')->where('schedule_class_id',$schedule_class_id)->where('start_date','>=',$startoftheweek)->where('start_date','<=',$endoftheweek)->update(['is_delete' => '1']);
 	
	$day_by_date = strtolower(date("l", strtotime($startoftheweek)));

	
 	deleteSessions($schedule_class_id,$startoftheweek,$endoftheweek);


 	//create new entry
 	$days_of_week = $request['days_of_week']; 
	foreach ($days_of_week as  $day) {	 

		if($day!="" && $day_by_date!=$day){
			$date = new DateTime($startoftheweek);			 
			$date->modify('next '.$day);			 
			$schedule_start_date = $date->format('Y-m-d');
		}
		else{
			$schedule_start_date = $startoftheweek;
		}
 
		$event_session = new \App\EventSession;
		$event_session->teacher_id = $request['teacher_name'];
		$event_session->schedule_class_id = $schedule_class_id;
		$event_session->event_schedule_id = '0';
		$event_session->start_date=$schedule_start_date;
		$event_session->start_time=$request[$day.'_time'];
		$event_session->duration = $request['time_duration'];
		$event_session->status = 'upcoming_proposed';
		$event_session->save();
 
	}
 }


 function getEventSessionPaginatedData($requestData,$cond=[]){
 		$data =[];
        $skip = $requestData['start'];
        $length = $requestData['length'];
        $orderValue = $requestData['order'][0];

        $totalsessions = \App\EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')->where('schedule_class.class_type',1)
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.teacher_id', 'schedule_class.class_payment_type','class_students_request.creator_id')
            ->count();

        
         
        
        $class_list = \App\EventSession::join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')->where('schedule_class.class_type',1)
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.teacher_id', 'schedule_class.class_payment_type','class_students_request.creator_id')
            ->orderBy('event_sessions.start_date','asc')
            ->orderBy('event_sessions.start_time','asc')
            ->skip($skip)->take($length)->get();   
            
         

        $sessionData = [];
        $i = $skip+1;
        foreach ($class_list as $key => $class) {

            $edit = '<i style="color:#4CAF50;font-size:20px;cursor:pointer;" class="fas fa-edit ml-2" data-toggle="modal" data-target="#addRowModal" onclick="editOnetoOneSchedule(this)" data-id="'.$class->id.'"></i>';



          $view = '<i style="color:#007bff;font-size:20px;cursor:pointer;" class="fas fa-eye ml-2" data-toggle="modal" data-target="#addRowModal" onclick="veiwOnetoOneSchedule(this)" data-id="'.$class->id.'"></i>';

                                

          $delete = '<i style="color:#F44336;font-size:20px;cursor:pointer;" class="fas fa-trash-alt ml-2"  onclick="deleteOnetoOneclass(this)" data-id="'.$class->id.'" aria-hidden="true"></i>';

         
            $sessionData[] = [ 
                            'id' => $i,
                            'class_name' => $class->schedule_class->class->course_name,
                            'course_name' => $class->schedule_class->course->course_name,
                            'teacher' => $class->user->name,
                            'duration' => $class->duration,
                            'date_time' => date('d-m-Y', strtotime($class->start_date))  ." ". date('h:i a', strtotime($class->start_time)),
                            'creator' => $class->schedule_class->studentClassRequest->user->name,
                            'calss_payment_type' => ucfirst($class->class_payment_type),
                            'action' => $view.' '.$delete,
                            ];
            $i++;
        }

        $json_data = array(
                "draw"            => intval( $requestData['draw'] ),
                "recordsTotal"    => intval( $totalsessions ),
                "recordsFiltered" => intval( $totalsessions ),
                "data"            => $sessionData,
            );

       	return $json_data;
 }

 function wizIQClassStatusPingURL(){
 	return url('/wiziq/classstatus');
 }

 function getScheduleSessionData($schedule_class_id){
 	$event_sessions =  \App\EventSession::where('event_sessions.schedule_class_id',$schedule_class_id)
            ->join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            // ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type','schedule_class.class_type') //,'class_students_request.creator_id','class_students_request.student_id','class_students_request.session_start_date'
            ->first(); 
	$event_schedule =  \App\EventSchedule::where('schedule_class_id',$schedule_class_id)->where('is_delete','0')->get(); //

	return ['event_sessions'=>$event_sessions,'event_schedule'=>$event_schedule];
 }

  function getSessionData($session_id){
 	$event_sessions =  \App\EventSession::where('event_sessions.id',$session_id)
            ->join('schedule_class', 'schedule_class.id', '=', 'event_sessions.schedule_class_id') 
            ->join('class_students_request', 'class_students_request.schedule_class_id', '=', 'schedule_class.id') 
            ->where('schedule_class.is_delete','0')
            ->where('event_sessions.is_delete','0')
            ->select('event_sessions.*', 'schedule_class.course_id','schedule_class.class_name', 'schedule_class.class_payment_type','schedule_class.class_type','class_students_request.creator_id','class_students_request.student_id','class_students_request.session_start_date')
            ->first(); 
	 

	return $event_sessions;
 }


function sendMail($template,$data){
	$data['bcc_email'] = config('constants.ADMIN_EMAIL');
 	\Mail::send($template, ['data'=>$data], function($message)use($data)
    {  
        $message->from($data['from_email'], $data['from_name']);
        $message->to($data['reciever_email'], $data['reciever_name'])->bcc($data['bcc_email'])->subject($data['subject']); //
        if($data['attachment']!='')
        	$message->attach($data['attachment']);
    }); 
 }

function is_develop(){
 	if(config('constants.APP_ENV')!="local")
 		return false;
 	else
 		return true;

}

// function debitLessonCredits($session){

// 	$seconds = ($session->duration * 3600);
// 	$lessonCredits = new LessonCredit();
//     $lessonCredits->user_id = ;
//     $lessonCredits->object_type = 'App\EventSession';
//     $lessonCredits->object_id = $session->id;
//     $lessonCredits->seconds = $seconds;
//     $lessonCredits->class_id = $session->schedule_class->class_name;
//     $lessonCredits->status = 'debited';
//     $lessonCredits->save();
// } 

function canLaunchClass($student_id,$class_id,$duration){
	$total_seconds_credited = \App\LessonCredit::where('user_id',$student_id)->where('class_id',$class_id)->where('status','credited')->sum('seconds');
	$total_seconds_debited = \App\LessonCredit::where('user_id',$student_id)->where('class_id',$class_id)->where('status','debited')->sum('seconds');
	$total_remaining_seconds = intval($total_seconds_credited) - intval($total_seconds_debited);


	$total_remaining_hours = ($total_remaining_seconds/3600);
	$total_remaining_minutes = ($total_remaining_seconds/60); 
	$total_sessions_remaining = 0;
	if($duration > 0 && $total_remaining_minutes >= $duration ){
		$total_sessions_remaining = $total_remaining_minutes/$duration;
		$launch =  true;
	}
	else{
		$launch = false;
	}

	return ['can_launch'=>$launch,'total_sessions_remaining' => $total_sessions_remaining,'total_remaining_hours' => $total_remaining_hours];
}



 function getCoursefees($course,$duration,$class_mode){
 	$feepersession= 0;
 	if($class_mode == '1'){ //one to one
 		if($duration=='30'){
 			$feepersession= $course->one_to_one_60_price/2; 
 		}
 		elseif($duration=='60'){
 			$feepersession= $course->one_to_one_60_price; 
 		}
 		elseif($duration=='90'){
 			$feepersession= $course->one_to_one_90_price;
 		}
 		elseif($duration=='120'){
 			$feepersession= $course->one_to_one_120_price;
 		}
 	}
 	elseif($class_mode == '2'){ //buddy
 		if($duration=='30'){
 			$feepersession= $course->buddy_60_price/2; 
 		}
 		elseif($duration=='60'){
 			$feepersession= $course->buddy_60_price;
 		}
 		elseif($duration=='90'){
 			$feepersession= $course->buddy_90_price;
 		}
 		elseif($duration=='120'){
 			$feepersession= $course->buddy_120_price;
 		}
 	}
 	elseif($class_mode == '3'){ //batch
 		if($duration=='30'){
 			$feepersession= $course->batch_60_price/2; 
 		}
 		elseif($duration=='60'){
 			$feepersession= $course->batch_60_price;
 		}
 		elseif($duration=='90'){
 			$feepersession= $course->batch_90_price;
 		}
 		elseif($duration=='120'){
 			$feepersession= $course->batch_120_price;
 		}
 	}

 	return $feepersession;
 }

function update_user_referal($request,$role){
	
}

 function countryList(){

 	$counties = [
                  "Afghanistan"=>"Afghanistan",
                  "Åland Islands"=>"Åland Islands",
                  "Albania"=>"Albania",
                  "Algeria"=>"Algeria",
                  "American Samoa"=>"American Samoa",
                  "Andorra"=>"Andorra",
                  "Angola"=>"Angola",
                  "Anguilla"=>"Anguilla",
                  "Antarctica"=>"Antarctica",
                  "Antigua and Barbuda"=>"Antigua and Barbuda",
                  "Argentina"=>"Argentina",
                  "Armenia"=>"Armenia",
                  "Aruba"=>"Aruba",
                  "Australia"=>"Australia",
                  "Austria"=>"Austria",
                  "Azerbaijan"=>"Azerbaijan",
                  "Bahamas"=>"Bahamas",
                  "Bahrain"=>"Bahrain",
                  "Bangladesh"=>"Bangladesh",
                  "Barbados"=>"Barbados",
                  "Belarus"=>"Belarus",
                  "Belgium"=>"Belgium",
                  "Belize"=>"Belize",
                  "Benin"=>"Benin",
                  "Bermuda"=>"Bermuda",
                  "Bhutan"=>"Bhutan",
                  "Bolivia"=>"Bolivia",
                  "Bosnia and Herzegovina"=>"Bosnia and Herzegovina",
                  "Botswana"=>"Botswana",
                  "Bouvet Island"=>"Bouvet Island",
                  "Brazil"=>"Brazil",
                  "British Indian Ocean Territory"=>"British Indian Ocean Territory",
                  "Brunei Darussalam"=>"Brunei Darussalam",
                  "Bulgaria"=>"Bulgaria",
                  "Burkina Faso"=>"Burkina Faso",
                  "Burundi"=>"Burundi",
                  "Cambodia"=>"Cambodia",
                  "Cameroon"=>"Cameroon",
                  "Canada"=>"Canada",
                  "Cape Verde"=>"Cape Verde",
                  "Cayman Islands"=>"Cayman Islands",
                  "Central African Republic"=>"Central African Republic",
                  "Chad"=>"Chad",
                  "Chile"=>"Chile",
                  "China"=>"China",
                  "Christmas Island"=>"Christmas Island",
                  "Cocos (Keeling) Islands"=>"Cocos (Keeling) Islands",
                  "Colombia"=>"Colombia",
                  "Comoros"=>"Comoros",
                  "Congo"=>"Congo",
                  "Congo, The Democratic Republic of The"=>"Congo, The Democratic Republic of The",
                  "Cook Islands"=>"Cook Islands",
                  "Costa Rica"=>"Costa Rica",
                  "Cote D'ivoire"=>"Cote D'ivoire",
                  "Croatia"=>"Croatia",
                  "Cuba"=>"Cuba",
                  "Cyprus"=>"Cyprus",
                  "Czech Republic"=>"Czech Republic",
                  "Denmark"=>"Denmark",
                  "Djibouti"=>"Djibouti",
                  "Dominica"=>"Dominica",
                  "Dominican Republic"=>"Dominican Republic",
                  "Ecuador"=>"Ecuador",
                  "Egypt"=>"Egypt",
                  "El Salvador"=>"El Salvador",
                  "Equatorial Guinea"=>"Equatorial Guinea",
                  "Eritrea"=>"Eritrea",
                  "Estonia"=>"Estonia",
                  "Ethiopia"=>"Ethiopia",
                  "Falkland Islands (Malvinas)"=>"Falkland Islands (Malvinas)",
                  "Faroe Islands"=>"Faroe Islands",
                  "Fiji"=>"Fiji",
                  "Finland"=>"Finland",
                  "France"=>"France",
                  "French Guiana"=>"French Guiana",
                  "French Polynesia"=>"French Polynesia",
                  "French Southern Territories"=>"French Southern Territories",
                  "Gabon"=>"Gabon",
                  "Gambia"=>"Gambia",
                  "Georgia"=>"Georgia",
                  "Germany"=>"Germany",
                  "Ghana"=>"Ghana",
                  "Gibraltar"=>"Gibraltar",
                  "Greece"=>"Greece",
                  "Greenland"=>"Greenland",
                  "Grenada"=>"Grenada",
                  "Guadeloupe"=>"Guadeloupe",
                  "Guam"=>"Guam",
                  "Guatemala"=>"Guatemala",
                  "Guernsey"=>"Guernsey",
                  "Guinea"=>"Guinea",
                  "Guinea-bissau"=>"Guinea-bissau",
                  "Guyana"=>"Guyana",
                  "Haiti"=>"Haiti",
                  "Heard Island and Mcdonald Islands"=>"Heard Island and Mcdonald Islands",
                  "Holy See (Vatican City State)"=>"Holy See (Vatican City State)",
                  "Honduras"=>"Honduras",
                  "Hong Kong"=>"Hong Kong",
                  "Hungary"=>"Hungary",
                  "Iceland"=>"Iceland",
                  "India"=>"India",
                  "Indonesia"=>"Indonesia",
                  "Iran, Islamic Republic of"=>"Iran, Islamic Republic of",
                  "Iraq"=>"Iraq",
                  "Ireland"=>"Ireland",
                  "Isle of Man"=>"Isle of Man",
                  "Israel"=>"Israel",
                  "Italy"=>"Italy",
                  "Jamaica"=>"Jamaica",
                  "Japan"=>"Japan",
                  "Jersey"=>"Jersey",
                  "Jordan"=>"Jordan",
                  "Kazakhstan"=>"Kazakhstan",
                  "Kenya"=>"Kenya",
                  "Kiribati"=>"Kiribati",
                  "Korea, Democratic People's Republic of"=>"Korea, Democratic People's Republic of",
                  "Korea, Republic of"=>"Korea, Republic of",
                  "Kuwait"=>"Kuwait",
                  "Kyrgyzstan"=>"Kyrgyzstan",
                  "Lao People's Democratic Republic"=>"Lao People's Democratic Republic",
                  "Latvia"=>"Latvia",
                  "Lebanon"=>"Lebanon",
                  "Lesotho"=>"Lesotho",
                  "Liberia"=>"Liberia",
                  "Libyan Arab Jamahiriya"=>"Libyan Arab Jamahiriya",
                  "Liechtenstein"=>"Liechtenstein",
                  "Lithuania"=>"Lithuania",
                  "Luxembourg"=>"Luxembourg",
                  "Macao"=>"Macao",
                  "Macedonia, The Former Yugoslav Republic of"=>"Macedonia, The Former Yugoslav Republic of",
                  "Madagascar"=>"Madagascar",
                  "Malawi"=>"Malawi",
                  "Malaysia"=>"Malaysia",
                  "Maldives"=>"Maldives",
                  "Mali"=>"Mali",
                  "Malta"=>"Malta",
                  "Marshall Islands"=>"Marshall Islands",
                  "Martinique"=>"Martinique",
                  "Mauritania"=>"Mauritania",
                  "Mauritius"=>"Mauritius",
                  "Mayotte"=>"Mayotte",
                  "Mexico"=>"Mexico",
                  "Micronesia, Federated States of"=>"Micronesia, Federated States of",
                  "Moldova, Republic of"=>"Moldova, Republic of",
                  "Monaco"=>"Monaco",
                  "Mongolia"=>"Mongolia",
                  "Montenegro"=>"Montenegro",
                  "Montserrat"=>"Montserrat",
                  "Morocco"=>"Morocco",
                  "Mozambique"=>"Mozambique",
                  "Myanmar"=>"Myanmar",
                  "Namibia"=>"Namibia",
                  "Nauru"=>"Nauru",
                  "Nepal"=>"Nepal",
                  "Netherlands"=>"Netherlands",
                  "Netherlands Antilles"=>"Netherlands Antilles",
                  "New Caledonia"=>"New Caledonia",
                  "New Zealand"=>"New Zealand",
                  "Nicaragua"=>"Nicaragua",
                  "Niger"=>"Niger",
                  "Nigeria"=>"Nigeria",
                  "Niue"=>"Niue",
                  "Norfolk Island"=>"Norfolk Island",
                  "Northern Mariana Islands"=>"Northern Mariana Islands",
                  "Norway"=>"Norway",
                  "Oman"=>"Oman",
                  "Pakistan"=>"Pakistan",
                  "Palau"=>"Palau",
                  "Palestinian Territory, Occupied"=>"Palestinian Territory, Occupied",
                  "Panama"=>"Panama",
                  "Papua New Guinea"=>"Papua New Guinea",
                  "Paraguay"=>"Paraguay",
                  "Peru"=>"Peru",
                  "Philippines"=>"Philippines",
                  "Pitcairn"=>"Pitcairn",
                  "Poland"=>"Poland",
                  "Portugal"=>"Portugal",
                  "Puerto Rico"=>"Puerto Rico",
                  "Qatar"=>"Qatar",
                  "Reunion"=>"Reunion",
                  "Romania"=>"Romania",
                  "Russian Federation"=>"Russian Federation",
                  "Rwanda"=>"Rwanda",
                  "Saint Helena"=>"Saint Helena",
                  "Saint Kitts and Nevis"=>"Saint Kitts and Nevis",
                  "Saint Lucia"=>"Saint Lucia",
                  "Saint Pierre and Miquelon"=>"Saint Pierre and Miquelon",
                  "Saint Vincent and The Grenadines"=>"Saint Vincent and The Grenadines",
                  "Samoa"=>"Samoa",
                  "San Marino"=>"San Marino",
                  "Sao Tome and Principe"=>"Sao Tome and Principe",
                  "Saudi Arabia"=>"Saudi Arabia",
                  "Senegal"=>"Senegal",
                  "Serbia"=>"Serbia",
                  "Seychelles"=>"Seychelles",
                  "Sierra Leone"=>"Sierra Leone",
                  "Singapore"=>"Singapore",
                  "Slovakia"=>"Slovakia",
                  "Slovenia"=>"Slovenia",
                  "Solomon Islands"=>"Solomon Islands",
                  "Somalia"=>"Somalia",
                  "South Africa"=>"South Africa",
                  "South Georgia and The South Sandwich Islands"=>"South Georgia and The South Sandwich Islands",
                  "Spain"=>"Spain",
                  "Sri Lanka"=>"Sri Lanka",
                  "Sudan"=>"Sudan",
                  "Suriname"=>"Suriname",
                  "Svalbard and Jan Mayen"=>"Svalbard and Jan Mayen",
                  "Swaziland"=>"Swaziland",
                  "Sweden"=>"Sweden",
                  "Switzerland"=>"Switzerland",
                  "Syrian Arab Republic"=>"Syrian Arab Republic",
                  "Taiwan, Province of China"=>"Taiwan, Province of China",
                  "Tajikistan"=>"Tajikistan",
                  "Tanzania, United Republic of"=>"Tanzania, United Republic of",
                  "Thailand"=>"Thailand",
                  "Timor-leste"=>"Timor-leste",
                  "Togo"=>"Togo",
                  "Tokelau"=>"Tokelau",
                  "Tonga"=>"Tonga",
                  "Trinidad and Tobago"=>"Trinidad and Tobago",
                  "Tunisia"=>"Tunisia",
                  "Turkey"=>"Turkey",
                  "Turkmenistan"=>"Turkmenistan",
                  "Turks and Caicos Islands"=>"Turks and Caicos Islands",
                  "Tuvalu"=>"Tuvalu",
                  "Uganda"=>"Uganda",
                  "Ukraine"=>"Ukraine",
                  "United Arab Emirates"=>"United Arab Emirates",
                  "United Kingdom"=>"United Kingdom",
                  "United States"=>"United States",
                  "United States Minor Outlying Islands"=>"United States Minor Outlying Islands",
                  "Uruguay"=>"Uruguay",
                  "Uzbekistan"=>"Uzbekistan",
                  "Vanuatu"=>"Vanuatu",
                  "Venezuela"=>"Venezuela",
                  "Viet Nam"=>"Viet Nam",
                  "Virgin Islands, British"=>"Virgin Islands, British",
                  "Virgin Islands, U.S."=>"Virgin Islands, U.S.",
                  "Wallis and Futuna"=>"Wallis and Futuna",
                  "Western Sahara"=>"Western Sahara",
                  "Yemen"=>"Yemen",
                  "Zambia"=>"Zambia",
                  "Zimbabwe"=>"Zimbabwe"];

        return $counties;
                        
 }

 function countryCode(){
 	$country_code = [
 						['country_code'=>"GB", 'calling_code'=>"+44" ,'label'=>'UK (+44)'],
						['country_code'=>"US", 'calling_code'=>"+1" ,'label'=>' USA (+1)'],
						['country_code'=>"DZ", 'calling_code'=>"+213" ,'label'=>'Algeria (+213)'],
						['country_code'=>"AD", 'calling_code'=>"+376" ,'label'=>'Andorra (+376)'],
						['country_code'=>"AO", 'calling_code'=>"+244" ,'label'=>'Angola (+244)'],
						['country_code'=>"AI", 'calling_code'=>"+1264" ,'label'=>'Anguilla (+1264)'],
						['country_code'=>"AG", 'calling_code'=>"+1268" ,'label'=>'Antigua &amp; Barbuda (+1268)'],
						['country_code'=>"AR", 'calling_code'=>"+54" ,'label'=>'Argentina (+54)'],
						['country_code'=>"AM", 'calling_code'=>"+374" ,'label'=>'Armenia (+374)'],
						['country_code'=>"AW", 'calling_code'=>"+297" ,'label'=>'Aruba (+297)'],
						['country_code'=>"AU", 'calling_code'=>"+61" ,'label'=>'Australia (+61)'],
						['country_code'=>"AT", 'calling_code'=>"+43" ,'label'=>'Austria (+43)'],
						['country_code'=>"AZ", 'calling_code'=>"+994" ,'label'=>'Azerbaijan (+994)'],
						['country_code'=>"BS", 'calling_code'=>"+1242" ,'label'=>'Bahamas (+1242)'],
						['country_code'=>"BH", 'calling_code'=>"+973" ,'label'=>'Bahrain (+973)'],
						['country_code'=>"BD", 'calling_code'=>"+880" ,'label'=>'Bangladesh (+880)'],
						['country_code'=>"BB", 'calling_code'=>"+1246" ,'label'=>'Barbados (+1246)'],
						['country_code'=>"BY", 'calling_code'=>"+375" ,'label'=>'Belarus (+375)'],
						['country_code'=>"BE", 'calling_code'=>"+32" ,'label'=>'Belgium (+32)'],
						['country_code'=>"BZ", 'calling_code'=>"+501" ,'label'=>'Belize (+501)'],
						['country_code'=>"BJ", 'calling_code'=>"+229" ,'label'=>'Benin (+229)'],
						['country_code'=>"BM", 'calling_code'=>"+1441" ,'label'=>'Bermuda (+1441)'],
						['country_code'=>"BT", 'calling_code'=>"+975" ,'label'=>'Bhutan (+975)'],
						['country_code'=>"BO", 'calling_code'=>"+591" ,'label'=>'Bolivia (+591)'],
						['country_code'=>"BA", 'calling_code'=>"+387" ,'label'=>'Bosnia Herzegovina (+387)'],
						['country_code'=>"BW", 'calling_code'=>"+267" ,'label'=>'Botswana (+267)'],
						['country_code'=>"BR", 'calling_code'=>"+55" ,'label'=>'Brazil (+55)'],
						['country_code'=>"BN", 'calling_code'=>"+673" ,'label'=>'Brunei (+673)'],
						['country_code'=>"BG", 'calling_code'=>"+359" ,'label'=>'Bulgaria (+359)'],
						['country_code'=>"BF", 'calling_code'=>"+226" ,'label'=>'Burkina Faso (+226)'],
						['country_code'=>"BI", 'calling_code'=>"+257" ,'label'=>'Burundi (+257)'],
						['country_code'=>"KH", 'calling_code'=>"+855" ,'label'=>'Cambodia (+855)'],
						['country_code'=>"CM", 'calling_code'=>"+237" ,'label'=>'Cameroon (+237)'],
						['country_code'=>"CA", 'calling_code'=>"+1" ,'label'=>' Canada (+1)'],
						['country_code'=>"CV", 'calling_code'=>"+238" ,'label'=>'Cape Verde Islands (+238)'],
						['country_code'=>"KY", 'calling_code'=>"+1345" ,'label'=>'Cayman Islands (+1345)'],
						['country_code'=>"CF", 'calling_code'=>"+236" ,'label'=>'Central African Republic (+236)'],
						['country_code'=>"CL", 'calling_code'=>"+56" ,'label'=>'Chile (+56)'],
						['country_code'=>"CN", 'calling_code'=>"+86" ,'label'=>'China (+86)'],
						['country_code'=>"CO", 'calling_code'=>"+57" ,'label'=>'Colombia (+57)'],
						['country_code'=>"KM", 'calling_code'=>"+269" ,'label'=>'Comoros (+269)'],
						['country_code'=>"CG", 'calling_code'=>"+242" ,'label'=>'Congo (+242)'],
						['country_code'=>"CK", 'calling_code'=>"+682" ,'label'=>'Cook Islands (+682)'],
						['country_code'=>"CR", 'calling_code'=>"+506" ,'label'=>'Costa Rica (+506)'],
						['country_code'=>"HR", 'calling_code'=>"+385" ,'label'=>'Croatia (+385)'],
						['country_code'=>"CU", 'calling_code'=>"+53" ,'label'=>'Cuba (+53)'],
						['country_code'=>"CY", 'calling_code'=>"+90392" ,'label'=>'Cyprus North (+90392)'],
						['country_code'=>"CY", 'calling_code'=>"+357" ,'label'=>'Cyprus South (+357)'],
						['country_code'=>"CZ", 'calling_code'=>"+42" ,'label'=>'Czech Republic (+42)'],
						['country_code'=>"DK", 'calling_code'=>"+45" ,'label'=>'Denmark (+45)'],
						['country_code'=>"DJ", 'calling_code'=>"+253" ,'label'=>'Djibouti (+253)'], 
						['country_code'=>"DO", 'calling_code'=>"+1809" ,'label'=>'Dominican Republic (+1809)'],
						['country_code'=>"EC", 'calling_code'=>"+593" ,'label'=>'Ecuador (+593)'],
						['country_code'=>"EG", 'calling_code'=>"+20" ,'label'=>'Egypt (+20)'],
						['country_code'=>"SV", 'calling_code'=>"+503" ,'label'=>'El Salvador (+503)'],
						['country_code'=>"GQ", 'calling_code'=>"+240" ,'label'=>'Equatorial Guinea (+240)'],
						['country_code'=>"ER", 'calling_code'=>"+291" ,'label'=>'Eritrea (+291)'],
						['country_code'=>"EE", 'calling_code'=>"+372" ,'label'=>'Estonia (+372)'],
						['country_code'=>"ET", 'calling_code'=>"+251" ,'label'=>'Ethiopia (+251)'],
						['country_code'=>"FK", 'calling_code'=>"+500" ,'label'=>'Falkland Islands (+500)'],
						['country_code'=>"FO", 'calling_code'=>"+298" ,'label'=>'Faroe Islands (+298)'],
						['country_code'=>"FJ", 'calling_code'=>"+679" ,'label'=>'Fiji (+679)'],
						['country_code'=>"FI", 'calling_code'=>"+358" ,'label'=>'Finland (+358)'],
						['country_code'=>"FR", 'calling_code'=>"+33" ,'label'=>'France (+33)'],
						['country_code'=>"GF", 'calling_code'=>"+594" ,'label'=>'French Guiana (+594)'],
						['country_code'=>"PF", 'calling_code'=>"+689" ,'label'=>'French Polynesia (+689)'],
						['country_code'=>"GA", 'calling_code'=>"+241" ,'label'=>'Gabon (+241)'],
						['country_code'=>"GM", 'calling_code'=>"+220" ,'label'=>'Gambia (+220)'],
						['country_code'=>"GE", 'calling_code'=>"+7880" ,'label'=>'Georgia (+7880)'],
						['country_code'=>"DE", 'calling_code'=>"+49" ,'label'=>'Germany (+49)'],
						['country_code'=>"GH", 'calling_code'=>"+233" ,'label'=>'Ghana (+233)'],
						['country_code'=>"GI", 'calling_code'=>"+350" ,'label'=>'Gibraltar (+350)'],
						['country_code'=>"GR", 'calling_code'=>"+30" ,'label'=>'Greece (+30)'],
						['country_code'=>"GL", 'calling_code'=>"+299" ,'label'=>'Greenland (+299)'],
						['country_code'=>"GD", 'calling_code'=>"+1473" ,'label'=>'Grenada (+1473)'],
						['country_code'=>"GP", 'calling_code'=>"+590" ,'label'=>'Guadeloupe (+590)'],
						['country_code'=>"GU", 'calling_code'=>"+671" ,'label'=>'Guam (+671)'],
						['country_code'=>"GT", 'calling_code'=>"+502" ,'label'=>'Guatemala (+502)'],
						['country_code'=>"GN", 'calling_code'=>"+224" ,'label'=>'Guinea (+224)'],
						['country_code'=>"GW", 'calling_code'=>"+245" ,'label'=>'Guinea - Bissau (+245)'],
						['country_code'=>"GY", 'calling_code'=>"+592" ,'label'=>'Guyana (+592)'],
						['country_code'=>"HT", 'calling_code'=>"+509" ,'label'=>'Haiti (+509)'],
						['country_code'=>"HN", 'calling_code'=>"+504" ,'label'=>'Honduras (+504)'],
						['country_code'=>"HK", 'calling_code'=>"+852" ,'label'=>'Hong Kong (+852)'],
						['country_code'=>"HU", 'calling_code'=>"+36" ,'label'=>'Hungary (+36)'],
						['country_code'=>"IS", 'calling_code'=>"+354" ,'label'=>'Iceland (+354)'],
						['country_code'=>"IN", 'calling_code'=>"+91" ,'label'=>'India (+91)'],
						['country_code'=>"ID", 'calling_code'=>"+62" ,'label'=>'Indonesia (+62)'],
						['country_code'=>"IR", 'calling_code'=>"+98" ,'label'=>'Iran (+98)'],
						['country_code'=>"IQ", 'calling_code'=>"+964" ,'label'=>'Iraq (+964)'],
						['country_code'=>"IE", 'calling_code'=>"+353" ,'label'=>'Ireland (+353)'],
						['country_code'=>"IL", 'calling_code'=>"+972" ,'label'=>'Israel (+972)'],
						['country_code'=>"IT", 'calling_code'=>"+39" ,'label'=>'Italy (+39)'],
						['country_code'=>"JM", 'calling_code'=>"+1876" ,'label'=>'Jamaica (+1876)'],
						['country_code'=>"JP", 'calling_code'=>"+81" ,'label'=>'Japan (+81)'],
						['country_code'=>"JO", 'calling_code'=>"+962" ,'label'=>'Jordan (+962)'],
						['country_code'=>"KZ", 'calling_code'=>"+7" ,'label'=>' Kazakhstan (+7)'],
						['country_code'=>"KE", 'calling_code'=>"+254" ,'label'=>'Kenya (+254)'],
						['country_code'=>"KI", 'calling_code'=>"+686" ,'label'=>'Kiribati (+686)'],
						['country_code'=>"KP", 'calling_code'=>"+850" ,'label'=>'Korea North (+850)'],
						['country_code'=>"KR", 'calling_code'=>"+82" ,'label'=>'Korea South (+82)'],
						['country_code'=>"KW", 'calling_code'=>"+965" ,'label'=>'Kuwait (+965)'],
						['country_code'=>"KG", 'calling_code'=>"+996" ,'label'=>'Kyrgyzstan (+996)'],
						['country_code'=>"LA", 'calling_code'=>"+856" ,'label'=>'Laos (+856)'],
						['country_code'=>"LV", 'calling_code'=>"+371" ,'label'=>'Latvia (+371)'],
						['country_code'=>"LB", 'calling_code'=>"+961" ,'label'=>'Lebanon (+961)'],
						['country_code'=>"LS", 'calling_code'=>"+266" ,'label'=>'Lesotho (+266)'],
						['country_code'=>"LR", 'calling_code'=>"+231" ,'label'=>'Liberia (+231)'],
						['country_code'=>"LY", 'calling_code'=>"+218" ,'label'=>'Libya (+218)'],
						['country_code'=>"LI", 'calling_code'=>"+417" ,'label'=>'Liechtenstein (+417)'],
						['country_code'=>"LT", 'calling_code'=>"+370" ,'label'=>'Lithuania (+370)'],
						['country_code'=>"LU", 'calling_code'=>"+352" ,'label'=>'Luxembourg (+352)'],
						['country_code'=>"MO", 'calling_code'=>"+853" ,'label'=>'Macao (+853)'],
						['country_code'=>"MK", 'calling_code'=>"+389" ,'label'=>'Macedonia (+389)'],
						['country_code'=>"MG", 'calling_code'=>"+261" ,'label'=>'Madagascar (+261)'],
						['country_code'=>"MW", 'calling_code'=>"+265" ,'label'=>'Malawi (+265)'],
						['country_code'=>"MY", 'calling_code'=>"+60" ,'label'=>'Malaysia (+60)'],
						['country_code'=>"MV", 'calling_code'=>"+960" ,'label'=>'Maldives (+960)'],
						['country_code'=>"ML", 'calling_code'=>"+223" ,'label'=>'Mali (+223)'],
						['country_code'=>"MT", 'calling_code'=>"+356" ,'label'=>'Malta (+356)'],
						['country_code'=>"MH", 'calling_code'=>"+692" ,'label'=>'Marshall Islands (+692)'],
						['country_code'=>"MQ", 'calling_code'=>"+596" ,'label'=>'Martinique (+596)'],
						['country_code'=>"MR", 'calling_code'=>"+222" ,'label'=>'Mauritania (+222)'],
						['country_code'=>"YT", 'calling_code'=>"+269" ,'label'=>'Mayotte (+269)'],
						['country_code'=>"MX", 'calling_code'=>"+52" ,'label'=>'Mexico (+52)'],
						['country_code'=>"FM", 'calling_code'=>"+691" ,'label'=>'Micronesia (+691)'],
						['country_code'=>"MD", 'calling_code'=>"+373" ,'label'=>'Moldova (+373)'],
						['country_code'=>"MC", 'calling_code'=>"+377" ,'label'=>'Monaco (+377)'],
						['country_code'=>"MN", 'calling_code'=>"+976" ,'label'=>'Mongolia (+976)'],
						['country_code'=>"MS", 'calling_code'=>"+1664" ,'label'=>'Montserrat (+1664)'],
						['country_code'=>"MA", 'calling_code'=>"+212" ,'label'=>'Morocco (+212)'],
						['country_code'=>"MZ", 'calling_code'=>"+258" ,'label'=>'Mozambique (+258)'],
						['country_code'=>"MN", 'calling_code'=>"+95" ,'label'=>'Myanmar (+95)'],
						['country_code'=>"NA", 'calling_code'=>"+264" ,'label'=>'Namibia (+264)'],
						['country_code'=>"NR", 'calling_code'=>"+674" ,'label'=>'Nauru (+674)'],
						['country_code'=>"NP", 'calling_code'=>"+977" ,'label'=>'Nepal (+977)'],
						['country_code'=>"NL", 'calling_code'=>"+31" ,'label'=>'Netherlands (+31)'],
						['country_code'=>"NC", 'calling_code'=>"+687" ,'label'=>'New Caledonia (+687)'],
						['country_code'=>"NZ", 'calling_code'=>"+64" ,'label'=>'New Zealand (+64)'],
						['country_code'=>"NI", 'calling_code'=>"+505" ,'label'=>'Nicaragua (+505)'],
						['country_code'=>"NE", 'calling_code'=>"+227" ,'label'=>'Niger (+227)'],
						['country_code'=>"NG", 'calling_code'=>"+234" ,'label'=>'Nigeria (+234)'],
						['country_code'=>"NU", 'calling_code'=>"+683" ,'label'=>'Niue (+683)'],
						['country_code'=>"NF", 'calling_code'=>"+672" ,'label'=>'Norfolk Islands (+672)'],
						['country_code'=>"NP", 'calling_code'=>"+670" ,'label'=>'Northern Marianas (+670)'],
						['country_code'=>"NO", 'calling_code'=>"+47" ,'label'=>'Norway (+47)'],
						['country_code'=>"OM", 'calling_code'=>"+968" ,'label'=>'Oman (+968)'],
						['country_code'=>"PW", 'calling_code'=>"+680" ,'label'=>'Palau (+680)'],
						['country_code'=>"PA", 'calling_code'=>"+507" ,'label'=>'Panama (+507)'],
						['country_code'=>"PG", 'calling_code'=>"+675" ,'label'=>'Papua New Guinea (+675)'],
						['country_code'=>"PY", 'calling_code'=>"+595" ,'label'=>'Paraguay (+595)'],
						['country_code'=>"PE", 'calling_code'=>"+51" ,'label'=>'Peru (+51)'],
						['country_code'=>"PH", 'calling_code'=>"+63" ,'label'=>'Philippines (+63)'],
						['country_code'=>"PL", 'calling_code'=>"+48" ,'label'=>'Poland (+48)'],
						['country_code'=>"PT", 'calling_code'=>"+351" ,'label'=>'Portugal (+351)'],
						['country_code'=>"PR", 'calling_code'=>"+1787" ,'label'=>'Puerto Rico (+1787)'],
						['country_code'=>"QA", 'calling_code'=>"+974" ,'label'=>'Qatar (+974)'],
						['country_code'=>"RE", 'calling_code'=>"+262" ,'label'=>'Reunion (+262)'],
						['country_code'=>"RO", 'calling_code'=>"+40" ,'label'=>'Romania (+40)'],
						['country_code'=>"RU", 'calling_code'=>"+7" ,'label'=>' Russia (+7)'],
						['country_code'=>"RW", 'calling_code'=>"+250" ,'label'=>'Rwanda (+250)'],
						['country_code'=>"SM", 'calling_code'=>"+378" ,'label'=>'San Marino (+378)'],
						['country_code'=>"ST", 'calling_code'=>"+239" ,'label'=>'Sao Tome &amp; Principe (+239)'],
						['country_code'=>"SA", 'calling_code'=>"+966" ,'label'=>'Saudi Arabia (+966)'],
						['country_code'=>"SN", 'calling_code'=>"+221" ,'label'=>'Senegal (+221)'],
						['country_code'=>"CS", 'calling_code'=>"+381" ,'label'=>'Serbia (+381)'],
						['country_code'=>"SC", 'calling_code'=>"+248" ,'label'=>'Seychelles (+248)'],
						['country_code'=>"SL", 'calling_code'=>"+232" ,'label'=>'Sierra Leone (+232)'],
						['country_code'=>"SG", 'calling_code'=>"+65" ,'label'=>'Singapore (+65)'],
						['country_code'=>"SK", 'calling_code'=>"+421" ,'label'=>'Slovak Republic (+421)'],
						['country_code'=>"SI", 'calling_code'=>"+386" ,'label'=>'Slovenia (+386)'],
						['country_code'=>"SB", 'calling_code'=>"+677" ,'label'=>'Solomon Islands (+677)'],
						['country_code'=>"SO", 'calling_code'=>"+252" ,'label'=>'Somalia (+252)'],
						['country_code'=>"ZA", 'calling_code'=>"+27" ,'label'=>'South Africa (+27)'],
						['country_code'=>"ES", 'calling_code'=>"+34" ,'label'=>'Spain (+34)'],
						['country_code'=>"LK", 'calling_code'=>"+94" ,'label'=>'Sri Lanka (+94)'],
						['country_code'=>"SH", 'calling_code'=>"+290" ,'label'=>'St. Helena (+290)'],
						['country_code'=>"KN", 'calling_code'=>"+1869" ,'label'=>'St. Kitts (+1869)'],
						['country_code'=>"SC", 'calling_code'=>"+1758" ,'label'=>'St. Lucia (+1758)'],
						['country_code'=>"SD", 'calling_code'=>"+249" ,'label'=>'Sudan (+249)'],
						['country_code'=>"SR", 'calling_code'=>"+597" ,'label'=>'Suriname (+597)'],
						['country_code'=>"SZ", 'calling_code'=>"+268" ,'label'=>'Swaziland (+268)'],
						['country_code'=>"SE", 'calling_code'=>"+46" ,'label'=>'Sweden (+46)'],
						['country_code'=>"CH", 'calling_code'=>"+41" ,'label'=>'Switzerland (+41)'],
						['country_code'=>"SI", 'calling_code'=>"+963" ,'label'=>'Syria (+963)'],
						['country_code'=>"TW", 'calling_code'=>"+886" ,'label'=>'Taiwan (+886)'],
						['country_code'=>"TJ", 'calling_code'=>"+7" ,'label'=>' Tajikstan (+7)'],
						['country_code'=>"TH", 'calling_code'=>"+66" ,'label'=>'Thailand (+66)'],
						['country_code'=>"TG", 'calling_code'=>"+228" ,'label'=>'Togo (+228)'],
						['country_code'=>"TO", 'calling_code'=>"+676" ,'label'=>'Tonga (+676)'],
						['country_code'=>"TT", 'calling_code'=>"+1868" ,'label'=>'Trinidad &amp; Tobago (+1868)'],
						['country_code'=>"TN", 'calling_code'=>"+216" ,'label'=>'Tunisia (+216)'],
						['country_code'=>"TR", 'calling_code'=>"+90" ,'label'=>'Turkey (+90)'],
						['country_code'=>"TM", 'calling_code'=>"+7" ,'label'=>' Turkmenistan (+7)'],
						['country_code'=>"TM", 'calling_code'=>"+993" ,'label'=>'Turkmenistan (+993)'],
						['country_code'=>"TC", 'calling_code'=>"+1649" ,'label'=>'Turks &amp; Caicos Islands (+1649)'],
						['country_code'=>"TV", 'calling_code'=>"+688" ,'label'=>'Tuvalu (+688)'],
						['country_code'=>"UG", 'calling_code'=>"+256" ,'label'=>'Uganda (+256)'], 
						['country_code'=>"UA", 'calling_code'=>"+380" ,'label'=>'Ukraine (+380)'],
						['country_code'=>"AE", 'calling_code'=>"+971" ,'label'=>'United Arab Emirates (+971)'],
						['country_code'=>"UY", 'calling_code'=>"+598" ,'label'=>'Uruguay (+598)'], 
						['country_code'=>"UZ", 'calling_code'=>"+7" ,'label'=>' Uzbekistan (+7)'],
						['country_code'=>"VU", 'calling_code'=>"+678" ,'label'=>'Vanuatu (+678)'],
						['country_code'=>"VA", 'calling_code'=>"+379" ,'label'=>'Vatican City (+379)'],
						['country_code'=>"VE", 'calling_code'=>"+58" ,'label'=>'Venezuela (+58)'],
						['country_code'=>"VN", 'calling_code'=>"+84" ,'label'=>'Vietnam (+84)'],
						['country_code'=>"VG", 'calling_code'=>"+1284" ,'label'=>'Virgin Islands - British (+1284)'],
						['country_code'=>"VI", 'calling_code'=>"+1340" ,'label'=>'Virgin Islands - US (+1340)'],
						['country_code'=>"WF", 'calling_code'=>"+681" ,'label'=>'Wallis &amp; Futuna (+681)'],
						['country_code'=>"YE", 'calling_code'=>"+969" ,'label'=>'Yemen (North)(+969)'],
						['country_code'=>"YE", 'calling_code'=>"+967" ,'label'=>'Yemen (South)(+967)'],
						['country_code'=>"ZM", 'calling_code'=>"+260" ,'label'=>'Zambia (+260)'],
						['country_code'=>"ZW", 'calling_code'=>"+263" ,'label'=>'Zimbabwe (+263)'] ];

	return $country_code;
 }