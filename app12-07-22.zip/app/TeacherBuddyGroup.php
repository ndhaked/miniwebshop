<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeacherBuddyGroup extends Model
{
    Protected $table = 'teacher_buddy_group';  
}
